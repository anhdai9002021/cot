# !python3
__title__ = "Quản lý\nCột"
__doc__ = ("Quét cột kết cấu trong Revit, quản lý theo Mark, tự lấy móng / dầm đỡ và dầm đầu cột, "
           "thiết lập thép mặc định + quy tắc neo, xuất Excel, vẽ DXF, thống kê thép, gửi sang AutoCAD.")

# ============================================================================
#  QUẢN LÝ CỘT  -  pyRevit (CPython 3) + Windows Forms, chế độ sáng / tối
#  Thư viện dùng chung nằm trong  CotTools.extension/lib  (colcore, excel_to_dxf, thong_ke_thep, data/)
# ============================================================================
import json
import os
import subprocess
import traceback


def _log_path():
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    d = os.path.join(base, "CotTools")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return os.path.join(d, "cottools.log")


def log(text):
    """Ghi nhật ký có thời gian vào %APPDATA%\\CotTools\\cottools.log (để biết tool dừng ở bước nào)."""
    try:
        import time
        p = _log_path()
        try:
            if os.path.getsize(p) > 400000:          # quá 400 KB -> giữ bản cũ thành .1, bắt đầu file mới
                os.replace(p, p + ".1")
        except OSError:
            pass
        with open(p, "a", encoding="utf-8") as f:
            f.write("%s  %s\n" % (time.strftime("%H:%M:%S"), text))
    except Exception:
        pass


def main():
    import clr
    clr.AddReference("System.Windows.Forms")
    clr.AddReference("System.Drawing")
    clr.AddReference("RevitAPI")
    clr.AddReference("RevitAPIUI")
    import System
    from System.Windows import Forms as WF
    from System import Drawing as SD
    from Autodesk.Revit import DB
    from Autodesk.Revit.UI import TaskDialog
    from Autodesk.Revit.UI.Selection import ObjectType

    # luôn ưu tiên thư mục lib của CotTools và bỏ bản module cũ còn cache (tránh trùng tên với extension khác)
    import sys
    _lib = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", "lib"))
    sys.path = [p_ for p_ in sys.path if os.path.normcase(os.path.normpath(p_)) != os.path.normcase(_lib)]
    sys.path.insert(0, _lib)
    for _m in ("colcore", "excel_to_dxf", "thong_ke_thep", "bang_thong_ke", "revit_scan"):
        sys.modules.pop(_m, None)
    try:
        import colcore as C
        import excel_to_dxf as E
        import thong_ke_thep as T
        import bang_thong_ke as BT
        import revit_scan as RS
    except ImportError as ex:
        TaskDialog.Show("Quản lý cột", "Không tìm thấy thư viện trong thư mục lib của extension.\n"
                        "Hãy chép NGUYÊN thư mục CotTools.extension (gồm cả thư mục lib) rồi Reload pyRevit.\n\n%s" % ex)
        return

    # ------------------------------------------------------------------ Revit
    def pn(key, base):
        """Tên tham số Revit: danh sách người dùng thêm (Thiết lập) dò trước, rồi tới danh sách mặc định."""
        extra = [x.strip() for x in str(st.get(key, "")).split(",") if x.strip()]
        return extra + [b_ for b_ in base if b_ not in extra]

    def scan_revit(scope="auto"):
        """Quét Revit: logic nằm trong lib/revit_scan.py (tách từ v9.5). scope: auto | sel | all."""
        from pyrevit import revit
        return RS.scan_revit(revit.doc, revit.uidoc, DB, st, log, set_status=set_status,
                             refresh=form.Refresh, scope=scope)


    # ------------------------------------------------------------------ dữ liệu
    st = C.load_settings()
    state = {"rows": [], "results": {}, "outdir": "", "dxf": "", "page": "cols", "theme": st["theme"],
             "warns": []}

    THEMES = {
        "light": dict(bg=(244, 246, 250), panel=(255, 255, 255), text=(28, 32, 42), muted=(108, 116, 132),
                      accent=(31, 95, 191), atext=(255, 255, 255), input=(255, 255, 255), line=(214, 220, 232),
                      band1=(255, 255, 255), band2=(234, 242, 255), warn=(255, 232, 160), btn=(228, 233, 242),
                      head=(31, 95, 191)),
        "dark": dict(bg=(20, 22, 28), panel=(30, 33, 42), text=(232, 234, 240), muted=(140, 146, 162),
                     accent=(86, 128, 255), atext=(255, 255, 255), input=(44, 48, 60), line=(60, 66, 82),
                     band1=(32, 35, 45), band2=(40, 48, 68), warn=(120, 96, 24), btn=(52, 57, 72),
                     head=(52, 70, 120)),
    }

    def col(role):
        t = THEMES[state["theme"]][role]
        return SD.Color.FromArgb(t[0], t[1], t[2])

    def font(size, bold=False):
        if bold:
            return SD.Font("Segoe UI", System.Single(size), SD.FontStyle.Bold)
        return SD.Font("Segoe UI", System.Single(size))

    _mfont = {}

    def tw_(text, size=10, bold=False):
        """Bề rộng chữ (px) để đặt ô / nhãn vừa khít, không bị cắt hay đè nhau."""
        try:
            k_ = (size, bold)
            if k_ not in _mfont:
                _mfont[k_] = font(size, bold)
            return int(WF.TextRenderer.MeasureText(text, _mfont[k_]).Width) + 14
        except Exception:
            return int(len(text) * size * 0.95) + 14

    reg = []        # (control, role) để đổi màu khi đổi giao diện

    def bind(ctrl, name, fn):
        ctrl.Click += fn

    def msg(text, title="Quản lý cột"):
        WF.MessageBox.Show(text, title)

    # ------------------------------------------------------------------ form
    form = WF.Form()
    form.Text = "Quản lý cột  -  Revit → Excel → AutoCAD  (v9.6)"
    form.Size = SD.Size(1180, 700)
    form.MinimumSize = SD.Size(900, 520)
    form.StartPosition = WF.FormStartPosition.CenterScreen
    form.Font = font(10)
    reg.append((form, "form"))

    def mk_label(parent, text, x, y, w, h=24, role="lbl", size=10, bold=False):
        c = WF.Label()
        c.Text = text
        c.Location = SD.Point(x, y)
        c.Size = SD.Size(w, h)
        c.Font = font(size, bold)
        c.TextAlign = SD.ContentAlignment.MiddleLeft
        parent.Controls.Add(c)
        reg.append((c, role))
        return c

    def mk_button(parent, text, x, y, w, h, role="btn", size=10, bold=False):
        c = WF.Button()
        c.Text = text
        c.Location = SD.Point(x, y)
        c.Size = SD.Size(w, h)
        c.FlatStyle = WF.FlatStyle.Flat
        c.FlatAppearance.BorderSize = 0
        c.Cursor = WF.Cursors.Hand
        c.Font = font(size, bold)
        parent.Controls.Add(c)
        reg.append((c, role))
        return c

    def mk_fbtn(parent, text, role="btn", bold=False, minw=0):
        """Nút TỰ GIÃN theo chữ (không bị cắt) để xếp trong FlowLayoutPanel."""
        c = WF.Button()
        c.Text = text
        c.AutoSize = True
        c.AutoSizeMode = WF.AutoSizeMode.GrowAndShrink
        c.MinimumSize = SD.Size(minw, 30)
        c.Padding = WF.Padding(8, 2, 8, 2)
        c.Margin = WF.Padding(0, 0, 6, 6)
        c.FlatStyle = WF.FlatStyle.Flat
        c.FlatAppearance.BorderSize = 0
        c.Cursor = WF.Cursors.Hand
        c.Font = font(10, bold)
        parent.Controls.Add(c)
        reg.append((c, role))
        return c

    def mk_panel(parent, role="panel"):
        p = WF.Panel()
        parent.Controls.Add(p)
        reg.append((p, role))
        return p

    def mk_text(parent, text, x, y, w):
        c = WF.TextBox()
        c.Text = text
        c.Location = SD.Point(x, y)
        c.Size = SD.Size(w, 26)
        c.BorderStyle = WF.BorderStyle.FixedSingle
        parent.Controls.Add(c)
        reg.append((c, "input"))
        return c

    # ----- vùng nội dung (thêm trước để Fill nằm dưới Top / Bottom)
    pnl_main = mk_panel(form, "form")
    pnl_main.Dock = WF.DockStyle.Fill
    pnl_main.Padding = WF.Padding(8)

    pnl_bot = mk_panel(form, "panel")
    pnl_bot.Dock = WF.DockStyle.Bottom
    pnl_bot.Height = 56

    pnl_top = mk_panel(form, "panel")
    pnl_top.Dock = WF.DockStyle.Top
    pnl_top.Height = 56

    # ----- thanh trên
    mk_label(pnl_top, "QUẢN LÝ CỘT", 16, 4, 300, 30, "title", 15, True)
    mk_label(pnl_top, "Revit → Excel → AutoCAD", 18, 32, 300, 18, "muted", 9)
    nav = {}
    nav["cols"] = mk_button(pnl_top, "Cột theo Mark", 330, 10, 130, 34, "nav", 10, True)
    nav["set"] = mk_button(pnl_top, "Thiết lập", 468, 10, 110, 34, "nav", 10, True)
    nav["res"] = mk_button(pnl_top, "Thống kê thép", 586, 10, 130, 34, "nav", 10, True)
    b_theme = mk_button(pnl_top, "Giao diện: Sáng", 740, 10, 140, 34, "btn", 10)

    # ----- thanh dưới: trạng thái + nút hành động
    lbl_status = mk_label(pnl_bot, "Sẵn sàng.", 20, 8, 480, 58, "muted", 10)
    lbl_status.Dock = WF.DockStyle.Fill                 # chiếm phần còn lại, tự xuống dòng, không đè lên nút
    lbl_status.Padding = WF.Padding(12, 0, 8, 0)
    flow = WF.FlowLayoutPanel()
    flow.Dock = WF.DockStyle.Right
    flow.AutoSize = True
    flow.WrapContents = False
    flow.Padding = WF.Padding(0, 8, 8, 0)
    pnl_bot.Controls.Add(flow)
    reg.append((flow, "panel"))

    def flow_btn(text, role="btn", w=170):
        b = WF.Button()
        b.Text = text
        b.AutoSize = True
        b.AutoSizeMode = WF.AutoSizeMode.GrowAndShrink
        b.MinimumSize = SD.Size(w, 36)
        b.Padding = WF.Padding(10, 0, 10, 0)
        b.Margin = WF.Padding(6, 0, 0, 0)
        b.FlatStyle = WF.FlatStyle.Flat
        b.FlatAppearance.BorderSize = 0
        b.Cursor = WF.Cursors.Hand
        b.Font = font(10, True)
        flow.Controls.Add(b)
        reg.append((b, role))
        return b

    b_scan = flow_btn("⟳ Quét lại Revit", "btn", 130)
    b_xl = flow_btn("Xuất Excel", "btn", 100)
    b_draw = flow_btn("▶ Vẽ DXF + Thống kê", "accent", 160)
    b_cad = flow_btn("➜ Gửi bản vẽ cột", "accent", 140)
    b_cadtk = flow_btn("➜ Gửi bảng TK", "accent", 120)

    # ----- trang 1: cột theo Mark
    pg_cols = mk_panel(pnl_main, "form")
    pg_cols.Dock = WF.DockStyle.Fill

    def new_grid(parent):
        g = WF.DataGridView()
        g.Dock = WF.DockStyle.Fill
        g.AllowUserToAddRows = False
        g.AllowUserToDeleteRows = False
        g.AllowUserToResizeRows = False
        g.RowHeadersVisible = False
        g.SelectionMode = WF.DataGridViewSelectionMode.FullRowSelect
        g.MultiSelect = False
        g.BorderStyle = getattr(WF.BorderStyle, "None")
        g.ColumnHeadersHeightSizeMode = WF.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        g.ColumnHeadersHeight = 48
        g.RowTemplate.Height = 30
        g.EnableHeadersVisualStyles = False
        g.AutoSizeColumnsMode = WF.DataGridViewAutoSizeColumnsMode.Fill      # cột tự giãn theo bề rộng form
        g.ScrollBars = WF.ScrollBars.Both
        g.AllowUserToResizeColumns = True          # kéo mép tiêu đề để co giãn cột
        g.ShowCellToolTips = True                   # chữ bị cắt: rê chuột để xem đủ
        g.CellBorderStyle = WF.DataGridViewCellBorderStyle.SingleHorizontal
        parent.Controls.Add(g)
        return g

    grid = new_grid(pg_cols)
    grid.SelectionMode = WF.DataGridViewSelectionMode.CellSelect       # chọn theo ô để kéo chọn / điền hàng loạt
    grid.MultiSelect = True
    grid.ClipboardCopyMode = WF.DataGridViewClipboardCopyMode.EnableWithoutHeaderText
    keys = []
    for key, title, ro, typ, w in C.GRID_COLS:
        gc = WF.DataGridViewTextBoxColumn()
        gc.Name = key
        gc.HeaderText = title
        gc.Width = w
        gc.MinimumWidth = 36
        gc.FillWeight = float(w)
        gc.ReadOnly = ro
        gc.SortMode = WF.DataGridViewColumnSortMode.NotSortable
        grid.Columns.Add(gc)
        keys.append(key)

    tb = WF.FlowLayoutPanel()
    tb.Dock = WF.DockStyle.Top
    tb.AutoSize = True
    tb.AutoSizeMode = WF.AutoSizeMode.GrowAndShrink
    tb.WrapContents = True
    tb.FlowDirection = WF.FlowDirection.LeftToRight
    tb.Padding = WF.Padding(0, 0, 0, 8)
    pg_cols.Controls.Add(tb)
    reg.append((tb, "form"))
    b_def = mk_fbtn(tb, "Đặt thép mặc định cho Mark dòng chọn")
    b_defall = mk_fbtn(tb, "Đặt lại mặc định cho tất cả")
    b_copy = mk_fbtn(tb, "Chép thép dòng chọn → cả Mark")
    b_neo = mk_fbtn(tb, "Tính lại neo móng/dầm")
    b_fill = mk_fbtn(tb, "↓ Điền xuống ô chọn (Ctrl+D)")
    tb.SetFlowBreak(b_fill, True)
    b_pickhead = mk_fbtn(tb, "➜ Chọn DẦM đầu cột trong Revit", "accent", True)
    b_pickbase = mk_fbtn(tb, "➜ Chọn MÓNG / DẦM ĐỠ chân cột trong Revit", "accent", True)
    b_view = mk_fbtn(tb, "◉ Xem cột này trong Revit (đóng form)", "btn", True)
    tb.SetFlowBreak(b_view, True)
    lbl_info = mk_label(tb, "Bấm ô để sửa. Nền vàng = còn thiếu.", 0, 0, 100, 24, "muted", 9)
    lbl_info.AutoSize = True
    lbl_info.Margin = WF.Padding(0, 2, 24, 2)
    lbl_hint = mk_label(tb, "Cột TRÒN: cột 'Dạng' = Tròn, b = h = đường kính, 'Cây cạnh b' = TỔNG số cây (gõ Tròn / Chữ nhật để đổi dạng)  |  Kéo ô vuông ở góc dưới-phải ô đang chọn để điền xuống như Excel  |  Ctrl+D điền xuống  |  "
                            "Ctrl+V dán từ Excel  |  Delete xoá ô  |  Nút ➜ / ◉ sẽ ĐÓNG form để dùng Revit, mở lại tool vẫn giữ bảng.",
                        0, 0, 100, 24, "muted", 9)
    lbl_hint.AutoSize = True
    lbl_hint.MaximumSize = SD.Size(1100, 0)
    lbl_hint.Margin = WF.Padding(0, 2, 0, 2)

    # ----- trang 2: thiết lập
    pg_set = mk_panel(pnl_main, "form")
    pg_set.Dock = WF.DockStyle.Fill
    pg_set.Visible = False
    fields = {}

    pg_set.AutoScroll = True

    def group(title, x, y, w, h):
        p = mk_panel(pg_set, "panel")
        p.Location = SD.Point(x, y)
        p.Size = SD.Size(w, h)
        mk_label(p, title, 14, 8, w - 28, 26, "cardtitle", 10, True)
        return p

    def field(parent, key, label, x, y, lw, tw=90):
        """Nhãn rộng vừa khít chữ + ô nhập ngay bên phải. Trả về toạ độ x cuối ô nhập."""
        mk_label(parent, label, x, y, lw, 28, "lbl", 10)
        fields[key] = mk_text(parent, "", x + lw + 8, y, tw)
        return x + lw + 8 + tw

    def lw_of(*texts):
        return max(tw_(t) for t in texts)

    GW = 600
    g1 = group("THÉP MẶC ĐỊNH  (điền sẵn cho mọi cột)", 0, 0, GW, 200)
    t1 = ("Số cây cạnh b (cả 2 góc)", "Số cây cạnh h (cả 2 góc)", "Đường kính thép dọc (mm)")
    l1 = lw_of(*t1)
    xe = field(g1, "nb", t1[0], 14, 44, l1)
    field(g1, "nh", t1[1], 14, 80, l1)
    field(g1, "dia", t1[2], 14, 116, l1)
    xs = xe + 30
    wd = tw_("Đai")
    mk_label(g1, "Đai", xs, 44, wd, 28, "lbl", 10)
    fields["stir"] = mk_text(g1, "", xs + wd + 4, 44, 150)
    mk_label(g1, "dạng R8-100/200", xs, 80, tw_("dạng R8-100/200", 9), 24, "muted", 9)
    wr_ = tw_("Cột TRÒN: tổng số cây")
    mk_label(g1, "Cột TRÒN: tổng số cây", xs, 116, wr_, 28, "lbl", 10)
    fields["round_n"] = mk_text(g1, "", xs + wr_ + 4, 116, 60)
    mk_label(g1, "Mỗi đoạn cột có thể chọn Ø thép riêng ngay trong bảng.", 14, 160, GW - 28, 24, "muted", 9)

    g2 = group("NEO CHÂN CỘT  (tự lấy chiều cao móng / dầm đỡ từ Revit)", 0, 210, GW, 220)
    t2 = ("Cột trên MÓNG:   l = H − a", "Cột trên DẦM:    l = H − a", "Không thấy móng/dầm (H/L)")
    l2 = lw_of(*t2)
    field(g2, "found_a", t2[0], 14, 44, l2, 80)
    field(g2, "beam_a", t2[1], 14, 80, l2, 80)
    field(g2, "base_default", t2[2], 14, 116, l2, 120)
    mk_label(g2, "H = bề dày móng hoặc cao dầm;  l = chiều dài thép neo xuống.", 14, 164, GW - 28, 24, "muted", 9)

    g3 = group("NEO ĐẦU CỘT", GW + 20, 0, GW, 200)
    t3 = "Đầu cột CÓ dầm: neo vào dầm (× d)"
    field(g3, "head_k", t3, 14, 44, tw_(t3), 80)
    mk_label(g3, "Đầu cột KHÔNG có dầm: kéo thẳng đến hết cột rồi dừng (không móc).", 14, 88, GW - 28, 48, "muted", 9)

    g4 = group("QUY TẮC VẼ KHÁC", GW + 20, 210, GW, 280)
    t4 = ("Nối thép (× d)", "Móc chân cột (mm)", "Vùng giữa ngắn hơn (mm) → đai dày suốt",
          "Vùng đai dày = (H − cao dầm) ÷", "Làm tròn theo bội (mm)", "Cách làm tròn")
    l4 = lw_of(*t4)
    for n_, k_ in enumerate(("lap_k", "hook", "min_mid", "dense_div", "round_step")):
        field(g4, k_, t4[n_], 14, 44 + 36 * n_, l4, 80)
    mk_label(g4, t4[5], 14, 44 + 36 * 5, l4, 28, "lbl", 10)
    cb_round = WF.ComboBox()
    cb_round.DropDownStyle = WF.ComboBoxStyle.DropDownList
    cb_round.Location = SD.Point(14 + l4 + 8, 44 + 36 * 5)
    cb_round.Size = SD.Size(200, 28)
    cb_round.Items.Add("Làm tròn lên")
    cb_round.Items.Add("Làm tròn gần nhất")
    g4.Controls.Add(cb_round)
    reg.append((cb_round, "input"))

    g5 = group("CẤU TẠO THÉP / ĐAI  (mm)", 0, 440, GW, 310)
    t5 = ("Lớp bảo vệ đai", "Tâm thép dọc cách mép bê tông", "Móc đai (× Ø đai, mỗi đầu)",
          "Nửa đoạn gãy thép tại sàn", "Độ lệch ngang đoạn gãy", "Đai đầu / cuối cách mặt sàn",
          "Thép đỉnh cách mặt sàn trên")
    l5 = lw_of(*t5)
    for n_, k_ in enumerate(("cover", "bar_inset", "stir_hook_k", "jog", "jog_x", "stirrup_end", "top_cover")):
        field(g5, k_, t5[n_], 14, 44 + 36 * n_, l5, 80)

    g6 = group("TÊN THAM SỐ REVIT  &  NHẬT KÝ", GW + 20, 500, GW, 250)
    t6 = ("Cột - bề rộng b", "Cột - bề sâu h", "Dầm - bề rộng", "Dầm - chiều cao", "Ghi log chi tiết (1 = bật)")
    l6 = lw_of(*t6)
    for n_, k_ in enumerate(("names_b", "names_h", "names_bw", "names_bh")):
        field(g6, k_, t6[n_], 14, 44 + 34 * n_, l6, 300)
    field(g6, "debug_log", t6[4], 14, 44 + 34 * 4, l6, 80)
    mk_label(g6, "Tên thêm cách nhau dấu phẩy; được dò TRƯỚC danh sách mặc định.", 14, 44 + 34 * 5, GW - 28, 24, "muted", 9)

    g7 = group("BỐ CỤC BẢN VẼ  &  BẢNG THỐNG KÊ", 0, 760, GW, 220)
    t7 = ("Khoảng cách giữa các cột khi vẽ (mm)", "Số dòng tối đa / 1 phần bảng thống kê",
          "Chiều dài cây thép chuẩn (m)", "Ø ≤ giá trị này = thép cuộn (không chia cây)")
    l7 = lw_of(*t7)
    for n_, k_ in enumerate(("col_step", "table_rows", "bar_std", "coil_max_d")):
        field(g7, k_, t7[n_], 14, 44 + 36 * n_, l7, 80)

    g8 = group("DÒ MÓNG / DẦM  &  THÉP BỔ SUNG  &  ĐAI XOẮN  (v9.5)", GW + 20, 760, GW, 220)
    t8 = ("Dung sai cao độ chân cột (mm)", "Dung sai cao độ đỉnh cột - dầm (mm)", "Dầm cao hơn (mm) bị loại",
          "Thép bổ sung neo xuống tầng dưới (× d)", "Đai mặc định cột TRÒN (S10-100/200 = xoắn)", "Đai xoắn: số vòng kín mỗi đầu")
    l8 = lw_of(*t8)
    for n_, k_ in enumerate(("tol_base", "tol_top", "max_beam", "add_anchor_k")):
        field(g8, k_, t8[n_], 14, 40 + 30 * n_, l8, 80)
    field(g8, "stir_round", t8[4], 14, 40 + 30 * 4, l8, 110)
    field(g8, "spiral_end", t8[5], 14, 40 + 30 * 5, l8, 80)

    b_save = mk_button(pg_set, "Lưu thiết lập", 0, 1000, 170, 42, "accent", 10, True)
    b_reset = mk_button(pg_set, "Khôi phục mặc định", 182, 1000, 210, 42, "btn", 10, False)
    lbl_setmsg = mk_label(pg_set, "", 410, 1008, 800, 26, "muted", 9)

    # ----- trang 3: thống kê
    pg_res = mk_panel(pnl_main, "form")
    pg_res.Dock = WF.DockStyle.Fill
    pg_res.Visible = False
    res_grid = new_grid(pg_res)
    for key, title, w in (("dong", "Dòng Excel", 90), ("pier", "Pier", 80), ("tu", "Tầng đầu", 120),
                          ("den", "Tầng cuối", 120), ("doc", "Thép dọc (Kg)", 130),
                          ("dai", "Thép đai (Kg)", 130), ("noi", "Thép nối (Kg)", 130)):
        gc = WF.DataGridViewTextBoxColumn()
        gc.Name = key
        gc.HeaderText = title
        gc.Width = w
        gc.MinimumWidth = 50
        gc.FillWeight = float(w)
        gc.ReadOnly = True
        gc.SortMode = WF.DataGridViewColumnSortMode.NotSortable
        res_grid.Columns.Add(gc)
    tb2 = mk_panel(pg_res, "form")
    tb2.Dock = WF.DockStyle.Top
    tb2.Height = 72
    tb2.Padding = WF.Padding(0, 8, 0, 8)
    lbl_res = mk_label(tb2, "Bấm 'Vẽ DXF + Thống kê' để có kết quả. Cột AB, AC, AD của sheet Column Detail.",
                       0, 0, 100, 24, "muted", 10)
    lbl_res.Dock = WF.DockStyle.Fill                    # tự xuống dòng khi đường dẫn dài
    b_open = mk_button(tb2, "Mở thư mục kết quả", 0, 0, 230, 38, "btn")
    b_open.Dock = WF.DockStyle.Right

    # ------------------------------------------------------------------ hiển thị lưới
    def style_grid(g):
        g.BackgroundColor = col("bg")
        g.GridColor = col("line")
        hs = g.ColumnHeadersDefaultCellStyle
        hs.BackColor = col("head")
        hs.ForeColor = SD.Color.White
        hs.SelectionBackColor = col("head")
        hs.SelectionForeColor = SD.Color.White
        hs.Font = font(10, True)
        hs.Alignment = WF.DataGridViewContentAlignment.MiddleCenter
        hs.WrapMode = getattr(WF.DataGridViewTriState, "True")      # tiêu đề dài tự xuống dòng
        ds = g.DefaultCellStyle
        ds.BackColor = col("band1")
        ds.ForeColor = col("text")
        ds.SelectionBackColor = col("accent")
        ds.SelectionForeColor = SD.Color.White
        ds.Font = font(10)
        ds.Alignment = WF.DataGridViewContentAlignment.MiddleCenter

    def fit_columns():
        """Cột Mark rộng vừa 'C1000'; các cột còn lại chia đều phần còn lại, tự giãn theo form,
        kéo mép tiêu đề để co giãn (chữ dài quá thì bị cắt, rê chuột để xem đủ)."""
        try:
            mark_w = tw_("C1000", 10, True) + 4
            for j, (key, title, ro, typ, w0) in enumerate(C.GRID_COLS):
                c_ = grid.Columns[j]
                if key == "mark":
                    c_.AutoSizeMode = getattr(WF.DataGridViewAutoSizeColumnMode, "None")
                    c_.MinimumWidth = 30
                    c_.Width = int(mark_w)
                else:
                    c_.AutoSizeMode = WF.DataGridViewAutoSizeColumnMode.Fill
                    c_.MinimumWidth = 36
                    c_.FillWeight = float(w0)
        except Exception:
            log("LOI fit_columns: " + traceback.format_exc())

    def refresh_grid():
        state["busy"] = True
        try:
            _refresh_grid()
        finally:
            state["busy"] = False
        try:
            update_handle()                 # cập nhật ô vuông kéo điền (định nghĩa ở phần điền hàng loạt)
        except NameError:
            pass

    def _refresh_grid():
        style_grid(grid)
        grid.Rows.Clear()
        bands = C.group_index(state["rows"])
        for i, r in enumerate(state["rows"]):
            vals = [C.cell_text(r, k) for k in keys]
            idx = grid.Rows.Add(System.Array[System.Object](vals))
            row = grid.Rows[idx]
            row.DefaultCellStyle.BackColor = col("band2") if bands[i] % 2 else col("band1")
            if i == 0 or bands[i] != bands[i - 1]:
                row.Cells[0].Style.Font = font(10, True)
            if i < len(state["rows"]) - 1 and bands[i + 1] != bands[i]:
                row.DividerHeight = 8          # khoảng trắng ngăn cách các cột (Mark) khác nhau
            for k in C.missing_fields(r):
                row.Cells[keys.index(k)].Style.BackColor = col("warn")
        fit_columns()
        n_marks = len(C.marks_in_order(state["rows"]))
        lbl_info.Text = "%d dòng, %d Mark.  Nền vàng = còn thiếu." % (len(state["rows"]), n_marks)

    def refresh_row(i, bands=None):
        r = state["rows"][i]
        row = grid.Rows[i]
        if bands is None:
            bands = C.group_index(state["rows"])
        for j, k in enumerate(keys):
            row.Cells[j].Value = C.cell_text(r, k)
            row.Cells[j].Style.BackColor = col("band2") if bands[i] % 2 else col("band1")
        for k in C.missing_fields(r):
            row.Cells[keys.index(k)].Style.BackColor = col("warn")

    def refresh_results():
        style_grid(res_grid)
        res_grid.Rows.Clear()
        t1 = t2 = t3 = 0.0
        stat = state.get("stat", [])
        for r in stat:
            res_grid.Rows.Add(System.Array[System.Object]([
                str(r.get("row") or ""), r["M"], r["n_from"], r["n_to"],
                "%.2f" % r["doc"], "%.2f" % r["dai"], "%.2f" % r["noi"]]))
            t1 += r["doc"]; t2 += r["dai"]; t3 += r["noi"]
        if stat:
            idx = res_grid.Rows.Add(System.Array[System.Object](["", "TỔNG", "", "", "%.2f" % t1, "%.2f" % t2, "%.2f" % t3]))
            res_grid.Rows[idx].DefaultCellStyle.Font = font(10, True)
            res_grid.Rows[idx].DefaultCellStyle.BackColor = col("band2")

    def set_status(text):
        lbl_status.Text = text

    # ------------------------------------------------------------------ giao diện sáng / tối
    def apply_theme():
        for c, role in reg:
            if role == "form":
                c.BackColor = col("bg")
                c.ForeColor = col("text")
            elif role == "panel":
                c.BackColor = col("panel")
                c.ForeColor = col("text")
            elif role in ("lbl", "cardtitle", "title"):
                c.ForeColor = col("accent") if role in ("cardtitle", "title") else col("text")
                try:
                    c.BackColor = c.Parent.BackColor
                except Exception:
                    pass
            elif role == "muted":
                c.ForeColor = col("muted")
                try:
                    c.BackColor = c.Parent.BackColor
                except Exception:
                    pass
            elif role == "input":
                c.BackColor = col("input")
                c.ForeColor = col("text")
            elif role == "btn":
                c.BackColor = col("btn")
                c.ForeColor = col("text")
            elif role == "accent":
                c.BackColor = col("accent")
                c.ForeColor = SD.Color.White
            elif role == "nav":
                c.BackColor = col("panel")
                c.ForeColor = col("muted")
        for k, b in nav.items():                      # nút trang đang mở nổi bật
            if k == state["page"]:
                b.BackColor = col("accent")
                b.ForeColor = SD.Color.White
        b_theme.Text = "Giao diện: Tối" if state["theme"] == "dark" else "Giao diện: Sáng"
        refresh_grid()
        refresh_results()

    def show_page(name):
        state["page"] = name
        pg_cols.Visible = (name == "cols")
        pg_set.Visible = (name == "set")
        pg_res.Visible = (name == "res")
        for k, b in nav.items():
            b.BackColor = col("accent") if k == name else col("panel")
            b.ForeColor = SD.Color.White if k == name else col("muted")

    def on_theme(s, e):
        state["theme"] = "light" if state["theme"] == "dark" else "dark"
        st["theme"] = state["theme"]
        apply_theme()
        show_page(state["page"])
        C.save_settings(st)

    bind(b_theme, "theme", on_theme)
    for k, b in nav.items():
        bind(b, "nav_" + k, (lambda kk: (lambda s, e: show_page(kk)))(k))

    # ------------------------------------------------------------------ thiết lập
    def load_fields():
        for k, tbx in fields.items():
            tbx.Text = str(st[k])
        cb_round.SelectedIndex = 0 if st["round_mode"] == "up" else 1

    def read_fields():
        raw = {k: tbx.Text for k, tbx in fields.items()}
        raw["round_mode"] = "up" if cb_round.SelectedIndex == 0 else "nearest"
        raw["theme"] = state["theme"]
        return raw

    def sync_settings(save=False):
        """Đọc thiết lập trên form. Trả về True nếu hợp lệ."""
        new, errs = C.clean_settings(read_fields())
        if errs:
            lbl_setmsg.Text = "Lỗi: " + "; ".join(errs)
            return False
        st.clear()
        st.update(new)
        C.apply_engine_settings(E, st)
        if save:
            ok = C.save_settings(st)
            lbl_setmsg.Text = "Đã lưu thiết lập." if ok else "Không lưu được file thiết lập."
        return True

    def on_save(s, e):
        if sync_settings(True):
            n = C.recompute_base(state["rows"], st)
            refresh_grid()
            if n:
                lbl_setmsg.Text += "  Đã tính lại neo móng/dầm cho %d dòng." % n

    def on_reset(s, e):
        st.clear()
        st.update(C.DEFAULT_SETTINGS)
        st["theme"] = state["theme"]
        load_fields()
        lbl_setmsg.Text = "Đã khôi phục mặc định (chưa lưu, bấm 'Lưu thiết lập')."

    bind(b_save, "save", on_save)
    bind(b_reset, "reset", on_reset)

    # ------------------------------------------------------------------ quản lý theo Mark
    def current_index():
        try:
            cr = grid.CurrentRow
            return cr.Index if cr is not None else -1
        except Exception:
            return -1

    def on_def(s, e):
        i = current_index()
        if i < 0 or i >= len(state["rows"]):
            msg("Hãy chọn một dòng trong bảng trước.")
            return
        if sync_settings():
            mk = state["rows"][i]["mark"]
            n = C.fill_defaults(state["rows"], st, False, marks={mk})
            refresh_grid()
            set_status("Đã đặt thép mặc định cho Mark %s (%d ô)." % (mk, n))

    def on_defall(s, e):
        if WF.MessageBox.Show("Đặt lại thép của TẤT CẢ các dòng về mặc định?", "Xác nhận",
                              WF.MessageBoxButtons.YesNo) == WF.DialogResult.Yes:
            if sync_settings():
                C.fill_defaults(state["rows"], st, False)
                refresh_grid()
                set_status("Đã đặt lại thép mặc định cho tất cả.")

    def on_copy(s, e):
        i = current_index()
        if i < 0 or i >= len(state["rows"]):
            msg("Hãy chọn một dòng trước.")
            return
        n = C.copy_steel_to_mark(state["rows"], i)
        refresh_grid()
        set_status("Đã chép thép của dòng chọn cho %d dòng khác cùng Mark %s." % (n, state["rows"][i]["mark"]))

    def on_neo(s, e):
        if sync_settings():
            n = C.recompute_base(state["rows"], st)
            refresh_grid()
            set_status("Đã tính lại neo chân cột cho %d dòng theo thiết lập." % n)

    def on_cell_edit(s, e):
        i, j = e.RowIndex, e.ColumnIndex
        if i < 0 or j < 0 or i >= len(state["rows"]):
            return
        key = keys[j]
        val = grid.Rows[i].Cells[j].Value
        ok, m = C.set_cell(state["rows"][i], key, str(val) if val is not None else "")
        if not ok:
            msg(m)
        if ok and key == "shape":
            n_ = C.apply_shape_to_mark(state["rows"], i)       # đổi dạng cho mọi tầng của cùng Mark
            refresh_grid()
            if n_:
                set_status("Đã đổi dạng cho %d dòng khác cùng Mark %s." % (n_, state["rows"][i]["mark"]))
            return
        refresh_row(i)

    grid.CellEndEdit += on_cell_edit

    # ------------------------------------------------------------------ điền hàng loạt kiểu Excel
    fill = {"drag": False, "j": -1, "rows": []}
    fv = {"j": -1, "r": -1}                 # ô cuối của vùng chọn (nơi vẽ ô vuông kéo điền)

    def editable(j):
        return 0 <= j < len(keys) and not grid.Columns[j].ReadOnly

    def sel_cells():
        """{chỉ số cột: [các dòng đang chọn]} (chỉ ô sửa được)."""
        out = {}
        for c_ in grid.SelectedCells:
            if c_.RowIndex < len(state["rows"]) and editable(c_.ColumnIndex):
                out.setdefault(c_.ColumnIndex, []).append(c_.RowIndex)
        for j in out:
            out[j].sort()
        return out

    def put_cell(i, j, text):
        ok, _m = C.set_cell(state["rows"][i], keys[j], text)
        return ok

    def finish_edit(done):
        bands = C.group_index(state["rows"])
        for i in sorted(set(done)):
            refresh_row(i, bands)
        grid.Invalidate()

    def fill_range(j, src_rows, dst_rows):
        """Chép giá trị các ô nguồn (lặp theo chu kỳ) xuống các dòng đích. Trả về số ô điền được."""
        vals = [C.cell_text(state["rows"][i], keys[j]) for i in src_rows]
        n = 0
        for n_, t in enumerate(dst_rows):
            if put_cell(t, j, vals[n_ % len(vals)]):
                n += 1
        finish_edit(dst_rows)
        return n

    def do_fill_down(s=None, e=None):
        sel = sel_cells()
        if not sel:
            set_status("Chọn các ô cần điền (kéo chuột chọn nhiều ô trong cột) rồi bấm lại.")
            return
        n = 0
        for j, rws in sel.items():
            if len(rws) > 1:
                n += fill_range(j, [rws[0]], rws[1:])
            elif rws[0] > 0:
                n += fill_range(j, [rws[0] - 1], [rws[0]])
        set_status("Đã điền %d ô (lấy giá trị ô trên cùng của vùng chọn)." % n)

    def do_paste(s=None, e=None):
        try:
            txt = WF.Clipboard.GetText()
        except Exception:
            txt = ""
        if not txt:
            return
        lines = txt.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        while lines and lines[-1] == "":
            lines.pop()
        block = [ln.split("\t") for ln in lines]
        allc = list(grid.SelectedCells)
        if not block or not allc:
            return
        sel = sel_cells()
        done, bad = [], 0
        if len(block) == 1 and len(block[0]) == 1 and len(allc) > 1:       # 1 giá trị -> điền hết vùng chọn
            for j, rws in sel.items():
                for i in rws:
                    done.append(i)
                    bad += 0 if put_cell(i, j, block[0][0]) else 1
        else:                                                            # dán khối từ ô góc trên-trái
            r0 = min(c_.RowIndex for c_ in allc)
            c0 = min(c_.ColumnIndex for c_ in allc)
            for di, parts in enumerate(block):
                i = r0 + di
                if i >= len(state["rows"]):
                    break
                for dj, t in enumerate(parts):
                    j = c0 + dj
                    if j >= len(keys) or not editable(j):
                        continue
                    done.append(i)
                    bad += 0 if put_cell(i, j, t) else 1
        finish_edit(done)
        set_status("Đã dán vào %d dòng.%s" % (len(set(done)), ("  %d ô sai dạng nên bỏ qua." % bad) if bad else ""))

    def do_clear(s=None, e=None):
        done = []
        for j, rws in sel_cells().items():
            for i in rws:
                put_cell(i, j, "")
                done.append(i)
        finish_edit(done)

    def on_key(s, e):
        try:
            k = e.KeyCode
            if e.Control and k == WF.Keys.D:
                do_fill_down()
                e.Handled = True
                e.SuppressKeyPress = True
            elif e.Control and k == WF.Keys.V:
                do_paste()
                e.Handled = True
                e.SuppressKeyPress = True
            elif k == WF.Keys.Delete:
                do_clear()
                e.Handled = True
                e.SuppressKeyPress = True
        except Exception:
            log("LOI phim tat: " + traceback.format_exc())

    def update_handle(s=None, e=None):
        if state.get("busy"):
            return
        try:
            sel = sel_cells()
            if len(sel) == 1 and grid.SelectedCells.Count == sum(len(v) for v in sel.values()):
                j = list(sel)[0]
                fv["j"], fv["r"] = j, sel[j][-1]
            else:
                fv["j"], fv["r"] = -1, -1
            grid.Invalidate()
        except Exception:
            fv["j"], fv["r"] = -1, -1

    def handle_hit(x, y):
        if fv["j"] < 0:
            return False
        rc = grid.GetCellDisplayRectangle(fv["j"], fv["r"], False)
        if rc.Width <= 0 or rc.Height <= 0:
            return False
        return (rc.Right - 18) <= x <= rc.Right and (rc.Bottom - 18) <= y <= rc.Bottom

    def on_cellpaint(s, e):
        if e.RowIndex < 0 or e.RowIndex != fv["r"] or e.ColumnIndex != fv["j"]:
            return
        try:
            e.Paint(e.ClipBounds, WF.DataGridViewPaintParts.All)
            b_ = e.CellBounds
            r_ = SD.Rectangle(b_.Right - 11, b_.Bottom - 11, 8, 8)
            e.Graphics.FillRectangle(SD.Brushes.White, r_)
            pen = SD.Pen(col("accent"), System.Single(2))
            e.Graphics.DrawRectangle(pen, r_)
            pen.Dispose()
            e.Handled = True
        except Exception:
            pass

    def on_mdown(s, e):
        try:
            if e.Button == WF.MouseButtons.Left and handle_hit(e.X, e.Y):
                fill["drag"] = True
                fill["j"] = fv["j"]
                fill["rows"] = list(sel_cells().get(fv["j"], []))
        except Exception:
            log("LOI keo dien (nhan): " + traceback.format_exc())

    def on_mmove(s, e):
        try:
            if not fill["drag"]:
                grid.Cursor = WF.Cursors.Cross if handle_hit(e.X, e.Y) else WF.Cursors.Default
        except Exception:
            pass

    def on_mup(s, e):
        if not fill["drag"]:
            return
        fill["drag"] = False
        try:
            src, j = fill["rows"], fill["j"]
            if not src or not state["rows"]:
                return
            ri = grid.HitTest(e.X, e.Y).RowIndex
            if ri < 0:
                ri = len(state["rows"]) - 1 if e.Y > grid.Height // 2 else -1
            ri = min(ri, len(state["rows"]) - 1)
            if ri > src[-1]:
                n = fill_range(j, src, list(range(src[-1] + 1, ri + 1)))
                grid.ClearSelection()
                for i in range(src[0], ri + 1):
                    grid.Rows[i].Cells[j].Selected = True
                set_status("Đã kéo điền %d ô xuống tới dòng %d." % (n, ri + 1))
        except Exception:
            log("LOI keo dien (tha): " + traceback.format_exc())

    grid.KeyDown += on_key
    grid.SelectionChanged += update_handle
    grid.CellPainting += on_cellpaint
    grid.MouseDown += on_mdown
    grid.MouseMove += on_mmove
    grid.MouseUp += on_mup
    bind(b_fill, "fill", do_fill_down)
    bind(b_def, "def", on_def)
    bind(b_defall, "defall", on_defall)
    bind(b_copy, "copy", on_copy)
    bind(b_neo, "neo", on_neo)

    # ------------------------------------------------------------------ quét / xuất / vẽ / gửi
    def sel_col_count():
        try:
            from pyrevit import revit
            return sum(1 for i_ in revit.uidoc.Selection.GetElementIds()
                       if revit.doc.GetElement(i_) is not None
                       and _is_cat(revit.doc.GetElement(i_), BICX.OST_StructuralColumns))
        except Exception:
            return 0

    def do_scan(user=False):
        """user=True: bấm nút 'Quét lại' -> hỏi giữ dữ liệu đã nhập + phạm vi quét (tránh mất bảng khi đang chọn 1 cột)."""
        log("do_scan bat dau (user=%s)" % user)
        old = list(state["rows"])
        keep, scope = False, "auto"
        if user and old:
            r1 = WF.MessageBox.Show(
                "Quét lại sẽ tạo lại bảng từ model.\n\nGiữ lại thép (số cây, Ø, đai) và dầm / móng bạn đã chọn hoặc nhập tay "
                "cho các dòng trùng khớp?\n\nYes = giữ lại\nNo = bỏ hết, dùng thép mặc định\nCancel = không quét",
                "Quét lại Revit", WF.MessageBoxButtons.YesNoCancel)
            if r1 == WF.DialogResult.Cancel:
                return
            keep = (r1 == WF.DialogResult.Yes)
            n_sel = sel_col_count()
            if n_sel:
                r2 = WF.MessageBox.Show(
                    "Trong Revit đang chọn %d cột.\n\nYes = chỉ quét %d cột đang chọn (bảng chỉ còn các cột này)\n"
                    "No = quét TOÀN BỘ model\nCancel = không quét" % (n_sel, n_sel),
                    "Phạm vi quét", WF.MessageBoxButtons.YesNoCancel)
                if r2 == WF.DialogResult.Cancel:
                    return
                scope = "sel" if r2 == WF.DialogResult.Yes else "all"
        set_status("Đang quét cột trong Revit ...")
        form.Refresh()
        try:
            items, warns, src = scan_revit(scope)
            if not items:
                msg("Không có cột kết cấu nào đọc được.\n" + "\n".join(warns[:10]))
                set_status("Không có cột.")
                return
            sync_settings()
            rows, w2 = C.build_rows(items, st)
            kept = C.carry_over(old, rows) if keep else 0
            state["rows"] = rows
            state["warns"] = warns + w2
            state["results"] = {}
            state["stat"] = []
            refresh_grid()
            refresh_results()
            log("do_scan xong: %d dong, giu lai %d" % (len(rows), kept))
            set_status("Đã quét %d dòng cột (%s).%s%s" % (len(rows), src,
                       ("  Giữ lại dữ liệu nhập tay cho %d dòng." % kept) if keep else "",
                       ("  Có %d lưu ý (xem hộp thoại)." % len(state["warns"])) if state["warns"] else ""))
            save_session(True)
            if state["warns"]:
                msg("Lưu ý khi quét:\n- " + "\n- ".join(state["warns"][:20]))
        except Exception as ex:
            log("LOI quet: " + traceback.format_exc())
            msg("Lỗi khi quét: %s\n\n%s" % (ex, traceback.format_exc()[-600:]))
            set_status("Lỗi khi quét.")

    def pick_outdir():
        if state["outdir"] and os.path.isdir(state["outdir"]):
            return state["outdir"]
        dlg = WF.FolderBrowserDialog()
        dlg.Description = "Chọn thư mục lưu COT.dxf và bảng kết quả"
        start = os.path.join(os.path.expanduser("~"), "Documents")
        if os.path.isdir(start):
            dlg.SelectedPath = start
        if dlg.ShowDialog() == WF.DialogResult.OK:
            state["outdir"] = dlg.SelectedPath
            return state["outdir"]
        return ""

    def do_export(s, e):
        if not state["rows"]:
            msg("Chưa có dữ liệu. Bấm 'Quét lại Revit' trước.")
            return
        dlg = WF.SaveFileDialog()
        dlg.Title = "Lưu file Excel"
        dlg.Filter = "Excel (*.xlsx)|*.xlsx"
        dlg.FileName = "COT_TU_REVIT"
        dlg.DefaultExt = "xlsx"
        dlg.OverwritePrompt = True
        if dlg.ShowDialog() == WF.DialogResult.OK:
            f = dlg.FileName if dlg.FileName.lower().endswith(".xlsx") else dlg.FileName + ".xlsx"
            C.write_xlsx(f, state["rows"], state["results"] or None)
            set_status("Đã xuất Excel: " + f)

    def ask_draw_options(cols_):
        """Hộp thoại trước khi vẽ: chọn cột cần vẽ + chế độ thép chân cột / tầng mái thấp.
        Trả về (tập mark được chọn, tuỳ chọn) hoặc None nếu bấm Hủy."""
        opts = dict(base_splice=False, top_through=True, thru_len=1000)
        try:
            opts.update(C.load_draw_opts())
        except Exception:
            log("load_draw_opts loi: " + traceback.format_exc())
        dlg = WF.Form()
        dlg.Text = "Vẽ ra CAD  -  chọn cột và chế độ thép"
        try:
            wa_h = int(WF.Screen.PrimaryScreen.WorkingArea.Height)
        except Exception:
            wa_h = 760
        dlg.Size = SD.Size(600, max(420, min(770, wa_h - 40)))
        dlg.AutoScroll = True                       # màn hình thấp / phóng to chữ: kéo thanh cuộn để thấy mục 2, 3 và nút Vẽ
        dlg.AutoScrollMinSize = SD.Size(560, 730)
        dlg.StartPosition = WF.FormStartPosition.CenterParent
        dlg.FormBorderStyle = WF.FormBorderStyle.FixedDialog
        dlg.MaximizeBox = False
        dlg.MinimizeBox = False
        dlg.Font = font(10)
        dlg.BackColor = col("bg")
        dlg.ForeColor = col("text")

        def lab(text, x, y, w, h=24, bold=False, role="text"):
            c = WF.Label()
            c.Text = text
            c.Location = SD.Point(x, y)
            c.Size = SD.Size(w, h)
            c.Font = font(10, bold)
            c.ForeColor = col(role)
            c.BackColor = col("bg")
            dlg.Controls.Add(c)
            return c

        def btn(text, x, y, w, h=34, primary=False):
            c = WF.Button()
            c.Text = text
            c.Location = SD.Point(x, y)
            c.Size = SD.Size(w, h)
            c.FlatStyle = WF.FlatStyle.Flat
            c.FlatAppearance.BorderSize = 0
            c.BackColor = col("accent") if primary else col("btn")
            c.ForeColor = col("atext") if primary else col("text")
            c.Cursor = WF.Cursors.Hand
            dlg.Controls.Add(c)
            return c

        lab("1) Chọn cột cần vẽ  (tích = vẽ):", 16, 12, 400, bold=True)
        clb = WF.CheckedListBox()
        clb.Location = SD.Point(16, 40)
        clb.Size = SD.Size(552, 250)
        clb.CheckOnClick = True
        clb.BorderStyle = WF.BorderStyle.FixedSingle
        clb.BackColor = col("input")
        clb.ForeColor = col("text")
        marks = []
        for mark, segs in cols_:
            marks.append(mark)
            sl_ = segs[0].sl if segs[0].sl not in (None, "") else 1
            clb.Items.Add("%s     (%d tầng, SL: %s%s)" % (mark, len(segs), sl_,
                                                       (", tròn Ø%d" % round(segs[0].b)) if segs[0].round else ""), True)
        dlg.Controls.Add(clb)
        lbl_cnt = lab("", 16, 296, 340)

        def upd_cnt(*a):
            lbl_cnt.Text = "Đã chọn %d / %d cột" % (clb.CheckedItems.Count, clb.Items.Count)

        def set_all(v):
            for i in range(clb.Items.Count):
                clb.SetItemChecked(i, v)
            upd_cnt()

        b_all = btn("Chọn tất cả", 360, 292, 100, 30)
        b_none = btn("Bỏ chọn hết", 468, 292, 100, 30)
        b_all.Click += lambda s_, e_: set_all(True)
        b_none.Click += lambda s_, e_: set_all(False)
        def on_item_check(s_, e_):       # sự kiện chạy TRƯỚC khi đổi dấu tích nên tự cộng / trừ 1
            n_ = clb.CheckedItems.Count + (1 if e_.NewValue == WF.CheckState.Checked else -1)
            lbl_cnt.Text = "Đã chọn %d / %d cột" % (n_, clb.Items.Count)

        clb.ItemCheck += on_item_check
        upd_cnt()

        lab("2) Chân cột  (móng / dầm đỡ):", 16, 336, 400, bold=True)
        rb_none = WF.RadioButton()
        rb_none.Text = "Không nối: thép đẩy từ móng / dầm đỡ lên, nối ở tầng kế (như cũ)"
        rb_sp = WF.RadioButton()
        rb_sp.Text = "Nối: móng / dầm đỡ có thép chờ, nối ngay tại chân cột"
        for i, rb in enumerate((rb_none, rb_sp)):
            rb.Location = SD.Point(30, 364 + i * 30)
            rb.Size = SD.Size(540, 26)
            rb.ForeColor = col("text")
            rb.BackColor = col("bg")
            dlg.Controls.Add(rb)
        rb_sp.Checked = bool(opts["base_splice"])
        rb_none.Checked = not rb_sp.Checked
        lab("Chiều dài nối = %g x Ø (sửa ở Thiết lập → Quy tắc vẽ khác → Nối thép (× d)); hai nhóm thép nối so le nhau 1 đoạn nối." % st["lap_k"],
            30, 424, 540, 40, role="muted")

        lab("3) Thép nối ngắn (tầng trên cùng / cột 1 tầng):", 16, 470, 540, bold=True)
        chk = WF.CheckBox()
        chk.Text = "Bỏ thép (2) nếu NGẮN hơn (mm), thép (1) đẩy thẳng lên:"
        chk.Location = SD.Point(30, 498)
        chk.Size = SD.Size(520, 26)
        chk.ForeColor = col("text")
        chk.BackColor = col("bg")
        chk.Checked = bool(opts["top_through"])
        dlg.Controls.Add(chk)
        tbx = WF.TextBox()
        tbx.Text = str(int(opts["thru_len"]))
        tbx.Location = SD.Point(30, 530)
        tbx.Size = SD.Size(90, 26)
        tbx.BorderStyle = WF.BorderStyle.FixedSingle
        tbx.BackColor = col("input")
        tbx.ForeColor = col("text")
        dlg.Controls.Add(tbx)
        lab("mm   Thép (1) = thanh từ dưới lên;  thép (2) = thanh nối ở tầng trên cùng "
            "(đo thanh ngắn hơn trong 2 hàng nối so le). Ngắn hơn số này: không nối, bỏ thép (2).", 128, 524, 440, 66, role="muted")

        lab("4) Bảng thống kê:  số dòng tối đa / 1 phần", 16, 598, 540, bold=True)
        tbx_rows = WF.TextBox()
        tbx_rows.Text = str(int(st["table_rows"]))
        tbx_rows.Location = SD.Point(30, 628)
        tbx_rows.Size = SD.Size(90, 26)
        tbx_rows.BorderStyle = WF.BorderStyle.FixedSingle
        tbx_rows.BackColor = col("input")
        tbx_rows.ForeColor = col("text")
        dlg.Controls.Add(tbx_rows)
        lab("dòng   Dài hơn số này thì bảng tự ngắt thành phần 2, 3... đặt cạnh nhau (tối thiểu 5).", 128, 624, 440, 40, role="muted")

        b_ok = btn("Vẽ", 360, 680, 100, 40, primary=True)
        b_cancel = btn("Hủy", 468, 680, 100, 40)
        out = {"res": None}

        def on_ok(s_, e_):
            if clb.CheckedItems.Count == 0:
                msg("Chưa chọn cột nào.")
                return
            try:
                h_ = int(round(float(tbx.Text.replace(",", ".").strip())))
                if h_ <= 0:
                    raise ValueError()
            except ValueError:
                msg("Kích thước thép (2) phải là số dương (mm).")
                return
            try:
                nr_ = int(round(float(tbx_rows.Text.replace(",", ".").strip())))
                if nr_ < 5:
                    raise ValueError()
            except ValueError:
                msg("Số dòng tối đa / 1 phần bảng thống kê phải là số nguyên >= 5.")
                return
            new = {"base_splice": bool(rb_sp.Checked), "top_through": bool(chk.Checked), "thru_len": h_}
            C.save_draw_opts(new)
            out["res"] = (set(marks[i] for i in range(clb.Items.Count) if clb.GetItemChecked(i)), new, nr_)
            dlg.DialogResult = WF.DialogResult.OK
            dlg.Close()

        b_ok.Click += on_ok
        b_cancel.Click += lambda s_, e_: dlg.Close()
        dlg.AcceptButton = b_ok
        dlg.CancelButton = b_cancel
        try:
            dlg.ShowDialog(form)
        finally:
            dlg.Dispose()
        return out["res"]

    def do_draw(s, e):
        if not state["rows"]:
            msg("Chưa có dữ liệu. Bấm 'Quét lại Revit' trước.")
            return
        if not sync_settings():
            show_page("set")
            return
        try:
            cols_ = E.columns_from_rows(state["rows"])
        except ValueError as ex:
            show_page("cols")
            msg(str(ex))
            return
        pick = ask_draw_options(cols_)
        if pick is None:
            return
        sel, dopts, nrows = pick
        st["table_rows"] = int(nrows)                 # số nhập ở hộp thoại Vẽ là số dùng thật; nhớ cho lần sau
        try:
            fields["table_rows"].Text = str(int(nrows))
        except Exception:
            pass
        C.save_settings(st)
        cols_ = [c_ for c_ in cols_ if c_[0] in sel]
        outdir = pick_outdir()
        if not outdir:
            return
        # v9.5: không ghi đè kết quả cũ mà không hỏi
        suffix = ""
        old_files = [f_ for f_ in ("COT.dxf", "THONG_KE.dxf", "ketqua_bang_mau.xlsx") if os.path.isfile(os.path.join(outdir, f_))]
        if old_files:
            import time as _t
            stamp = _t.strftime("_%Y%m%d_%H%M%S")
            ans = WF.MessageBox.Show(
                "Thư mục kết quả đã có: %s\n\nYes = GHI ĐÈ bản cũ\nNo = lưu thành bản MỚI (thêm hậu tố %s), giữ nguyên bản cũ\n"
                "Cancel = không vẽ" % (", ".join(old_files), stamp),
                "Đã có kết quả cũ", WF.MessageBoxButtons.YesNoCancel, WF.MessageBoxIcon.Question)
            if ans == WF.DialogResult.Cancel:
                return
            if ans == WF.DialogResult.No:
                suffix = stamp
            log("ve: thu muc co ket qua cu (%s) -> %s" % (", ".join(old_files), "luu ban moi" + suffix if suffix else "ghi de"))
        try:
            dxf = os.path.join(outdir, "COT%s.dxf" % suffix)
            tpl = os.path.join(C.ASSET_DIR, "C3.dxf")
            C.apply_engine_settings(E, st)
            C.apply_table_settings(BT, st)
            C.apply_draw_opts(E, dopts)
            log("ve: %d cot, chan cot=%s, bo thep 2 ngan=%s (< %s mm)" % (
                len(cols_), "NOI (thep cho)" if dopts["base_splice"] else "khong noi",
                dopts["top_through"], dopts["thru_len"]))
            prims, w = E.generate_columns(cols_, tpl, dxf, True, [])
            cs, bars, stirs = T.scan(dxf)
            stat, _bydia = T.compute(cs, bars, stirs)
            state["stat"] = stat
            state["results"] = C.results_map(stat)
            state["dxf"] = dxf
            xl = os.path.join(outdir, "ketqua_bang_mau%s.xlsx" % suffix)
            C.write_xlsx(xl, state["rows"], state["results"])
            tk_note = ""
            state["tk"] = ""
            try:                                  # bảng thống kê cốt thép theo mẫu (tự ngắt theo số dòng đã nhập)
                tk = os.path.join(outdir, "THONG_KE%s.dxf" % suffix)
                if os.path.isfile(tk):
                    try:
                        os.remove(tk)             # xoá bản cũ: nếu tạo lỗi thì không gửi nhầm bảng cũ sang CAD
                    except OSError:
                        pass
                info = BT.generate(dxf, tk, max_rows=int(nrows))
                state["tk"] = tk
                log("bang TK: toi da %d dong/phan -> %d dong, %d phan %s" % (nrows, info["rows"], info["parts"], info["per_part"]))
                tk_note = "  |  Bảng TK: %s (%d dòng, %d phần, tối đa %d dòng/phần)" % (tk, info["rows"], info["parts"], nrows)
            except Exception as ex_tk:
                log("LOI bang thong ke: " + traceback.format_exc())
                w = list(w) + ["Không tạo được THONG_KE.dxf: %s" % ex_tk]
            refresh_results()
            tot = sum(r["doc"] + r["dai"] + r["noi"] for r in stat)
            lbl_res.Text = "Đã vẽ %d cột → %s  |  Tổng %.2f kg  |  Bảng: %s%s" % (len(prims), dxf, tot, xl, tk_note)
            set_status("Đã vẽ %d cột và thống kê (%.2f kg). Xem trang 'Thống kê thép'." % (len(prims), tot))
            show_page("res")
            if w:
                msg("Cảnh báo khi vẽ:\n- " + "\n- ".join(w[:15]))
        except Exception as ex:
            log("LOI ve: " + traceback.format_exc())
            msg("Lỗi khi vẽ: %s\n\n%s" % (ex, traceback.format_exc()[-600:]))
            set_status("Lỗi khi vẽ.")

    def send_cad(path, what):
        if not path or not os.path.isfile(path):
            msg("Hãy bấm 'Vẽ DXF + Thống kê' trước (chưa có %s)." % what)
            return
        ps1 = os.path.join(C.ASSET_DIR, "dua_vao_cad.ps1")
        lsp = os.path.join(C.ASSET_DIR, "COLREBAR.lsp")
        try:
            cp = subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", ps1, "-Lsp", lsp,
                 "-Dxf", path],
                capture_output=True, text=True, errors="replace", timeout=90, creationflags=0x08000000)
            out = (cp.stdout + cp.stderr).strip()
            set_status(("Đã gửi %s sang AutoCAD. Quay lại AutoCAD và click điểm chèn." % what) if cp.returncode == 0
                       else "Chưa gửi được sang AutoCAD.")
            msg(out or "Xong.")
        except Exception as ex:
            msg("Không gọi được PowerShell: %s\n\nCách làm tay: trong AutoCAD gõ APPLOAD nạp COLREBAR.lsp, "
                "rồi gõ VECOT và chọn %s" % (ex, path))

    def do_cad(s, e):
        send_cad(state["dxf"], "bản vẽ cột (COT.dxf)")

    def do_cadtk(s, e):
        send_cad(state.get("tk", ""), "bảng thống kê (THONG_KE.dxf)")

    def do_open(s, e):
        if state["outdir"] and os.path.isdir(state["outdir"]):
            try:
                os.startfile(state["outdir"])
            except Exception:
                pass


    # ------------------------------------------------------------------ chọn trực tiếp trong Revit
    BICX = DB.BuiltInCategory
    PN_W = ["b", "B", "Width", "Beam Width", "Chiều rộng", "Rộng", "Bề rộng"]
    PN_H = ["h", "H", "Height", "Beam Height", "Chiều cao", "Cao", "Bề cao", "d", "Depth"]

    def _mm(v):
        return DB.UnitUtils.ConvertFromInternalUnits(v, DB.UnitTypeId.Millimeters)

    def make_eid(v):
        try:
            return DB.ElementId(int(v))
        except Exception:
            return DB.ElementId(System.Int64(int(v)))

    def _eid(el):
        try:
            return int(el.Id.Value)
        except Exception:
            return int(el.Id.IntegerValue)

    def _is_cat(el, bic):
        try:
            return el.Category is not None and el.Category.BuiltInCategory == bic
        except Exception:
            try:
                return el.Category is not None and el.Category.Id.Value == int(bic)
            except Exception:
                return False

    def _param_mm(el, names):
        try:
            tp = el.Document.GetElement(el.GetTypeId())
        except Exception:
            tp = None
        for src in (el, tp):
            if src is None:
                continue
            for nm in names:
                try:
                    p = src.LookupParameter(nm)
                except Exception:
                    p = None
                if p is not None and p.HasValue and p.StorageType == DB.StorageType.Double and p.AsDouble() > 0:
                    return _mm(p.AsDouble())
        return None

    def read_beam(el):
        """Đọc dầm: cao (mm), rộng (mm), hướng trong mặt bằng, độ dốc."""
        bb = el.get_BoundingBox(None)
        dz = bb.Max.Z - bb.Min.Z
        d, slope, rise = None, 0.0, 0.0
        loc = el.Location
        if isinstance(loc, DB.LocationCurve):
            c = loc.Curve
            p0, p1 = c.GetEndPoint(0), c.GetEndPoint(1)
            L2 = ((p1.X - p0.X) ** 2 + (p1.Y - p0.Y) ** 2) ** 0.5
            rise = abs(p1.Z - p0.Z)
            if L2 > 1e-6:
                d = ((p1.X - p0.X) / L2, (p1.Y - p0.Y) / L2)
                slope = rise / L2
            else:
                slope = 99.0
        if slope <= 0.02:
            depth, how = _mm(dz), ""
        else:   # dầm xiên: hộp bao sai -> ưu tiên tham số chiều cao của loại dầm
            depth = _param_mm(el, pn("names_bh", PN_H)) or _mm(max(dz - rise, 0.0))
            how = " (dầm XIÊN, cao lấy từ tham số loại dầm)"
        return dict(id=_eid(el), depth=depth, width=_param_mm(el, pn("names_bw", PN_W)), d=d, how=how)

    def pick_in_revit(prompt, multi):
        """Form đã đóng nên Revit dùng bình thường. Esc = hủy."""
        from pyrevit import revit
        uidoc = revit.uidoc
        try:
            if multi:
                refs = list(uidoc.Selection.PickObjects(ObjectType.Element, prompt))
            else:
                refs = [uidoc.Selection.PickObject(ObjectType.Element, prompt)]
            return [uidoc.Document.GetElement(r.ElementId) for r in refs]
        except Exception as ex:
            log("pick huy/loi: %s" % ex)
            return None

    action = {"name": None, "row": -1}

    def on_pickhead(s, e):
        from pyrevit import revit
        i = action["row"]
        if i < 0 or i >= len(state["rows"]):
            msg("Hãy chọn một dòng trong bảng trước.")
            return
        r = state["rows"][i]
        els = pick_in_revit("Chọn các DẦM ở đỉnh cột %s (%s → %s). Chọn xong bấm Finish." % (
            r["mark"], r["n_from"], r["n_to"]), True)
        if not els:
            set_status("Đã hủy chọn.")
            return
        beams, bad = [], 0
        for el in els:
            try:
                if _is_cat(el, BICX.OST_StructuralFraming):
                    beams.append(read_beam(el))
                    continue
            except Exception as ex:
                log("read_beam loi: %s" % ex)
            bad += 1
        if not beams:
            msg("Không có DẦM nào trong các đối tượng đã chọn (phải là Structural Framing).")
            return
        bx = None
        if r.get("col_id"):
            try:
                t = revit.doc.GetElement(make_eid(r["col_id"])).GetTransform()
                bx = (t.BasisX.X, t.BasisX.Y)
            except Exception:
                bx = None
        if bx:
            perp = [b for b in beams if b["d"] and b["width"] and abs(b["d"][0] * bx[0] + b["d"][1] * bx[1]) < 0.35]
        else:
            perp = [b for b in beams if b["width"]] if len(beams) == 1 else []
        R = max(b["depth"] for b in beams)
        S = ""
        if perp:
            pb = max(perp, key=lambda b: b["depth"])
            S = "%dx%d" % (round(pb["width"]), round(pb["depth"]))
        r["R"] = int(round(R))
        r["S"] = S
        C.mark_manual(r, "R", "S")
        refresh_row(i)
        log("CHON dam dinh cot %s: %s" % (r["mark"], beams))
        set_status("Đã gán dầm đầu cột cho %s (%s → %s): cao %d mm%s." % (
            r["mark"], r["n_from"], r["n_to"], r["R"], (", dầm giao " + S) if S else ""))
        msg("Đã đọc %d dầm:\n- " % len(beams) + "\n- ".join(
            "Id %s: cao %d mm, rộng %s%s" % (b["id"], round(b["depth"]), ("%d mm" % round(b["width"])) if b["width"] else "?", b["how"])
            for b in beams)
            + "\n\nDầm đầu cột (R) = %d mm.   Dầm giao (S) = %s" % (r["R"], S or "(không xác định - sửa tay ô 'Dầm giao')")
            + (("\n(%d đối tượng không phải dầm đã bỏ qua)" % bad) if bad else ""))

    def on_pickbase(s, e):
        i = action["row"]
        if i < 0 or i >= len(state["rows"]):
            msg("Hãy chọn một dòng trong bảng trước.")
            return
        r = state["rows"][i]
        if r.get("Y") is None:
            msg("Chỉ dòng ĐẦU của mỗi cột (đoạn chân cột) mới có 'Móng / neo'. Hãy chọn dòng thấp nhất của cột này.")
            return
        if not sync_settings():
            show_page("set")
            return
        els = pick_in_revit("Chọn MÓNG hoặc DẦM đang đỡ chân cột %s (%s)." % (r["mark"], r["n_from"]), False)
        if not els:
            set_status("Đã hủy chọn.")
            return
        el = els[0]
        try:
            if _is_cat(el, BICX.OST_StructuralFoundation):
                bb = el.get_BoundingBox(None)
                kind, H, info = "found", _mm(bb.Max.Z - bb.Min.Z), "móng"
            elif _is_cat(el, BICX.OST_StructuralFraming):
                bi = read_beam(el)
                kind, H, info = "beam", bi["depth"], "dầm%s" % bi["how"]
            else:
                msg("Đối tượng chọn không phải Móng (Structural Foundation) hoặc Dầm (Structural Framing).")
                return
        except Exception as ex:
            msg("Không đọc được đối tượng: %s" % ex)
            return
        r["base_kind"], r["base_H"] = kind, H
        r["Y"] = C.base_text(kind, H, st)
        C.mark_manual(r, "Y")
        refresh_row(i)
        log("CHON do chan cot %s: %s H=%s -> %s" % (r["mark"], kind, H, r["Y"]))
        set_status("Chân cột %s đỡ bởi %s dày/cao %d mm → neo %s." % (r["mark"], info, round(H), r["Y"]))

 
    def request(name):
        i = current_index()
        if i < 0 or i >= len(state["rows"]):
            msg("Hãy chọn một dòng trong bảng trước.")
            return
        if name == "pickbase" and state["rows"][i].get("Y") is None:
            msg("Chỉ dòng ĐẦU của mỗi cột (đoạn chân cột) mới có 'Móng / neo'. Hãy chọn dòng thấp nhất của cột này.")
            return
        if name == "view" and not state["rows"][i].get("col_id"):
            msg("Dòng này không có Id cột Revit (hãy Quét lại).")
            return
        action["name"], action["row"] = name, i
        form.DialogResult = WF.DialogResult.OK          # đóng form tạm thời -> Revit dùng bình thường

    bind(b_pickhead, "pickhead", lambda s, e: request("pickhead"))
    bind(b_pickbase, "pickbase", lambda s, e: request("pickbase"))
    bind(b_view, "view", lambda s, e: request("view"))

    # ---- bấm dòng trong bảng -> chọn luôn cột đó trong Revit
    def select_in_revit(cid):
        from pyrevit import revit
        uidoc = revit.uidoc
        el = uidoc.Document.GetElement(make_eid(cid))
        if el is None:
            set_status("Cột Id %s không còn trong model (hãy Quét lại)." % cid)
            return
        ids = System.Collections.Generic.List[DB.ElementId]()
        ids.Add(el.Id)
        uidoc.Selection.SetElementIds(ids)
        try:
            uidoc.ShowElements(ids)
        except Exception as ex:
            log("ShowElements loi: %s" % ex)
        set_status("Đã chọn cột Id %s trong Revit." % cid)


    bind(b_scan, "scan", lambda s, e: do_scan(True))
    bind(b_xl, "export", do_export)
    bind(b_draw, "draw", do_draw)
    bind(b_cad, "cad", do_cad)
    bind(b_cadtk, "cadtk", do_cadtk)
    bind(b_open, "open", do_open)

    # ------------------------------------------------------------------ chạy
    C.apply_engine_settings(E, st)
    load_fields()
    apply_theme()
    show_page("cols")
    log("mo form")
    SESSION_VER = "9.5"

    def session_path():
        return os.path.join(os.path.dirname(C.settings_path()), "session.json")

    def doc_key():
        try:
            from pyrevit import revit
            return "%s|%s" % (revit.doc.Title, revit.doc.PathName)
        except Exception:
            return ""

    def save_session(resume):
        try:
            import time
            data = dict(ver=SESSION_VER, key=doc_key(), resume=resume, rows=state["rows"], warns=state["warns"],
                        saved=time.strftime("%H:%M %d/%m"))
            tmp = session_path() + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)     # ghi file tạm trong khối with, xong mới thay file thật
            os.replace(tmp, session_path())                # lỗi giữa chừng không làm rỗng session.json
        except Exception:
            log("save_session loi: " + traceback.format_exc())

    def load_session():
        try:
            with open(session_path(), "r", encoding="utf-8") as f:
                d = json.load(f)
            if d.get("ver") != SESSION_VER:
                return None                 # bảng lưu bởi bản cũ (chưa có 'Dạng' cột tròn...) -> bỏ, quét lại từ model
            if d.get("resume") and d.get("key") == doc_key() and d.get("rows"):
                save_session_flag = dict(d, resume=False)
                with open(session_path(), "w", encoding="utf-8") as f:
                    json.dump(save_session_flag, f, ensure_ascii=False)
                return d
        except Exception:
            pass
        return None

    sess = load_session()
    if sess:
        state["rows"] = sess["rows"]
        state["warns"] = sess.get("warns", [])
        refresh_grid()
        refresh_results()
        set_status("Đã mở lại bảng lưu lúc %s (%d dòng), KHÔNG quét lại. Bấm 'Quét lại Revit' nếu model đã đổi." %
                   (sess.get("saved", "?"), len(state["rows"])))
    else:
        do_scan()
    while True:
        action["name"] = None
        form.ShowDialog()
        nm = action["name"]
        if nm is None:
            break
        i = action["row"]
        try:
            if nm == "pickhead":
                on_pickhead(None, None)
            elif nm == "pickbase":
                on_pickbase(None, None)
            elif nm == "view":
                select_in_revit(state["rows"][i].get("col_id"))
                save_session(True)
                break                       # form ĐỂ ĐÓNG: dùng Revit thoải mái, mở lại tool sẽ giữ nguyên bảng
        except Exception:
            log("LOI hanh dong: " + traceback.format_exc())
            msg("Lỗi: " + traceback.format_exc()[-600:])
        try:
            refresh_grid()
            grid.CurrentCell = grid.Rows[i].Cells[0]
        except Exception:
            pass
    if state["rows"]:
        save_session(True)              # mọi cách thoát (kể cả nút X) đều giữ bảng cho lần mở sau

try:
    import pyrevit  # noqa: F401
    _IN_REVIT = True
except ImportError:
    _IN_REVIT = False

if _IN_REVIT:
    try:
        main()
    except Exception:
        try:
            from Autodesk.Revit.UI import TaskDialog
            TaskDialog.Show("Quản lý cột - lỗi", traceback.format_exc()[-1500:])
        except Exception:
            pass