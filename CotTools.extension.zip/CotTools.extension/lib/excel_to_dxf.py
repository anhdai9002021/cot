# -*- coding: utf-8 -*-
"""
Excel (sheet 'Column Detail') -> bản vẽ cột DXF theo mẫu C3.dxf

Cách dùng:
    python excel_to_dxf.py --excel MAU_EX_COT.xlsm --template C3.dxf --out COT.dxf
    python excel_to_dxf.py --excel MAU_EX_COT.xlsm --template C3.dxf --out C3.dxf --cols C3

Nguyên tắc:
- Giữ nguyên HEADER / TABLES (layer, kiểu text, kiểu dim) / BLOCKS / OBJECTS của file mẫu,
  chỉ thay phần ENTITIES bằng bản vẽ sinh ra từ Excel.
- Mọi hình vẽ, block, thuộc tính, dim, leader đều nhân bản từ chính đối tượng trong file mẫu.
- Cần: Python 3.8+ (openpyxl chỉ cần khi đọc file Excel). Không cần AutoCAD, không cần ezdxf.
"""
import argparse
import math
import re

# ----------------------------------------------------------------------------
# THAM SỐ QUY TẮC (chỉnh ở đây)
# ----------------------------------------------------------------------------
LAP_K = 40            # chiều dài nối thép = LAP_K x đường kính (mẫu: 720 = 40 x 18)
HOOK = 300            # chiều dài móc thép ở chân và đỉnh (mm)
JOG = 100             # nửa chiều cao đoạn gãy thép tại sàn (mm)
JOG_X = 30            # độ lệch ngang đoạn gãy (mm)
TOP_COVER = 30        # thép đỉnh cách mặt sàn trên (mm)
COVER = 30            # đai cách mép bê tông (mm)
BAR_INSET = 50        # tâm thép dọc cách mép bê tông (mm)
DENSE_DIV = 4         # vùng đai dày = (H - cao dầm) / DENSE_DIV
ROUND_STEP = 50       # làm tròn vùng đai dày theo bội số này
ROUND_MODE = "up"     # "up" = làm tròn lên, "nearest" = gần nhất
STIRRUP_END = 50      # đai đầu tiên / cuối cùng cách mặt sàn
MIN_MID = 500         # vùng giữa ngắn hơn giá trị này -> đai dày suốt đoạn (GIẢ ĐỊNH, xem README)
COL_STEP = 8000       # khoảng cách giữa các cột khi vẽ nhiều cột (mm)
ADD_ANCHOR_K = 40     # thép bổ sung (tầng trên nhiều thanh hơn): neo xuống cột tầng dưới ADD_ANCHOR_K x d
ADD_DX = 850.0        # mặt đứng: thép bổ sung vẽ lệch so với thép chính (mm)
SPIRAL_END_TURNS = 1.5  # đai xoắn: số vòng đai kín ở mỗi đầu
STIR_HOOK_K = 6       # móc đai = STIR_HOOK_K x đường kính đai (mỗi đầu)
HEAD_ANCHOR_K = 30    # đầu cột có dầm: thép neo vào dầm = HEAD_ANCHOR_K x d; không có dầm: kéo thẳng, không móc
BASE_SPLICE = False   # chân cột: True = móng / dầm đỡ có THÉP CHỜ, nối tại chân cột; False = thép đẩy từ móng lên, nối ở tầng kế
TOP_THROUGH = True    # tầng trên cùng thấp (mái): thép đẩy suốt từ tầng dưới lên, không nối
THRU_MIN_LEN = 1000   # thép (2) (thanh nối ở tầng trên cùng) NGẮN hơn giá trị này (mm) -> bỏ thép (2), đẩy thép (1) từ dưới lên thẳng
NOTE_GAP_COL = 90     # ghi chú đai (mặt cắt): chữ cách mép cột tối thiểu (mm, đã tính viền 30)
NOTE_CHAR_W = 33.5    # bề rộng 1 ký tự ghi chú đai (mm, chữ cao 50, hệ số rộng 0.8)
NOTE_GAP_SH = 31      # khoảng trống giữa chữ ghi chú đai và vòng số hiệu (mm)
APP_NAME = "COLREBAR"  # tên ứng dụng gắn dữ liệu ẩn (XDATA) để Lisp thống kê / chỉnh sửa

# Gốc toạ độ bản vẽ mẫu (điểm EXTMIN của C3.dxf)
X0 = 3742610.880520916
Y0 = -300919.5900032787


# ----------------------------------------------------------------------------
# Đọc / ghi DXF dạng cặp (mã nhóm, giá trị)
# ----------------------------------------------------------------------------
def load_raw(path):
    with open(path, "r", encoding="utf-8", errors="replace", newline="") as f:
        text = f.read()
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    pairs = []
    for i in range(0, len(lines) - 1, 2):
        pairs.append((int(lines[i].strip()), lines[i + 1]))
    return pairs


def save_raw(path, pairs):
    with open(path, "w", encoding="utf-8", newline="") as f:
        for c, v in pairs:
            f.write("%3d\r\n%s\r\n" % (c, v))


def split_sections(pairs):
    """Trả về (trước ENTITIES, danh sách entity, sau ENTITIES)."""
    i = 0
    start = end = None
    while i < len(pairs) - 1:
        if pairs[i] == (0, "SECTION") and pairs[i + 1] == (2, "ENTITIES"):
            start = i + 2
            j = start
            while pairs[j] != (0, "ENDSEC"):
                j += 1
            end = j
            break
        i += 1
    if start is None:
        raise ValueError("Không tìm thấy section ENTITIES trong file mẫu")
    return pairs[:start], pairs[start:end], pairs[end:]


def chunks(pairs):
    out = []
    for c, v in pairs:
        if c == 0:
            out.append([(c, v)])
        else:
            out[-1].append((c, v))
    return out


def getv(chunk, code, default=None):
    for c, v in chunk:
        if c == code:
            return v
    return default


def setv(chunk, code, value, nth=0):
    k = 0
    for i, (c, v) in enumerate(chunk):
        if c == code:
            if k == nth:
                chunk[i] = (c, value)
                return True
            k += 1
    return False


_AW = {"M": 833, "Ó": 778, "N": 722, "G": 778, "A": 667, "L": 556, "Ầ": 667, "U": 722,
       "2": 556, "↑": 500, "B": 667, "T": 611, "H": 722, "Ế": 667, "Â": 667, "E": 667, "Ê": 667}


def text_w(txt):
    return sum(_AW.get(ch, 600) for ch in txt) * 0.1118


def fmt(x):
    return repr(float(x)) if not isinstance(x, str) else x


class Ctx:
    """Cấp handle và gom entity."""

    def __init__(self, seed):
        self.h = seed
        self.out = []

    def handle(self):
        v = "%X" % self.h
        self.h += 1
        return v

    def add(self, chunk_list):
        for ch in chunk_list:
            self.out.extend(ch)


# ----------------------------------------------------------------------------
# Nguyên mẫu lấy từ file mẫu
# ----------------------------------------------------------------------------
class Protos:
    def __init__(self, entity_pairs):
        ch = chunks(entity_pairs)
        self.poly = None
        self.dim_rot = None
        self.dim_h = None
        self.leader = {}
        self.blocks = {}      # tên block -> [INSERT, ATTRIB..., SEQEND]
        self.title = {}       # scale -> proto của Dce_KhTenDam
        i = 0
        while i < len(ch):
            c = ch[i]
            t = c[0][1]
            if t == "LWPOLYLINE" and self.poly is None:
                self.poly = c
            elif t == "DIMENSION":
                if getv(c, 50) is not None and self.dim_rot is None:
                    self.dim_rot = c
                elif getv(c, 50) is None and self.dim_h is None:
                    self.dim_h = c
            elif t == "LEADER":
                self.leader.setdefault(len(
                    [1 for k, v in c if k == 10]), c)
            elif t == "INSERT":
                grp = [c]
                j = i + 1
                while j < len(ch) and ch[j][0][1] == "ATTRIB":
                    grp.append(ch[j])
                    j += 1
                if j < len(ch) and ch[j][0][1] == "SEQEND":
                    grp.append(ch[j])
                name = getv(c, 2)
                if name == "Dce_KhTenDam":
                    self.title.setdefault(float(getv(c, 41)), grp)
                else:
                    self.blocks.setdefault(name, grp)
            i += 1


def clean_xdata(chunk):
    return [(c, v) for c, v in chunk if c < 1000]


def tag_entities(pairs, line):
    """Gắn thẻ XDATA (COLREBAR) cho mọi entity cấp cao nhất chưa có XDATA: để AutoCAD biết entity thuộc cột nào
    (lệnh COTSUA xoá / vẽ lại đúng các entity của cột đó). ATTRIB / SEQEND đi theo INSERT nên bỏ qua."""
    out, cur = [], []

    def flush():
        if not cur:
            return
        if cur[0][1] not in ("ATTRIB", "SEQEND") and not any(c == 1001 for c, _v in cur):
            cur.append((1001, APP_NAME))
            cur.append((1000, line))
        out.extend(cur)

    for c, v in pairs:
        if c == 0:
            flush()
            cur = []
        cur.append((c, v))
    flush()
    return out


# ----------------------------------------------------------------------------
# Bộ dựng entity (toạ độ tương đối -> tuyệt đối)
# ----------------------------------------------------------------------------
class Builder:
    def __init__(self, ctx, protos, ox, oy, base=(X0, Y0)):
        self.ctx = ctx
        self.p = protos
        self.ox = base[0] + ox
        self.oy = base[1] + oy
        self.prims = []   # dữ liệu để vẽ preview / kiểm tra

    def ab(self, x, y):
        return self.ox + x, self.oy + y

    # --- polyline
    def poly(self, layer, pts, closed=False, bulges=None, xdata=None):
        h = self.ctx.handle()
        ch = [(0, "LWPOLYLINE"), (5, h), (330, "2"), (100, "AcDbEntity"), (8, layer),
              (100, "AcDbPolyline"), (90, str(len(pts))), (70, "1" if closed else "0"),
              (43, "0.0")]
        for i, (x, y) in enumerate(pts):
            ax, ay = self.ab(x, y)
            ch.append((10, fmt(ax)))
            ch.append((20, fmt(ay)))
            if bulges and bulges[i]:
                ch.append((42, fmt(bulges[i])))
        if xdata:
            ch.append((1001, APP_NAME))
            ch.extend((1000, t) for t in xdata)
        self.ctx.out.extend(ch)
        self.prims.append(("poly", layer, pts, closed, bulges))

    # --- block insert (nhân bản từ mẫu)
    def insert(self, grp, x, y, layer, texts, scale=None, attr_shift=None, xdata=None):
        """grp: [INSERT, ATTRIB.., SEQEND] mẫu; texts: {tag: text};
        attr_shift: {tag: (dx, dy)} dịch thêm cho thuộc tính."""
        ctx = self.ctx
        ins = clean_xdata(grp[0])
        ins_name = getv(ins, 2)
        ox_, oy_ = float(getv(ins, 10)), float(getv(ins, 20))
        nx, ny = self.ab(x, y)
        dx, dy = nx - ox_, ny - oy_
        hi = ctx.handle()
        setv(ins, 5, hi)
        setv(ins, 10, fmt(nx))
        setv(ins, 20, fmt(ny))
        if layer:
            setv(ins, 8, layer)
        if scale is not None:
            for code in (41, 42, 43):
                setv(ins, code, fmt(scale))
        if xdata:
            ins.append((1001, APP_NAME))
            ins.extend((1000, t) for t in xdata)
        ctx.out.extend(ins)
        shown = []
        attribs = [a for a in grp[1:] if a[0][1] == "ATTRIB"]
        seqs = [a for a in grp[1:] if a[0][1] == "SEQEND"]
        for a in attribs:
            a = clean_xdata(a)
            setv(a, 5, ctx.handle())
            setv(a, 330, hi)
            tag = getv(a, 2)
            ex = (0.0, 0.0)
            if attr_shift and tag in attr_shift:
                ex = attr_shift[tag]
            for cx, cy in ((10, 20), (11, 21)):
                if getv(a, cx) is not None:
                    setv(a, cx, fmt(float(getv(a, cx)) + dx + ex[0]))
                    setv(a, cy, fmt(float(getv(a, cy)) + dy + ex[1]))
            if tag in texts:
                setv(a, 1, texts[tag])
                if ins_name == "Dce_KyHieuChuGiua" and getv(a, 72) == "1":
                    # chữ canh giữa: điểm bắt đầu (mã 10) = -nửa bề rộng chữ
                    setv(a, 10, fmt(nx - text_w(texts[tag]) / 2.0))
            shown.append((tag, getv(a, 1), float(getv(a, 10)) - self.ox, float(getv(a, 20)) - self.oy,
                          getv(a, 50), float(getv(a, 40, "0"))))
            ctx.out.extend(a)
        for sq in seqs:
            sq = clean_xdata(sq)
            setv(sq, 5, ctx.handle())
            setv(sq, 330, hi)
            if layer:
                setv(sq, 8, layer)
            ctx.out.extend(sq)
        self.prims.append(("insert", getv(ins, 2), x, y, float(getv(ins, 41, "1")),
                           float(getv(ins, 50, "0")), shown))

    def block(self, name, x, y, layer, texts, scale=None, attr_shift=None, xdata=None):
        self.insert(self.p.blocks[name], x, y, layer, texts, scale, attr_shift, xdata=xdata)

    def title(self, scl, x, y, name_text, tl_text, xdata=None):
        self.insert(self.p.title[scl], x, y, "DCE_Block", {"TENDAM": name_text, "TL": tl_text},
                    xdata=xdata)

    # --- dim
    def dim(self, style, p13, p14, dimline, txt, vertical, meas):
        ch = list(self.p.dim_rot if vertical else self.p.dim_h)
        ch = clean_xdata(ch)
        ch = [(c, v) for c, v in ch if c != 2]          # bỏ tên block hình học: AutoCAD tự vẽ lại
        setv(ch, 5, self.ctx.handle())
        setv(ch, 8, "DCE_Dim")
        setv(ch, 3, style)
        for code_x, code_y, pt in ((10, 20, dimline), (11, 21, txt), (13, 23, p13), (14, 24, p14)):
            ax, ay = self.ab(*pt)
            setv(ch, code_x, fmt(ax))
            setv(ch, code_y, fmt(ay))
        setv(ch, 42, fmt(meas))
        self.ctx.out.extend(ch)
        self.prims.append(("dim", p13, p14, dimline, txt, vertical, meas))

    def leader(self, layer, pts, style="Dce_25MV"):
        h = self.ctx.handle()
        ch = [(0, "LEADER"), (5, h), (330, "2"), (100, "AcDbEntity"), (8, layer),
              (100, "AcDbLeader"), (3, style), (76, str(len(pts)))]
        for (x, y) in pts:
            ax, ay = self.ab(x, y)
            ch += [(10, fmt(ax)), (20, fmt(ay)), (30, "0.0")]
        self.ctx.out.extend(ch)
        self.prims.append(("leader", layer, pts))


# ----------------------------------------------------------------------------
# Đọc Excel
# ----------------------------------------------------------------------------
class Seg:
    spiral = False         # True: đai XOẮN (chỉ cho cột tròn)
    Hz = None              # chiều cao ĐỨNG (mm) của đoạn; None = bằng H (cột thẳng). Cột xiên: H = chiều dài trục
    slant = 0.0            # độ nghiêng so với phương đứng (độ), 0 = cột thẳng
    round = False          # True: cột TRÒN (b = h = đường kính, nb = TỔNG số cây thép dọc)
    ov = None              # (đoạn đầu của cột) {khoá: số} ghi đè: nhóm thép "đoạn.loại.hàng.bổ_sung" = Ø; đai "S.đoạn" = Ø; "SH.<khoá>" = số hiệu


def parse_stirrup(s):
    m = re.search(r"(\d+)\s*[-aA]\s*(\d+)(?:\s*/\s*(\d+))?", str(s or ""))
    if not m:
        raise ValueError("Không đọc được đai: %r (ví dụ R8-100/200)" % (s,))
    d, s1 = int(m.group(1)), int(m.group(2))
    s2 = int(m.group(3)) if m.group(3) else s1
    return d, s1, s2


def parse_pair(s, default):
    m = re.findall(r"[\d.]+", str(s or ""))
    if len(m) >= 2:
        return float(m[0]), float(m[1])
    return default


def _num(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def read_columns(path, only=None, strict=True):
    """Đọc sheet 'Column Detail' từ dòng 9. strict=False: chỉ liệt kê cột, không đòi nhập đủ thép."""
    import openpyxl            # chỉ cần khi đọc file Excel (tool trong Revit không cần)
    wb = openpyxl.load_workbook(path, data_only=True, keep_vba=False)
    if "Column Detail" not in wb.sheetnames:
        raise ValueError("Không thấy sheet 'Column Detail' trong file Excel")
    ws = wb["Column Detail"]
    cols = {}
    order = []
    errors = []
    for r in range(9, ws.max_row + 1):
        mark = ws.cell(r, 1).value
        if mark is None or str(mark).strip() == "":
            continue
        mark = str(mark).strip()
        if only and mark not in only:
            continue
        g = lambda c: ws.cell(r, c).value
        rnd = str(g(31) or "").strip().lower() in ("tròn", "tron", "round")
        if strict:
            need = [(5, "H (cột E)"), (6, "b (cột F)"), (7, "h (cột G)"), (8, "số cây cạnh b (cột H)"),
                    (10, "số cây cạnh h (cột J)"), (12, "đường kính thép (cột L)")]
            for c, label in need:
                if g(c) in (None, "") or _num(g(c), None) is None:
                    errors.append("Dòng %d (%s): thiếu %s" % (r, mark, label))
            if rnd:
                need = [n_ for n_ in need if n_[0] not in (7, 10)]
            if not re.search(r"\d+\s*[-aA]\s*\d+", str(g(13) or "")):
                errors.append("Dòng %d (%s): thiếu hoặc sai đai (cột M, ví dụ R8-100/200)" % (r, mark))
            if errors and len(errors) > 40:
                break
            if any(e.startswith("Dòng %d " % r) for e in errors):
                continue
        s = Seg()
        s.row = r
        s.mark = mark
        s.n_from = str(g(2) or "").strip()
        s.n_to = str(g(3) or "").strip()
        s.H = _num(g(5)) * 1000.0
        s.b = _num(g(6))
        s.h = _num(g(7))
        s.nb = int(_num(g(8))) + int(_num(g(9)))
        s.nh = int(_num(g(10))) + int(_num(g(11)))
        s.round = rnd
        if rnd:
            s.h, s.nh = s.b, 0
        s.dia = int(_num(g(12)))
        try:
            s.stir = parse_stirrup(g(13))
        except ValueError:
            s.stir = (0, 0, 0)
        s.has_beam = g(18) not in (None, "") and _num(g(18), 0.0) > 0      # ô R trống/0 = đầu cột không có dầm
        s.R = _num(g(18), 100.0) if s.has_beam else 100.0                   # R chỉ dùng để cắt cột khi vẽ
        s.beam = parse_pair(g(19), (200.0, 0.0))
        s.x = g(24)
        s.base = g(25)
        s.sl = g(27)
        cols.setdefault(mark, [])
        if mark not in order:
            order.append(mark)
        cols[mark].append(s)
    if errors:
        raise ValueError("Excel chưa nhập đủ, cần bổ sung:\n  " + "\n  ".join(errors[:40]))
    return [(m, cols[m]) for m in order], []


def nbars(seg):
    if seg.round:
        return max(seg.nb, 0)          # cột tròn: nb = tổng số cây
    return max(2 * seg.nb + 2 * seg.nh - 4, 0)


def r50(x):
    if ROUND_MODE == "up":
        return math.ceil(x / ROUND_STEP - 1e-9) * ROUND_STEP
    return math.floor(x / ROUND_STEP + 0.5) * ROUND_STEP


def fmt_stir(d, s1, s2=None):
    return "%%%%c%da%d" % (d, s1) + ("/%d" % s2 if s2 and s2 != s1 else "")


def cao_trinh(z):
    return "%+.3f" % z if abs(z) > 1e-9 else "%+.3f" % 0.0


def is_spiral_text(t):
    t = str(t or "").strip().lower()
    return bool(re.match(r"^[sx]\s*\d", t)) or ("xoắn" in t) or ("xoan" in t) or ("spiral" in t)


def stir_zones_rel(s):
    """Vùng đai của 1 đoạn cột, toạ độ TƯƠNG ĐỐI đáy đoạn (y = 0 ... H). Trả (zones, marks) - cùng quy tắc với bản vẽ."""
    d, s1, s2 = s.stir
    net = s.H - s.R
    Ld = r50(net / DENSE_DIV)
    mid_len = s.H - s.R - 2 * Ld
    if mid_len < MIN_MID:
        return [(0.0, s.H, s1)], [STIRRUP_END, s.H - STIRRUP_END]
    return ([(0.0, Ld, s1), (Ld, s.H - s.R - Ld, s2), (s.H - s.R - Ld, s.H, s1)],
            [STIRRUP_END, Ld, Ld + s2, s.H - s.R - Ld - s2, s.H - s.R - Ld, s.H - STIRRUP_END])


def spiral_length(s):
    """Đai XOẮN 1 đoạn cột tròn: (tổng chiều dài mm, số vòng xoắn, vòng kín đầu).
    Mỗi vòng xoắn = sqrt((pi x Dc)^2 + bước^2), Dc = đường kính tim đai; thêm SPIRAL_END_TURNS vòng kín mỗi đầu + 2 móc."""
    d = s.stir[0]
    dc = s.b - 2.0 * COVER
    circ = math.pi * dc
    zones, _m = stir_zones_rel(s)
    lo, hi = STIRRUP_END, s.H - STIRRUP_END
    turns, L = 0.0, 0.0
    for (za, zb, sp) in zones:
        a, b_ = max(za, lo), min(zb, hi)
        if b_ > a and sp > 0:
            t = (b_ - a) / sp
            turns += t
            L += t * math.hypot(circ, sp)
    L += 2.0 * SPIRAL_END_TURNS * circ + 2.0 * STIR_HOOK_K * d
    return L, turns, 2.0 * SPIRAL_END_TURNS


def stir_key(s):
    """Số hiệu đai: đai thường theo (b, h, d); đai xoắn theo (b, h, d, tổng chiều dài) vì mỗi tầng dài khác nhau."""
    if s.round and s.spiral:
        return (s.b, s.h, s.stir[0], "S", int(round(spiral_length(s)[0])))
    return (s.b, s.h, s.stir[0])


# ----------------------------------------------------------------------------
# Vẽ 1 cột
# ----------------------------------------------------------------------------
def draw_column(bd, mark, segs, warns):
    n = len(segs)
    first = segs[0]
    if first.x in (None, ""):
        raise ValueError("Cột %s: dòng đầu thiếu cao độ (cột X)" % mark)
    z0 = float(first.x)
    hm, neo = parse_pair(first.base, (600.0, 400.0))
    if first.base in (None, ""):
        warns.append("%s: thiếu cột Y (móng/neo), dùng 600/400" % mark)
    sl = first.sl if first.sl not in (None, "") else 1
    ov = dict(getattr(first, "ov", None) or {})          # đổi Ø theo số hiệu (lệnh COTSUA trong AutoCAD)
    for k_, s_ in enumerate(segs):                        # đai: đổi Ø cho cả đoạn
        kk_ = "S.%d" % (k_ + 1)
        if kk_ in ov and int(ov[kk_]) > 0:
            s_.stir = (int(ov[kk_]), s_.stir[1], s_.stir[2])
    for k_, s_ in enumerate(segs):                        # đổi kích thước tiết diện theo đoạn: "BW.đoạn" = b, "BH.đoạn" = h (mm)
        bw_, bh_ = ov.get("BW.%d" % (k_ + 1)), ov.get("BH.%d" % (k_ + 1))
        if s_.round:
            v_ = bw_ or bh_
            if v_:
                s_.b = s_.h = float(v_)
        else:
            if bw_:
                s_.b = float(bw_)
            if bh_:
                s_.h = float(bh_)
    dias_base = [s.dia for s in segs]                     # Ø mặc định của từng đoạn
    # Ø thép dọc LỚN NHẤT trong đoạn (kể cả nhóm đã đổi Ø) quyết định chiều dài nối; nối tại sàn lấy theo Ø lớn hơn của 2 đoạn kề nhau
    dias = [max([dias_base[k_]] + [int(v_) for kk_, v_ in ov.items() if kk_.split(".")[0] == str(k_ + 1)])
            for k_ in range(n)]
    lapk = [LAP_K * max(dias[k], dias[k + 1]) for k in range(n - 1)]
    for k in range(n - 1):
        if dias[k] != dias[k + 1]:
            warns.append("%s: đổi Ø thép dọc từ Ø%d (đoạn %d) sang Ø%d (đoạn %d); chiều dài nối lấy theo Ø lớn hơn (%g x %d = %d mm)" % (
                mark, dias[k], k + 1, dias[k + 1], k + 2, LAP_K, max(dias[k], dias[k + 1]), lapk[k]))

    for k_, s_ in enumerate(segs):
        if s_.round and s_.nb < 6:
            warns.append("%s (đoạn %d): cột tròn chỉ có %d cây thép dọc (thường tối thiểu 6) -> kiểm tra lại." % (
                mark, k_ + 1, s_.nb))
            break
    for k_, s_ in enumerate(segs):
        if s_.spiral and not s_.round:
            s_.spiral = False
            warns.append("%s (đoạn %d): đai xoắn chỉ dùng cho cột TRÒN -> cột chữ nhật dùng đai kín thường" % (mark, k_ + 1))
    for k_, s_ in enumerate(segs):
        if s_.slant and s_.slant > 0:
            warns.append("%s (đoạn %d): CỘT XIÊN %g° - thép, đai tính theo chiều dài TRỤC (H = %g m); hình vẽ thể hiện theo chiều dài trục, "
                         "cao trình theo chiều cao đứng." % (mark, k_ + 1, s_.slant, round(s_.H / 1000.0, 3)))
            break
    for k_, s_ in enumerate(segs):          # tool chỉ vẽ 1 đai ngoài, chưa có đai phụ / giằng
        if (not s_.round) and (s_.nb > 2 or s_.nh > 2):
            warns.append("%s (đoạn %d): mỗi cạnh > 2 cây (b=%d, h=%d) nhưng tool CHỈ vẽ và tính 1 đai ngoài, "
                         "CHƯA có đai phụ / giằng -> khối lượng đai có thể thiếu, hãy bổ sung tay." % (
                             mark, k_ + 1, s_.nb, s_.nh))
            break
    lapk0 = LAP_K * dias[0]                 # chiều dài nối tại chân cột (chế độ thép chờ)
    base_sp = bool(BASE_SPLICE)
    top_thru = False
    if TOP_THROUGH and n >= 2:
        # thép (2) = thanh nối ở tầng trên cùng; đo thanh NGẮN hơn trong 2 hàng (hàng nối so le): H - cover - đoạn gãy - đoạn nối
        len2 = segs[-1].H - TOP_COVER - JOG - lapk[n - 2]
        top_thru = len2 < THRU_MIN_LEN
        if top_thru and nbars(segs[-1]) > nbars(segs[-2]):
            top_thru = False
            warns.append("%s: tầng trên cùng tăng số thanh (%d -> %d) nên KHÔNG bỏ thép (2); thép bổ sung neo xuống tầng dưới" % (
                mark, nbars(segs[-2]), nbars(segs[-1])))
        if top_thru:
            warns.append("%s: thép (2) tầng trên cùng chỉ dài %g mm (< %g mm): bỏ thép (2), thép (1) từ tầng dưới đẩy thẳng lên đỉnh, không nối" % (
                mark, round(len2), THRU_MIN_LEN))
        if dias[-1] != dias[-2]:
            warns.append("%s: tầng trên cùng đổi Ø (%d -> %d) nhưng thép đẩy suốt nên giữ Ø%d" % (mark, dias[-2], dias[-1], dias[-2]))
    if base_sp and n == 1 and TOP_THROUGH:
        len2b = segs[0].H - TOP_COVER - lapk0         # thép cột (2) ngắn hơn trong 2 hàng nối so le
        if len2b < THRU_MIN_LEN:
            base_sp = False
            warns.append("%s: thép cột (2) chỉ dài %g mm (< %g mm): bỏ thép (2), thép (1) từ móng / dầm đỡ đẩy thẳng lên đỉnh cột, không nối" % (
                mark, round(len2b), THRU_MIN_LEN))
    if base_sp and neo < lapk0:
        warns.append("%s: chế độ nối ở chân: đoạn neo thép chờ vào móng/dầm đỡ chỉ %g mm < chiều dài nối %d mm, kiểm tra lại neo" % (
            mark, neo, lapk0))

    # ---- cao độ sàn (y bản vẽ)
    y_base = 900.0 + hm
    F = [y_base]
    for s in segs:
        F.append(F[-1] + s.H)
    names = [first.n_from] + [s.n_to for s in segs]
    zs = [z0]
    for s in segs:
        zs.append(zs[-1] + (s.Hz if s.Hz else s.H) / 1000.0)
    y_neo = y_base - neo
    y_top = F[-1]

    # ---- số thanh, nhóm thép
    N = [nbars(s) for s in segs]
    add_info = []
    groups = []        # mỗi đoạn: danh sách nhóm thép
    sh = 0
    prev_c = (0, 0)    # số thanh MỖI HÀNG (so le) của tầng dưới được nối lên tầng này
    for k in range(n):
        Nk = N[k]
        L1 = Nk - Nk // 2
        L2 = Nk - L1
        gl = []
        # thép bổ sung: tầng này nhiều thanh hơn số thanh tầng dưới nối lên -> phần dư neo xuống cột tầng dưới
        a_ln = [0, 0]
        if k > 0:
            a_ln = [max(L1 - prev_c[0], 0), max(L2 - prev_c[1], 0)]
            if a_ln[0] + a_ln[1] > 0:
                add_info.append("%s: đoạn %d tăng số thanh (%d -> %d): %d thanh thép BỔ SUNG neo xuống cột tầng dưới %g x Ø%d = %d mm" % (
                    mark, k + 1, N[k - 1], Nk, a_ln[0] + a_ln[1], ADD_ANCHOR_K, dias[k], int(round(ADD_ANCHOR_K * dias[k]))))
        if k < n - 1:
            Nc = min(Nk, N[k + 1])
            c1 = Nc - Nc // 2
            c2 = Nc - c1
            e1, e2 = max(L1 - c1, 0), max(L2 - c2, 0)
            spec = [("cont", 0, c1), ("cont", 1, c2), ("end", 0, e1), ("end", 1, e2)]
            if top_thru and k == n - 2:        # thép đi suốt lên đỉnh tầng mái thấp
                spec = [("thru", 0, c1), ("thru", 1, c2), ("end", 0, e1), ("end", 1, e2)]
            prev_c = (c1, c2)
        elif top_thru:
            spec = []                           # tầng mái thấp: không có thép riêng (đã đẩy suốt từ tầng dưới)
        else:
            spec = [("last", 0, L1), ("last", 1, L2)]
        rem = [L1 - a_ln[0], L2 - a_ln[1]]      # số thanh MỖI HÀNG xuất phát từ vị trí nối thường (không bổ sung)
        for kind, lane, cnt in spec:
            if cnt <= 0:
                continue
            take = min(cnt, max(rem[lane], 0))
            rem[lane] -= take
            if take > 0:
                sh += 1
                key_ = "%d.%s.%d.0" % (k + 1, kind, lane)
                gl.append(dict(kind=kind, lane=lane, cnt=take, sh=sh, seg=k, key=key_,
                               dia=int(ov.get(key_, dias_base[k]))))
            if cnt - take > 0:                  # phần còn lại = thanh bổ sung (bắt đầu neo trong cột tầng dưới)
                sh += 1
                key_ = "%d.%s.%d.1" % (k + 1, kind, lane)
                gl.append(dict(kind=kind, lane=lane, cnt=cnt - take, sh=sh, seg=k, add=True, key=key_,
                               dia=int(ov.get(key_, dias_base[k]))))
        groups.append(gl)
    for msg_ in add_info:
        warns.append(msg_)
    if top_thru:       # mặt cắt tầng mái vẫn ghi chú các thanh đi suốt (chỉ để ghi chú, không vẽ lại)
        groups[n - 1] = [dict(g, seg=n - 1, dup=True) for g in groups[n - 2] if g["kind"] == "thru"]
    waits = []         # thép chờ ở móng / dầm đỡ (chế độ nối)
    if base_sp:
        for g in groups[0]:
            if g.get("dup"):
                continue
            sh += 1
            wkey_ = "1.wait.%d.0" % g["lane"]
            waits.append(dict(lane=g["lane"], cnt=g["cnt"], sh=sh, parent=g, key=wkey_,
                              dia=int(ov.get(wkey_, g["dia"]))))

    # ---- số hiệu đai: mỗi loại (b, h, d) một số
    stir_sh = {}
    for s in segs:
        key = stir_key(s)
        if key not in stir_sh:
            sh += 1
            stir_sh[key] = sh

    # ---- đổi số hiệu thủ công (lệnh COTSUA trong AutoCAD): "SH.<khoá nhóm>" = số mới; số còn lại tự đánh, bỏ qua số đã dùng
    manual_sh = {}
    sh_entries = []                                   # (đối tượng, khoá ghi đè) theo đúng thứ tự đánh số tự động
    for k_ in range(n):
        for g_ in groups[k_]:
            if not g_.get("dup"):
                sh_entries.append((g_, "SH." + g_["key"]))
    for w_ in waits:
        sh_entries.append((w_, "SH." + w_["key"]))
    stir_ent = {}
    for key_, v_ in list(stir_sh.items()):
        okey_ = None
        for k_, s_ in enumerate(segs):
            if stir_key(s_) == key_ and ("SH.S.%d" % (k_ + 1)) in ov:
                okey_ = "SH.S.%d" % (k_ + 1)
                break
        stir_ent[key_] = {"sh": v_}
        sh_entries.append((stir_ent[key_], okey_ or "SH.S.0"))
    for e_, ok_ in sh_entries:
        if ok_ in ov and int(ov[ok_]) > 0:
            manual_sh[id(e_)] = int(ov[ok_])
    if manual_sh:
        vals_ = list(manual_sh.values())
        if len(vals_) != len(set(vals_)):
            raise ValueError("Cột %s: hai nhóm thép bị gán cùng một số hiệu thủ công" % mark)
        used_, nxt_ = set(vals_), 0
        for e_, ok_ in sh_entries:
            if id(e_) in manual_sh:
                e_["sh"] = manual_sh[id(e_)]
            else:
                nxt_ += 1
                while nxt_ in used_:
                    nxt_ += 1
                e_["sh"] = nxt_
        for key_, e_ in stir_ent.items():
            stir_sh[key_] = e_["sh"]
        by_key_ = {g_["key"]: g_ for k_ in range(n) for g_ in groups[k_] if not g_.get("dup")}
        for k_ in range(n):                           # nhóm thép xuyên suốt (dup) dùng lại số hiệu của nhóm gốc
            for g_ in groups[k_]:
                if g_.get("dup") and g_["key"] in by_key_:
                    g_["sh"] = by_key_[g_["key"]]["sh"]

    XA, XB = 2400.0, 2900.0
    lane_x = [XA, XB]

    # ================= MẶT ĐỨNG (TL 1/50) =================
    # tiêu đề
    G = lambda v: ("%g" % v)
    colx = ["COL|M=%s|SL=%s|Z0=%s|HM=%s|NEO=%s|NSEG=%d" % (mark, sl, G(z0), G(hm), G(neo), n)]
    for k_, s_ in enumerate(segs):
        colx.append("SEG|%d|%s|%s|%s|%s|%s|%d|%d|%d|%s%d-%d/%d|%s|%sx%s|%d|%s" % (
            k_ + 1, names[k_], names[k_ + 1], G(s_.H), G(s_.b), G(s_.h), s_.nb, s_.nh, s_.dia,
            "S" if s_.spiral else "R", s_.stir[0], s_.stir[1], s_.stir[2], G(s_.R), G(s_.beam[0]), G(s_.beam[1]), s_.row,
            "C" if s_.round else "R") + "|%d|%s|%s" % (1 if s_.has_beam else 0, G(s_.Hz or 0), G(s_.slant or 0)))
    # cấu hình vẽ + giá trị đổi Ø được LƯU TRONG bản vẽ -> lệnh COTSUA trong AutoCAD vẽ lại cột mà không cần Revit
    colx.append("CFG|LAP_K=%s|HOOK=%s|JOG=%s|JOG_X=%s|TOP_COVER=%s|COVER=%s|BAR_INSET=%s|DENSE_DIV=%s|ROUND_STEP=%s|ROUND_MODE=%s" % (
        G(LAP_K), G(HOOK), G(JOG), G(JOG_X), G(TOP_COVER), G(COVER), G(BAR_INSET), G(DENSE_DIV), G(ROUND_STEP), ROUND_MODE))
    colx.append("CFG2|STIRRUP_END=%s|MIN_MID=%s|ADD_ANCHOR_K=%s|SPIRAL_END_TURNS=%s|STIR_HOOK_K=%s|HEAD_ANCHOR_K=%s|BASE_SPLICE=%d|TOP_THROUGH=%d|THRU_MIN_LEN=%s" % (
        G(STIRRUP_END), G(MIN_MID), G(ADD_ANCHOR_K), G(SPIRAL_END_TURNS), G(STIR_HOOK_K), G(HEAD_ANCHOR_K),
        1 if BASE_SPLICE else 0, 1 if TOP_THROUGH else 0, G(THRU_MIN_LEN)))
    for key_ in sorted(ov):
        colx.append("OV|%s|%d" % (key_, int(ov[key_])))
    slant_txt = (" XIÊN %g%%%%d" % first.slant) if first.slant else ""
    bd.title(100.0, 1900.0, 400.0, "%%uCỘT " + mark + slant_txt + " (SL: " + str(sl) + ")", "TL: 1/50", xdata=colx)
    # đường sàn, cao trình, tên tầng
    for i, y in enumerate(F):
        bd.poly("3", [(950.0, y), (3650.0, y)])
        bd.block("Dce_CaoTrinh", 850.0, y, "DCE_Block", {"CT": cao_trinh(zs[i])})
        bd.block("Dce_KyHieuChuLeTrai", 190.0, y - 125.0, "Dce_text", {"KYHIEUCHU": names[i]})

    # chân cột (móng)
    y_bot = y_base - hm
    bd.poly("DCE_BaoBeTong", [(1500.0, y_bot), (2300.0, y_bot)])

    def zigzag(x, ylo, yhi):
        gap = yhi - ylo
        c = (ylo + yhi) / 2.0
        z = min(35.0, gap / 6.0)
        ext = gap / 2.0 + z
        pts = [(x, c - ext), (x, c - z), (x + z, c - z), (x - z, c + z), (x, c + z), (x, c + ext)]
        bd.poly("DCE_MCZiCZac", pts)

    zigzag(1500.0, y_bot, y_base)
    zigzag(2300.0, y_bot, y_base)

    def tagS(seg_):
        """Thẻ liên kết của đai (số hiệu đai) - để lệnh COTSUA biết click vào đâu."""
        return "TAG|M=%s|SH=%d|TP=S" % (mark, stir_sh[stir_key(seg_)])

    dens_all = []   # vùng đai từng đoạn
    dens_num = []   # số lượng đai từng đoạn
    for k, s in enumerate(segs):
        yb, yt = F[k], F[k + 1]
        ytop_col = yt - s.R
        # hai dải bê tông
        bd.poly("DCE_BaoBeTong", [(1500.0, yb), (1800.0, yb), (1800.0, ytop_col), (1500.0, ytop_col)])
        bd.poly("DCE_BaoBeTong", [(2300.0, yb), (2000.0, yb), (2000.0, ytop_col), (2300.0, ytop_col)])
        zigzag(1500.0, ytop_col, yt)
        zigzag(2300.0, ytop_col, yt)
        # hộp dầm
        bh = s.beam[1]
        if bh > 0:
            bd.poly("3", [(1800.0, yt), (1800.0, yt - bh), (2000.0, yt - bh), (2000.0, yt)], closed=True)
        # vùng đai
        d, s1, s2 = s.stir
        net = s.H - s.R
        Ld = r50(net / DENSE_DIV)
        mid_len = s.H - s.R - 2 * Ld
        if mid_len < MIN_MID:
            zones = [(yb, yt, s1)]
            marks = [yb + STIRRUP_END, yt - STIRRUP_END]
        else:
            zones = [(yb, yb + Ld, s1), (yb + Ld, yt - s.R - Ld, s2), (yt - s.R - Ld, yt, s1)]
            marks = [yb + STIRRUP_END, yb + Ld, yb + Ld + s2, yt - s.R - Ld - s2,
                     yt - s.R - Ld, yt - STIRRUP_END]
        if s.round and s.spiral:
            # đai XOẮN: mỗi vòng là 1 nét xiên (nửa bước) trong vùng từ đai đầu đến đai cuối
            lo_, hi_ = yb + STIRRUP_END, yt - STIRRUP_END
            for (za, zb, sp_) in zones:
                a_, b_ = max(za, lo_), min(zb, hi_)
                y_ = a_
                while sp_ > 0 and y_ + sp_ / 2.0 <= b_ + 1e-6:
                    bd.poly("DCE_ThepDai.TTT", [(1830.0, y_), (1970.0, y_ + sp_ / 2.0)], xdata=[tagS(s)])
                    y_ += sp_
        else:
            for m in marks:
                bd.poly("DCE_ThepDai.TTT", [(1830.0, m), (1970.0, m)], xdata=[tagS(s)])
        dens_all.append(zones)
        # số lượng đai: mỗi vùng = ceil(khoảng cách đai đầu - đai cuối / bước) + 1
        if len(zones) == 1:
            num = math.ceil(max(yt - STIRRUP_END - (yb + STIRRUP_END), 0) / s1 - 1e-9) + 1
        else:
            n1 = math.ceil((Ld - STIRRUP_END) / s1 - 1e-9) + 1
            n2 = math.ceil(max(zones[1][1] - s2 - (zones[1][0] + s2), 0) / s2 - 1e-9) + 1
            n3 = math.ceil((zones[2][1] - STIRRUP_END - zones[2][0]) / s1 - 1e-9) + 1
            num = n1 + n2 + n3
        dens_num.append(1 if (s.round and s.spiral) else int(num))
    # nắp đỉnh cột
    bd.poly("DCE_BaoBeTong", [(1500.0, y_top), (2300.0, y_top)])

    # đai: ký hiệu + dim bên trái
    for k, s in enumerate(segs):
        zones = dens_all[k]
        d, s1, s2 = s.stir
        shn = stir_sh[stir_key(s)]
        for (za, zb, sp) in zones:
            ym = (za + zb) / 2.0
            bd.block("Dce_KhtThepDai", 1200.0, ym, "DCE_Block",
                     {"DKVAKC": "%%c" + "%da%d" % (d, sp), "SH": str(shn)},
                     attr_shift={"SH": (0.0, -31.0 * (len(str(shn)) - 1))}, xdata=[tagS(s)])
        if len(zones) > 1:
            bd.dim("Dce_50MV", (1500.0, F[k + 1]), (1500.0, F[k]), (950.0, F[k]),
                   (849.0, (F[k] + F[k + 1]) / 2.0), True, F[k + 1] - F[k])
            z1, z2, z3 = zones
            bd.dim("Dce_50MV", (1500.0, z1[1]), (1500.0, z1[0]), (1200.0, z1[0]),
                   (1099.0, (z1[0] + z1[1]) / 2.0), True, z1[1] - z1[0])
            bd.dim("Dce_50MV", (1500.0, z2[1]), (1500.0, z2[0]), (1200.0, z2[0]),
                   (1099.0, (z2[0] + z2[1]) / 2.0), True, z2[1] - z2[0])
            bd.dim("Dce_50MV", (1500.0, z3[0]), (1500.0, z3[1]), (1200.0, z3[1]),
                   (1099.0, (z3[0] + z3[1]) / 2.0), True, z3[1] - z3[0])
        else:
            z1 = zones[0]
            bd.dim("Dce_50MV", (1500.0, z1[1]), (1500.0, z1[0]), (1200.0, z1[0]),
                   (1099.0, (z1[0] + z1[1]) / 2.0), True, z1[1] - z1[0])

    # ---- thép dọc (mặt đứng)
    brk = {y_neo, y_base}
    for k in range(n):
        brk.add(F[k + 1])
    for k in range(1, n):
        for g_ in groups[k]:
            if g_.get("add") and not g_.get("dup"):
                brk.add(F[k] - ADD_ANCHOR_K * g_["dia"])      # đáy thép bổ sung neo xuống tầng dưới
    for k in range(1, n):
        if top_thru and k == n - 1:
            continue                    # thép đi suốt: không gãy, không nối tại sàn này
        f = F[k]
        lp = lapk[k - 1]
        brk.update([f + JOG, f + JOG + lp, f + JOG + 2 * lp])
    if base_sp:
        brk.update([y_base + lapk0, y_base + 2 * lapk0])
    brk.update([y_top - TOP_COVER, y_top])

    def sy(k, lane, g, dk):
        """Cao độ đáy thanh: thanh bổ sung neo xuống cột tầng dưới ADD_ANCHOR_K x d; thanh thường theo quy tắc nối."""
        if g.get("add"):
            return F[k] - ADD_ANCHOR_K * dk
        return start_y(k, lane)

    def start_y(k, lane):
        if k == 0:
            return (y_base + lapk0 * lane) if base_sp else y_neo
        return F[k] + JOG + lapk[k - 1] * lane

    for k in range(n):
        for g in groups[k]:
            if g.get("dup"):
                continue
            lane, kind = g["lane"], g["kind"]
            dk = g["dia"]                       # Ø của riêng nhóm (số hiệu) này
            if kind == "cont":
                x = lane_x[lane] + (ADD_DX if g.get("add") else 0.0)
                f = F[k + 1]
                s_off = lapk[k] * lane
                jb, jt = f - JOG + s_off, f + JOG + s_off
                end = jt + lapk[k]
                st = sy(k, lane, g, dk)
                if k == 0 and not base_sp:
                    hx = x - HOOK if lane == 0 else x + HOOK
                    pts = [(hx, st), (x, st), (x, jb), (x + JOG_X, jt), (x + JOG_X, end)]
                else:
                    pts = [(x, st), (x, jb), (x + JOG_X, jt), (x + JOG_X, end)]
                ylab = (st + jt - 50.0) / 2.0
            elif kind == "end":
                x = lane_x[lane] + (700.0 if g.get("add") else 1000.0)
                st = sy(k, lane, g, dk)
                top = F[k + 1] - TOP_COVER
                hk = HEAD_ANCHOR_K * dk if segs[k].has_beam else 0.0     # có dầm: neo 30d; không: kéo thẳng
                pts = [(x, st), (x, top)]
                if hk > 0:
                    pts.append((x + hk, top))
                if k == 0 and not base_sp:      # đoạn đầu: có móc chân (chế độ thép chờ: móc nằm ở thép chờ)
                    pts.insert(0, (x - HOOK if lane == 0 else x + HOOK, st))
                ylab = (st + top + 150.0) / 2.0
            else:  # last / thru (thru = thép đi suốt từ tầng dưới lên đỉnh tầng mái thấp)
                x = lane_x[lane] + (ADD_DX if g.get("add") else 0.0)
                st = sy(k, lane, g, dk)
                top = y_top - TOP_COVER
                has_b = segs[n - 1].has_beam if kind == "thru" else segs[k].has_beam
                hk = HEAD_ANCHOR_K * dk if has_b else 0.0     # có dầm: neo 30d; không: kéo thẳng
                hx = x - hk if lane == 0 else x + hk
                pts = [(x, st), (x, top)]
                if hk > 0:
                    pts.append((hx, top))
                if k == 0 and not base_sp:      # cột chỉ có 1 đoạn: có móc chân
                    pts.insert(0, (x - HOOK if lane == 0 else x + HOOK, st))
                ylab = (st + top + 150.0) / 2.0
            bd.poly("DCE_ThepChu", pts, xdata=[
                "BAR|M=%s|SH=%d|D=%d|N=%d|SEG=%d|KIND=%s|LAP=%s|SL=%s|KEY=%s%s" % (
                    mark, g["sh"], dk, g["cnt"], k + 1, "last" if kind == "thru" else kind,
                    G(lapk[k] if kind == "cont" else 0), sl, g["key"], "|ADD=1" if g.get("add") else "")])
            g["x"] = x
            bd.block("Dce_KhtThepDai2", x, ylab, "DCE_Block",
                     {"DKVAKC": "%d%%%%c%d" % (g["cnt"], dk), "SH": str(g["sh"])},
                     xdata=["TAG|M=%s|SH=%d|TP=B" % (mark, g["sh"])])

    # thép chờ ở móng / dầm đỡ (chế độ nối): neo vào móng có móc, nhô lên khỏi mặt móng đúng chiều dài nối
    for w_ in waits:
        g_, ln_ = w_["parent"], w_["lane"]
        xs_ = g_["x"] + JOG_X
        top_w = y_base + lapk0 * (1 + ln_)
        hx_ = xs_ - HOOK if ln_ == 0 else xs_ + HOOK
        bd.poly("DCE_ThepChu", [(hx_, y_neo), (xs_, y_neo), (xs_, top_w)], xdata=[
            "BAR|M=%s|SH=%d|D=%d|N=%d|SEG=1|KIND=wait|LAP=%s|SL=%s|KEY=%s" % (
                mark, w_["sh"], w_["dia"], w_["cnt"], G(lapk0), sl, w_["key"])])
        bd.block("Dce_KhtThepDai2", xs_, (y_neo + y_base) / 2.0, "DCE_Block",
                 {"DKVAKC": "%d%%%%c%d" % (w_["cnt"], w_["dia"]), "SH": str(w_["sh"])},
                 xdata=["TAG|M=%s|SH=%d|TP=B" % (mark, w_["sh"])])

    # dim bên phải
    ys = sorted(brk)
    for a, b in zip(ys[:-1], ys[1:]):
        if b - a > 1e-6:
            bd.dim("Dce_50MV", (4000.0, a), (4000.0, b), (4500.0, b), (4399.0, (a + b) / 2.0), True, b - a)

    bd.poly("Defpoints", [(0.0, y_top + 500.0), (4750.0, y_top + 500.0), (4750.0, 0.0), (0.0, 0.0)], closed=True)

    # ================= MẶT CẮT (TL 1/25) =================
    pb = 300.0
    px0, px1, px2 = 5000.0, 6000.0, 7295.0
    LLx = 6500.0
    need_r = px2
    for k_, s_ in enumerate(segs):          # ghi chú đai nằm bên phải cột -> nới khung nếu cột rộng / chữ dài
        d_, a1_, a2_ = s_.stir
        t_ = fmt_stir(d_, a1_, a2_) if len(dens_all[k_]) > 1 else fmt_stir(d_, a1_)
        if s_.round and s_.spiral:
            t_ += " xoắn"
        v_ = len(t_.replace("%%c", "Ø"))
        need_r = max(need_r, LLx + s_.b + NOTE_GAP_COL + NOTE_CHAR_W * v_ + NOTE_GAP_SH + 125.0 + 70.0)
    px2 = math.ceil(need_r / 5.0) * 5.0
    last_top = pb
    for k, s in enumerate(segs):
        b, h = s.b, s.h
        d, s1, s2 = s.stir
        zones = dens_all[k]
        LLy = pb + 600.0
        gl = list(reversed(groups[k]))
        n_notes = len(gl)
        top_note = LLy + h + 155.0 + 125.0 * max(n_notes - 1, 0)
        ptop = top_note + 125.0
        # khung ô
        bd.poly("DCE_BaoBeTong", [(px1, ptop), (px2, ptop), (px2, pb), (px1, pb)], closed=True)
        bd.poly("DCE_BaoBeTong", [(px1, ptop), (px0, ptop), (px0, pb), (px1, pb)], closed=True)
        # ký hiệu tầng
        cy = (pb + ptop) / 2.0
        cyi = math.floor(cy)
        bd.block("Dce_KyHieuChuGiua", 5500.0, cyi, "Dce_text", {"KYHIEUCHU": "↑"})
        bd.block("Dce_KyHieuChuGiua", 5500.0, cyi - 250.0, "Dce_text", {"KYHIEUCHU": names[k]})
        bd.block("Dce_KyHieuChuGiua", 5500.0, cyi + 250.0, "Dce_text", {"KYHIEUCHU": names[k + 1]})
        # mỗi thép trên mặt cắt gán vào 1 nhóm số hiệu: 2 hàng nối so le = thép xen kẽ theo thứ tự vòng quanh tiết diện (quy ước)
        lane_q = [[], []]
        for g_ in groups[k]:
            lane_q[g_["lane"]].extend([g_] * g_["cnt"])
        lane_i = [0, 0]

        def next_group(order_idx):
            ln_ = order_idx % 2
            q_ = lane_q[ln_]
            g_ = q_[lane_i[ln_]] if lane_i[ln_] < len(q_) else None
            lane_i[ln_] += 1
            return g_

        def bar_tag(g_):
            return ["TAG|M=%s|SH=%d|TP=B" % (mark, g_["sh"])] if g_ else None

        # bê tông + đai + viền
        if s.round:
            # ---- CỘT TRÒN: b = h = đường kính; thép dọc rải đều trên đường tròn, đai là vòng tròn
            rr_ = b / 2.0
            ccx, ccy = LLx + rr_, LLy + rr_
            rs_ = rr_ - COVER

            def circ(r_):
                return [(ccx - r_, ccy), (ccx + r_, ccy)], [1.0, 1.0]

            pc_, bc_ = circ(rr_)
            bd.poly("DCE_BaoBeTong", pc_, closed=True, bulges=bc_)
            pc_, bc_ = circ(rr_ + 30.0)
            bd.poly("3", pc_, closed=True, bulges=bc_)
            Ls = 2.0 * math.pi * rs_ + 2.0 * STIR_HOOK_K * d       # đai vòng: chu vi + 2 móc
            sp_tag = ""
            if s.spiral:                                  # đai XOẮN: 1 sợi liên tục / đoạn cột (NUM = 1, L = tổng chiều dài)
                Ls = spiral_length(s)[0]
                sp_tag = "|SP=1"
            pc_, bc_ = circ(rs_)
            bd.poly("DCE_ThepDai", pc_, closed=True, bulges=bc_, xdata=[
                ("STIR|M=%s|SH=%d|D=%d|SEG=%d|NUM=%d|L=%.1f|SL=%s" + sp_tag) % (
                    mark, stir_sh[stir_key(s)], d, k + 1, dens_num[k], Ls, sl)])
            nb_ = max(int(s.nb), 1)
            rb_ = rr_ - BAR_INSET
            for i_ in range(nb_):
                th_ = math.pi / 2.0 - 2.0 * math.pi * i_ / nb_     # cây đầu ở đỉnh, đi theo chiều kim đồng hồ
                g_ = next_group(i_)
                bd.block("Dce_McThepChu", ccx + rb_ * math.cos(th_), ccy + rb_ * math.sin(th_),
                         "DCE_ThepChu", {}, scale=float(g_["dia"] if g_ else dias_base[k]), xdata=bar_tag(g_))
        else:
            bd.poly("DCE_BaoBeTong", [(LLx, LLy + h), (LLx + b, LLy + h), (LLx + b, LLy), (LLx, LLy)], closed=True)
            oct_pts = [(10, -30), (b - 10, -30), (b + 30, 10), (b + 30, h - 10), (b - 10, h + 30),
                       (10, h + 30), (-30, h - 10), (-30, 10)]
            oct_b = [0, 0.3926990816987241, 0, 0.3926990816987241, 0, 0.3926990816987241, 0, 0.3926990816987241]
            bd.poly("3", [(LLx + x, LLy + y) for x, y in oct_pts], closed=True, bulges=oct_b)
            x0, x1, y0, y1 = COVER, b - COVER, COVER, h - COVER
            leg = 6.0 * d / math.sqrt(2.0)
            bulge = -0.3926990816987241
            sp = [(x1 - 22.2 - leg, y1 - leg), (x1 - 22.2, y1), (x1 - 20, y1), (x1, y1 - 20),
                  (x1, y0 + 20), (x1 - 20, y0), (x0 + 20, y0), (x0, y0 + 20), (x0, y1 - 20),
                  (x0 + 20, y1), (x1 - 20, y1), (x1, y1 - 20), (x1, y1 - 22.3), (x1 - leg, y1 - leg - 22.3)]
            sb = [0, 0, bulge, 0, bulge, 0, bulge, 0, bulge, 0, bulge, 0, 0, 0]
            Ls = 2.0 * ((b - 2 * COVER) + (h - 2 * COVER)) + 2.0 * STIR_HOOK_K * d
            bd.poly("DCE_ThepDai", [(LLx + x, LLy + y) for x, y in sp], bulges=sb, xdata=[
                "STIR|M=%s|SH=%d|D=%d|SEG=%d|NUM=%d|L=%.1f|SL=%s" % (
                    mark, stir_sh[stir_key(s)], d, k + 1, dens_num[k], Ls, sl)])
            # thép dọc: vòng tròn
            xs = [BAR_INSET + i * (b - 2 * BAR_INSET) / (s.nb - 1) for i in range(s.nb)] if s.nb > 1 else [b / 2.0]
            ysx = [BAR_INSET + j * (h - 2 * BAR_INSET) / (s.nh - 1) for j in range(s.nh)] if s.nh > 1 else [h / 2.0]
            cells = []
            for j in range(s.nh - 1, -1, -1):
                for i in range(s.nb):
                    edge = (j in (0, s.nh - 1)) or (i in (0, s.nb - 1))
                    if edge:
                        cells.append((i, j))
            # thứ tự vòng quanh tiết diện theo chiều kim đồng hồ (từ góc trên-trái) để gán hàng nối xen kẽ
            cw, seen_ = [], set()
            ring = ([(i, s.nh - 1) for i in range(s.nb)] + [(s.nb - 1, j) for j in range(s.nh - 2, -1, -1)]
                    + [(i, 0) for i in range(s.nb - 2, -1, -1)] + [(0, j) for j in range(1, s.nh - 1)])
            for c_ in ring:
                if c_ in cells and c_ not in seen_:
                    seen_.add(c_)
                    cw.append(c_)
            cw += [c_ for c_ in cells if c_ not in seen_]
            gmap = {c_: next_group(ix_) for ix_, c_ in enumerate(cw)}
            for (ci_, cj_) in cells:
                g_ = gmap.get((ci_, cj_))
                bd.block("Dce_McThepChu", LLx + xs[ci_], LLy + ysx[cj_], "DCE_ThepChu", {},
                         scale=float(g_["dia"] if g_ else dias_base[k]), xdata=bar_tag(g_))
        # ghi chú thép dọc
        for i_, g in enumerate(gl):
            yn = LLy + h + 155.0 + 125.0 * i_
            bd.block("Dce_KhtMcThepChu", LLx - 99.0, yn, "DCE_Block",
                     {"DKVAKC": "%d%%%%c%d" % (g["cnt"], g["dia"]), "SH": str(g["sh"])},
                     attr_shift={"SH": (-15.0 * (len(str(g["sh"])) - 1), 0.0)},
                     xdata=["TAG|M=%s|SH=%d|TP=B" % (mark, g["sh"])])
            bd.leader("DCE_Dim", [(LLx + b / 2.0 + 26.0, LLy + h + 30.0), (LLx + b / 2.0 + 26.0, yn), (LLx - 99.0, yn)])
        # ghi chú đai
        shn = stir_sh[stir_key(s)]
        text = fmt_stir(d, s1, s2) if len(zones) > 1 else fmt_stir(d, s1)
        if s.round and s.spiral:
            text += " xoắn"
        vis = len(text.replace("%%c", "Ø"))
        yst = LLy + 0.75 * h - 15.0
        # chữ canh phải, kết thúc cách vòng số hiệu NOTE_GAP_SH; đầu chữ cách mép cột >= NOTE_GAP_COL
        xnote = LLx + b + NOTE_GAP_COL + NOTE_CHAR_W * vis + NOTE_GAP_SH
        bd.block("Dce_KhtMcThepTangCuong", xnote, yst, "DCE_Block",
                 {"DKVAKC": text, "SH": str(shn)},
                 attr_shift={"DKVAKC": (-(NOTE_GAP_SH - 6.2), 0.0),
                             "SH": (-15.0 * (len(str(shn)) - 1), 0.0)}, xdata=[tagS(s)])
        xl_ = LLx + b - COVER
        if s.round:               # điểm đầu leader nằm trên vòng đai tại độ cao yst
            rs2_ = b / 2.0 - COVER
            xl_ = LLx + b / 2.0 + math.sqrt(max(rs2_ * rs2_ - (yst - (LLy + b / 2.0)) ** 2, 0.0))
        bd.leader("DCE_Block", [(xl_, yst), (xnote, yst)])
        # dim tiết diện
        if s.round:               # cột tròn: 1 dim đường kính, đường gióng là tiếp tuyến của vòng tròn
            bd.dim("Dce_25MV", (LLx, LLy + b / 2.0), (LLx + b, LLy + b / 2.0), (LLx + b, LLy - 175.0),
                   (LLx + b / 2.0, LLy - 124.0), False, b)
        else:
            bd.dim("Dce_25MV", (LLx, LLy + h), (LLx, LLy), (LLx - 175.0, LLy), (LLx - 226.0, LLy + h / 2.0), True, h)
            bd.dim("Dce_25MV", (LLx, LLy), (LLx + b, LLy), (LLx + b, LLy - 175.0), (LLx + b / 2.0, LLy - 124.0), False, b)
        # tiêu đề mặt cắt
        bd.title(50.0, 6600.0, pb + 175.0,
                 "%%uCỘT " + mark + ((" %%%%c%d" % round(b)) if s.round else "") + " (SL: " + str(sl) + ")", "TL: 1/25")
        last_top = ptop
        pb = ptop
    bd.poly("Defpoints", [(4950.0, last_top + 50.0), (px2 + 50.0, last_top + 50.0), (px2 + 50.0, 250.0), (4950.0, 250.0)],
            closed=True)


# ----------------------------------------------------------------------------
# Chương trình chính
# ----------------------------------------------------------------------------
def add_appid(head, ctx, name):
    """Thêm bản ghi APPID cho XDATA (bắt buộc để AutoCAD đọc dữ liệu ẩn)."""
    t = None
    for i in range(len(head) - 1):
        if head[i] == (0, "TABLE") and head[i + 1] == (2, "APPID"):
            t = i
            break
    if t is None:
        raise ValueError("Không thấy bảng APPID trong file mẫu")
    e = t
    while head[e] != (0, "ENDTAB"):
        e += 1
    first = None
    for i in range(t, e):
        if head[i] == (0, "APPID"):
            first = i
            break
    owner = None
    if first is not None:
        j = first + 1
        while j < e and head[j][0] != 0:
            if head[j][0] == 330:
                owner = head[j][1]
            j += 1
    for i in range(t, e):
        if head[i] == (2, name):
            return head          # đã có
    rec = [(0, "APPID"), (5, ctx.handle())]
    if owner:
        rec.append((330, owner))
    rec += [(100, "AcDbSymbolTableRecord"), (100, "AcDbRegAppTableRecord"), (2, name), (70, "0"), ]
    # tăng số bản ghi trong bảng
    for i in range(t, e):
        if head[i][0] == 70:
            head[i] = (70, str(int(head[i][1]) + 1))
            break
    return head[:e] + rec + head[e:]


def seg_from_row(d):
    """Dựng Seg từ 1 dòng dữ liệu dạng dict (dùng cho tool trong Revit, không qua Excel).
    Khoá: mark, n_from, n_to, H (m), b, h, nb, nh, dia, stir ('R8-100/200'), R (cao dầm mm hoặc None),
          S ('WxD' hoặc ''), X (cao độ m), Y ('H/L'), SL, row."""
    s = Seg()
    s.row = d.get("row") or 0
    s.mark = str(d["mark"]).strip()
    s.n_from = str(d.get("n_from") or "").strip()
    s.n_to = str(d.get("n_to") or "").strip()
    s.H = _num(d.get("H")) * 1000.0
    s.b = _num(d.get("b"))
    s.h = _num(d.get("h"))
    s.nb = int(_num(d.get("nb")))
    s.nh = int(_num(d.get("nh")))
    s.round = (str(d.get("shape") or "") == "round")
    if s.round:
        s.b = s.h = (s.b or s.h)
        s.nh = 0
    s.dia = int(_num(d.get("dia")))
    s.spiral = is_spiral_text(d.get("stir"))
    s.slant = _num(d.get("slant"), 0.0)
    hz = _num(d.get("Hz"), 0.0)
    s.Hz = hz * 1000.0 if (hz and s.slant) else None
    try:
        s.stir = parse_stirrup(d.get("stir"))
    except ValueError:
        s.stir = (0, 0, 0)
    rv = d.get("R")
    s.has_beam = rv not in (None, "") and _num(rv, 0.0) > 0
    s.R = _num(rv, 100.0) if s.has_beam else 100.0
    s.beam = parse_pair(d.get("S"), (200.0, 0.0))
    s.x = d.get("X")
    s.base = d.get("Y")
    s.sl = d.get("SL")
    return s


def columns_from_rows(rows):
    """Gom các dòng (dict) theo Mark, giữ thứ tự xuất hiện -> [(mark, [Seg,...]), ...]. Kiểm tra đủ dữ liệu."""
    errors = []
    order, cols = [], {}
    for i, d in enumerate(rows):
        label = "%s (%s → %s)" % (d.get("mark"), d.get("n_from"), d.get("n_to"))
        need = [("H", "H"), ("b", "b"), ("h", "h"), ("nb", "số cây cạnh b"), ("nh", "số cây cạnh h"),
                ("dia", "đường kính thép")]
        for key, name in need:
            if str(d.get("shape") or "") == "round" and key in ("h", "nh"):
                continue                      # cột tròn: chỉ cần đường kính (b) và tổng số cây (nb)
            if _num(d.get(key), 0.0) <= 0:
                errors.append("%s: thiếu %s" % (label, name))
        if not re.search(r"\d+\s*[-aA]\s*\d+", str(d.get("stir") or "")):
            errors.append("%s: thiếu hoặc sai đai (ví dụ R8-100/200)" % label)
        sg = seg_from_row(d)
        if sg.mark not in cols:
            cols[sg.mark] = []
            order.append(sg.mark)
        cols[sg.mark].append(sg)
    if errors:
        raise ValueError("Chưa nhập đủ dữ liệu:\n  " + "\n  ".join(errors[:30]))
    return [(m, cols[m]) for m in order]


def generate(excel, template, out, only=None, local=False):
    cols, w0 = read_columns(excel, only, True)
    if not cols:
        raise SystemExit("Không tìm thấy cột nào trong Excel (kiểm tra tham số --cols)")
    return generate_columns(cols, template, out, local, list(w0))


def generate_columns(cols, template, out, local=False, warns=None):
    """cols: [(mark, [Seg...]), ...]  ->  ghi file DXF. Trả về (prims, cảnh báo)."""
    warns = warns if warns is not None else []
    pairs = load_raw(template)
    head, ents, tail = split_sections(pairs)
    protos = Protos(ents)
    seed = None
    hs_index = None
    for i, (c, v) in enumerate(head):
        if c == 9 and v.strip() == "$HANDSEED":
            seed = int(head[i + 1][1].strip(), 16)
            hs_index = i + 1
            break
    ctx = Ctx(max(seed or 0, 0x10000))
    head = add_appid(head, ctx, APP_NAME)
    if hs_index is not None:
        hs_index = [i for i, (c, v) in enumerate(head) if c == 9 and v.strip() == "$HANDSEED"][0] + 1
    allprims = []
    for idx, (mark, segs) in enumerate(cols):
        bd = Builder(ctx, protos, idx * COL_STEP, 0.0, (0.0, 0.0) if local else (X0, Y0))
        n0 = len(ctx.out)
        draw_column(bd, mark, segs, warns)
        # mọi entity của cột mang thẻ M=<Mark> để AutoCAD (COTSUA) xoá / vẽ lại đúng cột này
        ctx.out[n0:] = tag_entities(ctx.out[n0:], "OBJ|M=%s" % str(mark).replace("|", "/").replace("=", "-"))
        allprims.append((mark, bd.prims))
    if hs_index is not None:
        head[hs_index] = (head[hs_index][0], "%X" % ctx.h)
    if local:
        for i in range(len(head) - 1):
            if head[i] == (9, "$INSUNITS"):
                head[i + 1] = (70, "0")
                break
    save_raw(out, head + ctx.out + tail)
    return allprims, warns


def main():
    global BASE_SPLICE, TOP_THROUGH, THRU_MIN_LEN
    ap = argparse.ArgumentParser(description="Excel Column Detail -> DXF cột")
    ap.add_argument("--excel", required=True)
    ap.add_argument("--template", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--cols", default="", help="danh sách cột, cách nhau dấu phẩy (mặc định: tất cả)")
    ap.add_argument("--local", action="store_true",
                    help="vẽ gần gốc toạ độ (0,0) thay vì toạ độ của file mẫu; dùng khi chèn vào bản vẽ đang mở")
    ap.add_argument("--base-splice", action="store_true",
                    help="chân cột: móng / dầm đỡ có thép chờ, nối tại chân (mặc định: thép đẩy từ móng lên, nối ở tầng kế)")
    ap.add_argument("--no-top-through", action="store_true",
                    help="tắt chế độ tầng mái thấp đẩy thép suốt (mặc định: bật)")
    ap.add_argument("--thru-len", type=float, default=THRU_MIN_LEN,
                    help="thép (2) ngắn hơn giá trị này (mm) thì bỏ, đẩy thép (1) từ dưới lên thẳng (mặc định %g)" % THRU_MIN_LEN)
    a = ap.parse_args()
    BASE_SPLICE, TOP_THROUGH, THRU_MIN_LEN = a.base_splice, not a.no_top_through, a.thru_len
    only = [c.strip() for c in a.cols.split(",") if c.strip()] or None
    prims, warns = generate(a.excel, a.template, a.out, only, a.local)
    print("Đã vẽ %d cột -> %s" % (len(prims), a.out))
    for w in warns:
        print("CẢNH BÁO:", w)


if __name__ == "__main__":
    main()