Thu muc nay danh cho Python embeddable (tuy chon) - dung cho lenh SUATHEP / TKLAI trong AutoCAD.

Neu may ban DA cai Python 3 (go "py -3 --version" trong CMD thay ket qua) thi KHONG can chep gi vao day.
Neu chua co: tai "Windows embeddable package (64-bit)" tu python.org (ban 3.10 tro len), giai nen TAT CA vao thu muc nay
sao cho co file  lib\python\python.exe . Khong can cai dat, khong can quyen Admin.
