;;; ===========================================================================
;;; COLSUA.lsp  -  Doi duong kinh (D) thep cot ngay trong AutoCAD, mat dung + mat cat + bang thong ke
;;;                tu cap nhat theo (lien ket qua so hieu).
;;;
;;; LENH
;;;   COTSUA   Chon 1 cay thep (hoac so hieu) o mat dung / mat cat -> nhap D moi
;;;             -> ve lai CA COT do (mat dung + mat cat) va ve lai bang thong ke.
;;;             Dai: chon dai hoac so hieu dai -> doi D dai cua cac doan co so hieu do.
;;;   COTTK     Ve lai rieng bang thong ke tu du lieu an trong ban ve.
;;;
;;; CAN
;;;   - Ban ve do CotTools v9.6 xuat (co the an COLREBAR trong thep + the lien ket).
;;;   - Python 3 (tuy chon: chep Python embeddable vao thu muc  lib\python  cua extension).
;;;   - AutoCAD ban day du (dung COM/ActiveX). AutoCAD LT khong chay duoc lenh nay.
;;;   - Duong dan thu muc extension va thu muc %TEMP% nen la ASCII (khong dau).
;;; File chi chua ky tu ASCII.
;;; ===========================================================================
(vl-load-com)

(setq *COTSUA-APP* "COLREBAR")

;;; ---------------------------------------------------------------------------
;;; Ham tien ich
;;; ---------------------------------------------------------------------------
(defun cotsua:split (s ch / out p)
  (setq out nil)
  (while (setq p (vl-string-search ch s))
    (setq out (cons (substr s 1 p) out)
          s   (substr s (+ p 1 (strlen ch)))))
  (reverse (cons s out)))

(defun cotsua:xs (en / ed app out x)
  ;; danh sach chuoi XDATA (ma 1000) cua ung dung COLREBAR
  (setq ed (entget en (list *COTSUA-APP*))
        app (assoc -3 ed)
        out nil)
  (if app
    (foreach x (cdr (assoc *COTSUA-APP* (cdr app)))
      (if (= (car x) 1000) (setq out (cons (cdr x) out)))))
  (reverse out))

(defun cotsua:info (en / xs)
  ;; chuoi XDATA dau tien tach theo "|"  ->  ("BAR" "M=C1" "SH=3" ...)
  (setq xs (cotsua:xs en))
  (if xs (cotsua:split (car xs) "|")))

(defun cotsua:get (parts key / r x n)
  (setq n (strlen key) r nil)
  (foreach x (cdr parts)
    (if (and (null r) (> (strlen x) n) (= (substr x 1 n) key) (= (substr x (+ n 1) 1) "="))
      (setq r (substr x (+ n 2)))))
  r)

(defun cotsua:allss ()
  (ssget "X" (list (list -3 (list *COTSUA-APP*)))))

(defun cotsua:fwd (p) (vl-string-translate "\\" "/" p))
(defun cotsua:bwd (p) (vl-string-translate "/" "\\" p))

(defun cotsua:ascii-p (s / i ok)
  (setq i 1 ok T)
  (while (<= i (strlen s))
    (if (> (ascii (substr s i 1)) 127) (setq ok nil))
    (setq i (1+ i)))
  ok)

(defun cotsua:write-plain (path txt / f)
  ;; du phong: ghi ANSI (ten co dau tieng Viet co the sai, cot ten ASCII van dung)
  (setq f (open path "w"))
  (if f (progn (write-line txt f) (close f) T) nil))

(defun cotsua:write-utf8 (path txt / st r)
  ;; ghi file UTF-8 (ten cot / tang co dau tieng Viet khong bi hong); loi thi ghi du phong
  (setq r nil)
  (setq st (vl-catch-all-apply 'vlax-create-object (list "ADODB.Stream")))
  (if (not (vl-catch-all-error-p st))
    (progn
      (setq r (vl-catch-all-apply
                '(lambda ()
                   (vlax-put-property st 'Type 2)
                   (vlax-put-property st 'Charset "utf-8")
                   (vlax-invoke-method st 'Open)
                   (vlax-invoke-method st 'WriteText txt)
                   (vlax-invoke-method st 'SaveToFile path 2)
                   (vlax-invoke-method st 'Close)
                   T)
                nil))
      (vl-catch-all-apply 'vlax-release-object (list st))
      (setq r (if (vl-catch-all-error-p r) nil T))))
  (if (and r (findfile path))
    T
    (cotsua:write-plain path txt)))

(defun cotsua:home ( / h f)
  ;; thu muc lib cua CotTools (noi co run_rebuild.cmd). Tu tim; khong thay thi hoi 1 lan roi ghi nho (setenv).
  (setq h (getenv "COTTOOLS_HOME"))
  (if (and h (findfile (strcat (cotsua:fwd h) "/run_rebuild.cmd")))
    h
    (progn
      (setq h nil f (findfile "COLSUA.lsp"))
      (if f
        (progn
          (setq h (vl-filename-directory (vl-filename-directory f)))
          (if (not (findfile (strcat h "/run_rebuild.cmd"))) (setq h nil))))
      (if (null h)
        (progn
          (setq f (getfiled "Chon file run_rebuild.cmd (trong thu muc lib cua CotTools)" "" "cmd" 8))
          (if f (setq h (vl-filename-directory f)))))
      (if (and h (findfile (strcat h "/run_rebuild.cmd")))
        (progn (setenv "COTTOOLS_HOME" h) h)
        nil))))

(defun cotsua:read-result (path / f ln out)
  ;; result.txt (ASCII): tra ve danh sach dong
  (setq out nil)
  (if (findfile path)
    (progn
      (setq f (open path "r"))
      (while (setq ln (read-line f)) (setq out (cons ln out)))
      (close f)))
  (reverse out))

(defun cotsua:result-pt (lines tag / ln r p)
  ;; dong "TAG x y" -> (x y 0.0)
  (setq r nil)
  (foreach ln lines
    (if (and (null r) (= (substr ln 1 (1+ (strlen tag))) (strcat tag " ")))
      (progn
        (setq p (cotsua:split (substr ln (+ (strlen tag) 2)) " "))
        (setq r (list (atof (car p)) (atof (cadr p)) 0.0)))))
  r)

(defun cotsua:result-str (lines tag / ln r)
  (setq r nil)
  (foreach ln lines
    (if (and (null r) (= (substr ln 1 (1+ (strlen tag))) (strcat tag " ")))
      (setq r (substr ln (+ (strlen tag) 2)))))
  r)

;;; ---------------------------------------------------------------------------
;;; Gom doi tuong cua 1 cot (theo Mark)
;;; ---------------------------------------------------------------------------
(defun cotsua:collect (mark refpt / ss i en p head ents e best bd d cpt x0 y0 bars stirs objs ncols pt)
  ;; -> (cot bars stirs objs ncols)   cot = ename khoi tieu de cua BAN SAO gan refpt nhat
  ;; bars: ((SH D KEY) ..)  stirs: ((SH D SEG) ..)   Neu co nhieu ban sao cung Mark thi chi lay doi tuong nam trong khung cua ban do
  (setq ss (cotsua:allss) i 0 ncols 0)
  (while (and ss (< i (sslength ss)))
    (setq en (ssname ss i)
          i (1+ i)
          p (cotsua:info en))
    (if (and p (= (cotsua:get p "M") mark))
      (progn
        (setq pt (cdr (assoc 10 (entget en))))
        (setq ents (cons (list en (car p) p pt) ents))
        (if (= (car p) "COL") (setq ncols (1+ ncols))))))
  (setq best nil bd nil)
  (foreach e ents
    (if (and (= (cadr e) "COL") (cadddr e))
      (progn
        (setq d (distance (list (car refpt) (cadr refpt)) (list (car (cadddr e)) (cadr (cadddr e)))))
        (if (or (null best) (< d bd)) (setq best e bd d)))))
  (if best
    (progn
      (setq cpt (cadddr best)
            x0 (- (car cpt) 1900.0 100.0)
            y0 (- (cadr cpt) 400.0 400.0))
      (foreach e ents
        (setq pt (cadddr e))
        (if (or (< ncols 2)
                (and pt (>= (car pt) x0) (< (car pt) (+ x0 8000.0)) (>= (cadr pt) y0)))
          (progn
            (setq objs (cons (car e) objs))
            (cond
              ((= (cadr e) "BAR")
               (setq bars (cons (list (cotsua:get (caddr e) "SH") (cotsua:get (caddr e) "D") (cotsua:get (caddr e) "KEY")) bars)))
              ((= (cadr e) "STIR")
               (setq stirs (cons (list (cotsua:get (caddr e) "SH") (cotsua:get (caddr e) "D") (cotsua:get (caddr e) "SEG")) stirs)))))))))
  (list (if best (car best)) bars stirs objs ncols))

(defun cotsua:collect-tk (/ ss i en p objs)
  ;; cac doi tuong cua bang thong ke (the OBJ|T=TK)
  (setq ss (cotsua:allss) i 0)
  (while (and ss (< i (sslength ss)))
    (setq en (ssname ss i)
          i (1+ i)
          p (cotsua:info en))
    (if (and p (= (car p) "OBJ") (= (cotsua:get p "T") "TK"))
      (setq objs (cons en objs))))
  objs)

(defun cotsua:dump-text (target chosen extra / ss i en xs txt x p seen l)
  ;; chi thi (extra) + du lieu cac cot trong ban ve (dua cho rebuild.py). Moi Mark chi 1 lan; Mark dang sua dung ban sao 'chosen'
  (setq txt "" seen nil ss (cotsua:allss) i 0)
  (foreach l extra (setq txt (strcat txt l "\n")))
  (if target (setq txt (strcat txt "#TARGET " target "\n")))
  (if chosen
    (progn
      (setq xs (cotsua:xs chosen))
      (setq txt (strcat txt "#COL\n"))
      (foreach x xs (setq txt (strcat txt x "\n")))
      (setq seen (list target))))
  (while (and ss (< i (sslength ss)))
    (setq en (ssname ss i)
          i (1+ i)
          xs (cotsua:xs en))
    (if (and xs (>= (strlen (car xs)) 4) (= (substr (car xs) 1 4) "COL|"))
      (progn
        (setq p (cotsua:split (car xs) "|"))
        (if (not (member (cotsua:get p "M") seen))
          (progn
            (setq seen (cons (cotsua:get p "M") seen))
            (setq txt (strcat txt "#COL\n"))
            (foreach x xs (setq txt (strcat txt x "\n"))))))))
  txt)

(defun cotsua:tk-default ( / f path ln r p)
  ;; so dong toi da / phan bang thong ke dang dat trong tool (settings.json), mac dinh 40 neu khong doc duoc
  (setq r 40 path (strcat (getenv "APPDATA") "\\CotTools\\settings.json"))
  (if (findfile path)
    (progn
      (setq f (open path "r"))
      (while (setq ln (read-line f))
        (if (setq p (vl-string-search "table_rows" ln))
          (if (setq p (vl-string-search ":" ln p))
            (setq r (atoi (substr ln (+ p 2)))))))
      (close f)))
  (if (< r 5) 40 r))

(defun cotsua:seg-size (col seg / xs x p r)
  ;; "b x h" hien tai (chuoi) cua doan seg (so thu tu dang chuoi) tu XDATA cua khoi tieu de cot
  (setq r nil)
  (foreach x (cotsua:xs col)
    (if (and (null r) (> (strlen x) 4) (= (substr x 1 4) "SEG|"))
      (progn
        (setq p (cotsua:split x "|"))
        (if (= (nth 1 p) seg) (setq r (list (nth 5 p) (nth 6 p)))))))
  r)

(defun cotsua:parse-size (txt / t1 p a b)
  ;; "300x400" / "300*400" / "300 400" -> (300 400);  "400" -> (400 400);  loi -> nil
  (setq t1 (vl-string-translate "*XxX," "     " txt))
  (setq t1 (vl-string-trim " " t1))
  (setq p (vl-string-search " " t1))
  (cond
    ((null p) (if (> (atof t1) 0) (list (atof t1) (atof t1)) nil))
    (T (setq a (atof (substr t1 1 p))
             b (atof (vl-string-trim " " (substr t1 (+ p 2)))))
       (if (and (> a 0) (> b 0)) (list a b) nil))))

(defun cotsua:mark-exists (name / ss i p r)
  (setq ss (cotsua:allss) i 0 r nil)
  (while (and ss (< i (sslength ss)) (null r))
    (setq p (cotsua:info (ssname ss i)) i (1+ i))
    (if (and p (= (car p) "COL") (= (cotsua:get p "M") name)) (setq r T)))
  r)

(defun cotsua:insert-at (path pt / os ce iu r)
  (setq os (getvar "OSMODE") ce (getvar "CMDECHO") iu (getvar "INSUNITS"))
  (setvar "OSMODE" 0)
  (setvar "CMDECHO" 0)
  (setvar "INSUNITS" 0)
  (setq r (vl-catch-all-apply
            '(lambda ()
               (command "_.-INSERT" (strcat "*" (cotsua:fwd path)) pt 1.0 0.0)
               T)
            nil))
  (setvar "OSMODE" os)
  (setvar "CMDECHO" ce)
  (setvar "INSUNITS" iu)
  (not (vl-catch-all-error-p r)))

;;; ---------------------------------------------------------------------------
;;; Chay rebuild.py:  mark = ten cot hoac nil (chi ve lai bang);  keys = ("1.cont.0.0=22" ..)
;;; Tra ve thu muc ket qua neu OK, nil neu loi
;;; ---------------------------------------------------------------------------
(defun cotsua:run (mark chosen keys extra / home tmp outdir dump cmd sh k rc res)
  ;; mark = ten cot hoac nil (chi ve lai bang); keys = ("1.cont.0.0=22" ..); extra = dong chi thi ("#RENAME x" "#SL 3")
  (setq home (cotsua:home)
        tmp  (getenv "TEMP"))
  (cond
    ((null home)
     (princ "\nKhong tim thay run_rebuild.cmd. Chon file run_rebuild.cmd trong thu muc lib cua CotTools khi duoc hoi.")
     nil)
    ((null tmp) (princ "\nKhong co bien TEMP.") nil)
    (T
     (if (not (and (cotsua:ascii-p home) (cotsua:ascii-p tmp)))
       (princ "\nCanh bao: duong dan co dau/khong ASCII -> Python co the khong doc duoc. Neu loi, dua extension ra thu muc khong dau."))
     (setq outdir (strcat (cotsua:bwd tmp) "\\CotTools_sua")
           dump   (strcat outdir "\\dump.txt"))
     (vl-mkdir outdir)
     (if (not (cotsua:write-utf8 dump (cotsua:dump-text mark chosen extra)))
       (progn (princ "\nKhong ghi duoc file tam.") nil)
       (progn
         (setq cmd (strcat "cmd /c \"\"" (cotsua:bwd home) "\\run_rebuild.cmd\" \"" dump "\" \"" outdir "\" \""
                           (if mark "@" "-") "\""))
         (foreach k keys (setq cmd (strcat cmd " " k)))
         (setq cmd (strcat cmd "\""))
         (princ "\nDang ve lai (Python)... ")
         (setq sh (vl-catch-all-apply 'vlax-create-object (list "WScript.Shell")))
         (if (vl-catch-all-error-p sh)
           (progn (princ "\nKhong tao duoc WScript.Shell.") nil)
           (progn
             (setq rc (vl-catch-all-apply 'vlax-invoke-method (list sh 'Run cmd 0 :vlax-true)))
             (vl-catch-all-apply 'vlax-release-object (list sh))
             (setq res (cotsua:read-result (strcat outdir "\\result.txt")))
             (if (and res (= (car res) "OK"))
               outdir
               (progn
                 (princ (strcat "\nLOI khi ve lai" (if (cotsua:result-str res "MSG") (strcat ": " (cotsua:result-str res "MSG")) "")
                                ". Chi tiet: " outdir "\\log.txt"))
                 nil)))))))))

(defun cotsua:erase-ss (ss / i)
  (setq i 0)
  (while (and ss (< i (sslength ss)))
    (entdel (ssname ss i))
    (setq i (1+ i))))

(defun cotsua:replace-table (outdir res interactive / old en ed frame v n ss i pt ok)
  ;; Thay bang thong ke cu bang ban moi. Bang co the lien ket (OBJ|T=TK) thi tu thay; khong co thi (interactive) hoi chon bang cu / diem chen.
  (setq old (cotsua:collect-tk) frame nil n 0)
  (foreach en old
    (setq ed (entget en))
    (if (and (= (cdr (assoc 0 ed)) "LWPOLYLINE")
             (= (strcase (cdr (assoc 8 ed))) "DEFPOINTS"))
      (progn (setq n (1+ n)) (if (null frame) (setq frame (cdr (assoc 10 ed)))))))
  (setq v (cotsua:result-pt res "TK_ANCHOR"))
  (cond
    ((and old frame (= n 1))
     (if (cotsua:insert-at (strcat outdir "\\tk.dxf")
                           (list (- (car frame) (car v)) (- (cadr frame) (cadr v)) 0.0))
       (progn (foreach en old (entdel en)) T)           ; chen duoc ban moi roi moi xoa bang cu
       nil))
    ((not interactive)
     (princ "\n(Bang thong ke chua duoc cap nhat: ban ve chua co bang lien ket / co nhieu bang. Dung lenh COTTK de chon bang can thay.)")
     nil)
    (T
     (princ "\nChua co bang thong ke lien ket. Chon (window) TOAN BO bang thong ke cu de THAY, hoac Enter de chen bang moi.")
     (setq ss (ssget) frame nil i 0)
     (while (and ss (< i (sslength ss)))
       (setq en (ssname ss i) i (1+ i) ed (entget en))
       (if (and (null frame)
                (= (cdr (assoc 0 ed)) "LWPOLYLINE")
                (= (strcase (cdr (assoc 8 ed))) "DEFPOINTS"))
         (setq frame (cdr (assoc 10 ed)))))
     (setq pt (if frame
                (list (- (car frame) (car v)) (- (cadr frame) (cadr v)) 0.0)
                (getpoint (if ss "\nKhong thay khung bang cu - chon diem chen bang moi (bang cu trong vung chon se bi xoa): "
                                 "\nChon diem chen bang thong ke moi: "))))
     (if pt
       (progn
         (setq ok (cotsua:insert-at (strcat outdir "\\tk.dxf") pt))
         (if (and ok ss) (cotsua:erase-ss ss))
         ok)
       nil))))

(defun cotsua:apply (mark col objs keys extra msg / outdir res anc oldpt nobj ok x)
  ;; chay Python, chen cot moi, xoa cot cu, cap nhat bang thong ke
  (princ (strcat "\n[1] Cot " mark ": " (itoa (length objs)) " doi tuong, sua " msg))
  (setq oldpt (cdr (assoc 10 (entget col))))
  (setq outdir (cotsua:run mark col keys extra))
  (princ (strcat "\n[2] Python: " (if outdir "OK" "LOI (xem thong bao tren)")))
  (if outdir
    (progn
      (setq res (cotsua:read-result (strcat outdir "\\result.txt"))
            anc (cotsua:result-pt res "COL_ANCHOR"))
      (if (or (null anc) (null (findfile (strcat outdir "\\col.dxf"))))
        (princ "\nKet qua ve lai khong day du - giu nguyen ban ve cu.")
        (progn
          (command "_.UNDO" "_BEGIN")
          (setq nobj (length objs))
          ;; chen cot moi TRUOC, thanh cong moi xoa cot cu (loi thi ban ve giu nguyen)
          (setq ok (cotsua:insert-at (strcat outdir "\\col.dxf")
                        (list (- (car oldpt) (car anc)) (- (cadr oldpt) (cadr anc)) 0.0)))
          (princ (strcat "\n[3] Chen ban ve cot moi: " (if ok "OK" "LOI - giu nguyen ban ve cu")))
          (if ok
            (progn
              (foreach x objs (entdel x))
              (princ (strcat "\n[4] Da xoa " (itoa nobj) " doi tuong cu"))
              (setq ok (cotsua:replace-table outdir res nil))
              (princ (strcat "\n[5] Cap nhat bang thong ke: " (if ok "OK" "chua (dung COTTK)")))
              (princ (strcat "\nDa sua " msg ", ve lai mat dung + mat cat"
                             (if (cotsua:result-str res "KG") (strcat ", tong thep " (cotsua:result-str res "KG") " kg") "")
                             ". (Ctrl+Z de hoan tac)"))))
          (command "_.UNDO" "_END")))))
  T)

(defun c:COTSUA ( / sel en p mark sh tp data col bars stirs objs ncols refpt d0 keys segs s b k
                   nm ns nsh nd nsz sz cur sl0 key0 extra kk msg go ln)
  ;; Click 1 o thep / so hieu / chi tiet cua cot -> nhap tung muc (Enter = giu nguyen):
  ;; ten cot, so cau kien, so hieu thep, duong kinh, kich thuoc tiet dien
  (setq sel (entsel "\nChon thep, so hieu thep hoac chi tiet cua cot can sua (mat dung hoac mat cat): "))
  (cond
    ((null sel) nil)
    (T
     (setq en (car sel)
           p  (cotsua:info en))
     (cond
       ((or (null p) (null (cotsua:get p "M")))
        (princ "\nDoi tuong nay khong thuoc cot do tool ve (khong co the lien ket)."))
       (T
        (setq mark (cotsua:get p "M")
              sh   (cotsua:get p "SH")
              tp   (cond ((= (car p) "STIR") "S")
                         ((= (car p) "BAR") "B")
                         (T (cotsua:get p "TP"))))
        (setq refpt (if (cadr sel) (cadr sel) (cdr (assoc 10 (entget en)))))
        (setq data  (cotsua:collect mark refpt)
              col   (nth 0 data)
              bars  (nth 1 data)
              stirs (nth 2 data)
              objs  (nth 3 data)
              ncols (nth 4 data))
        (cond
          ((null col) (princ (strcat "\nKhong thay khoi tieu de cot " mark " (ban ve cu hoac da bi xoa).")))
          (T
           (if (> ncols 1)
             (princ (strcat "\n(Co " (itoa ncols) " ban sao cung Mark - chi sua ban sao gan diem vua click.)")))
           (setq go T keys nil segs nil d0 nil extra nil msg "" key0 nil)
           ;; ---- thep dang chon: cac khoa nhom + doan (neu click vao thep / so hieu)
           (if sh
             (progn
               (if (= tp "S")
                 (foreach s stirs
                   (if (= (car s) sh)
                     (progn (if (null d0) (setq d0 (atoi (cadr s))))
                            (setq keys (cons (strcat "S." (caddr s)) keys))
                            (if (not (member (caddr s) segs)) (setq segs (cons (caddr s) segs))))))
                 (foreach b bars
                   (if (and (= (car b) sh) (caddr b))
                     (progn (if (null d0) (setq d0 (atoi (cadr b))))
                            (setq keys (cons (caddr b) keys))
                            (setq k (car (cotsua:split (caddr b) ".")))
                            (if (not (member k segs)) (setq segs (cons k segs)))))))
               (if (or (null keys) (null d0))
                 (progn
                   (princ "\nKhong tra duoc so hieu nay (ban ve cu, chua co khoa lien ket) - chi sua duoc ten cot / so cau kien.")
                   (setq sh nil keys nil segs nil)))))
           (princ (strcat "\n--- Sua cot " mark (if sh (strcat ", so hieu " sh) "") " (Enter = giu nguyen) ---"))
           ;; ---- ten cot
           (setq nm (getstring T (strcat "\nTen cot <" mark ">: ")))
           (cond
             ((or (null nm) (= nm "") (= nm mark)) (setq nm nil))
             ((or (vl-string-search "|" nm) (vl-string-search "=" nm))
              (princ "\nTen khong duoc chua ky tu | hoac = - giu ten cu.") (setq nm nil))
             ((cotsua:mark-exists nm)
              (princ "\nTen nay da co cot khac dung - giu ten cu.") (setq nm nil))
             (T (setq extra (cons (strcat "#RENAME " nm) extra)
                      msg (strcat msg " [ten " mark "->" nm "]"))))
           ;; ---- so cau kien
           (setq sl0 (cotsua:get (cotsua:info col) "SL"))
           (setq ns (getint (strcat "\nSo cau kien <" (if sl0 sl0 "1") ">: ")))
           (if (and ns (>= ns 1) (/= (itoa ns) sl0))
             (setq extra (cons (strcat "#SL " (itoa ns)) extra)
                   msg (strcat msg " [SL " (itoa ns) "]")))
           ;; ---- cac muc cua thep dang chon
           (if sh
             (progn
               (setq nsh (getint (strcat "\nSo hieu thep <" sh ">: ")))
               (if (and nsh (>= nsh 1) (/= nsh (atoi sh)))
                 (progn
                   (foreach kk keys (setq ln (cons (strcat "SH." kk "=" (itoa nsh)) ln)))
                   (setq msg (strcat msg " [so hieu " sh "->" (itoa nsh) "]"))))
               (setq nd (getint (strcat "\nDuong kinh D <" (itoa d0) ">: ")))
               (if (and nd (>= nd 4) (<= nd 50) (/= nd d0))
                 (progn
                   (foreach kk keys (setq ln (cons (strcat kk "=" (itoa nd)) ln)))
                   (setq msg (strcat msg " [D" (itoa d0) "->D" (itoa nd) "]"))))
               (setq cur (cotsua:seg-size col (car segs)))
               (setq nsz (getstring T (strcat "\nKich thuoc tiet dien b x h cua doan " (car segs)
                                             " <" (if cur (strcat (car cur) "x" (cadr cur)) "?") ">: ")))
               (if (and nsz (/= nsz ""))
                 (progn
                   (setq sz (cotsua:parse-size nsz))
                   (if (null sz)
                     (princ "\nKich thuoc khong hop le (vi du 300x400) - giu nguyen.")
                     (progn
                       (foreach s segs
                         (setq ln (cons (strcat "BW." s "=" (itoa (fix (+ 0.5 (car sz))))) ln))
                         (setq ln (cons (strcat "BH." s "=" (itoa (fix (+ 0.5 (cadr sz))))) ln)))
                       (setq msg (strcat msg " [kich thuoc " nsz "]"))))))))
           (setq keys ln)
           (if (and (null extra) (null keys))
             (princ "\nKhong doi gi.")
             (cotsua:apply mark col objs keys extra msg))))))))
  (princ))

;;; ---------------------------------------------------------------------------
;;; COTTK  - thong ke cot: TAT CA hoac chi nhung cot ban chon
;;; ---------------------------------------------------------------------------
(defun cotsua:marks-of (ss / i p m out)
  ;; cac Mark (khong trung) cua nhung doi tuong da chon
  (setq i 0 out nil)
  (while (and ss (< i (sslength ss)))
    (setq p (cotsua:info (ssname ss i)) i (1+ i))
    (if p
      (progn
        (setq m (cotsua:get p "M"))
        (if (and m (not (member m out))) (setq out (cons m out))))))
  (reverse out))

(defun c:COTTK ( / mode ss marks extra newtab outdir res sk pt ok m def nr)
  (initget "T C")
  (setq mode (getkword "\nThong ke [T=tat ca cot trong ban ve/C=chi cac cot toi chon] <T>: "))
  (if (null mode) (setq mode "T"))
  (setq extra nil newtab nil)
  (cond
    ((= mode "C")
     (princ "\nChon cac cot can thong ke (window / click, chon duoc nhieu cot): ")
     (setq ss (ssget (list (list -3 (list *COTSUA-APP*)))))
     (setq marks (if ss (cotsua:marks-of ss) nil))
     (cond
       ((null marks) (princ "\nKhong chon duoc cot nao do tool ve - huy.") (setq mode nil))
       (T
        (princ (strcat "\nDa chon " (itoa (length marks)) " cot: "))
        (foreach m marks (princ (strcat m "  ")))
        (foreach m marks (setq extra (cons (strcat "#ONLY " m) extra)))
        (initget "B M")
        (setq newtab (getkword "\nBang ket qua [B=thay bang thong ke cu/M=chen BANG MOI rieng, giu bang cu] <M>: "))
        (if (or (null newtab) (= newtab "M"))
          (setq newtab T extra (cons "#NOTAG 1" extra))
          (setq newtab nil)))))
    (T nil))
  (if mode
    (progn
      ;; so dong thong ke toi da moi phan bang (cat phan); mac dinh = so dang dat trong tool
      (setq def (cotsua:tk-default))
      (setq nr (getint (strcat "\nSo dong thong ke toi da moi phan bang - cat phan <" (itoa def) ">: ")))
      (if (or (null nr) (< nr 5)) (setq nr def))
      (setq extra (cons (strcat "#ROWS " (itoa nr)) extra))
      (setq outdir (cotsua:run nil nil nil extra))
      (if outdir
        (progn
          (setq res (cotsua:read-result (strcat outdir "\\result.txt")))
          (command "_.UNDO" "_BEGIN")
          (if newtab
            (progn
              (setq pt (getpoint "\nChon diem chen bang thong ke moi: "))
              (setq ok (if pt (cotsua:insert-at (strcat outdir "\\tk.dxf") pt) nil)))
            (setq ok (cotsua:replace-table outdir res T)))
          (if ok
            (princ (strcat "\nDa thong ke " (if (= mode "C") "cac cot da chon" "tat ca cot") ", tong thep " (cotsua:result-str res "KG") " kg."))
            (princ "\nBang thong ke chua duoc ve / thay."))
          (command "_.UNDO" "_END")
          (setq sk (cotsua:result-str res "SKIP"))
          (if (and sk (> (atoi sk) 0))
            (princ (strcat "\nCHU Y: " sk " cot tu ban ve cu (chua co du lieu v9.6) KHONG duoc tinh vao bang - xuat lai tu Revit. Chi tiet: " outdir "\\log.txt")))))))
  (princ))

(princ "\nCOLSUA da nap. COTSUA: sua duong kinh / so hieu thep / ten cot / so cau kien (cot + bang tu cap nhat). COTTK: quet lai toan bo cot, ve lai bang thong ke.")
(princ)
