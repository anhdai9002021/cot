# -*- coding: utf-8 -*-
"""
rebuild.py  -  vẽ lại 1 cột (mặt đứng + mặt cắt) và bảng thống kê từ DỮ LIỆU ẨN trong bản vẽ AutoCAD.
Được lệnh COTSUA (COLSUA.lsp) gọi; KHÔNG cần Revit, không cần Excel, chỉ dùng thư viện chuẩn của Python 3.

    python rebuild.py dump.txt outdir  Mark  [khoá=số ...]

dump.txt : do AutoCAD ghi, mỗi cột bắt đầu bằng dòng "#COL", tiếp theo là các chuỗi XDATA (COL|..., SEG|..., CFG|..., OV|...)
outdir   : thư mục ghi kết quả
Mark     : cột cần vẽ lại ("-" = chỉ vẽ lại bảng thống kê, "@" = lấy Mark từ dòng "#TARGET <Mark>" trong dump.txt)
khoá=số  : Ø theo số hiệu: nhóm thép dọc "đoạn.loại.hàng.bổ_sung" (vd 1.cont.0.0), đai "S.đoạn" (vd S.2);
           số hiệu thủ công: "SH.<khoá>" (vd SH.1.cont.0.0=5, SH.S.2=7)
dump.txt có thể có thêm dòng đầu'#ROWS n' (số dòng tối đa / phần bảng), '#RENAME Tên mới' (đổi tên cột), '#SL n' (số cấu kiện),
'#ONLY Mark' (nhiều dòng: chỉ thống kê các cột này), '#NOTAG 1' (bảng riêng, không tự thay khi sửa cột)

Kết quả trong outdir:
    col.dxf     cột đã vẽ lại (toạ độ cục bộ);  tk.dxf  bảng thống kê (nếu có)
    result.txt  dòng "OK", "COL_ANCHOR x y", "TK_ANCHOR x y", "KG ...", "WARN n"  (chỉ ASCII)
    log.txt     nhật ký / lỗi
"""
import os
import re
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import excel_to_dxf as E          # noqa: E402
import thong_ke_thep as T         # noqa: E402
import bang_thong_ke as BT        # noqa: E402

TEMPLATE = os.path.join(HERE, "data", "C3.dxf")
COL_ANCHOR_LOCAL = (1900.0, 400.0)      # điểm chèn khối tiêu đề cột trong bản vẽ cục bộ (excel_to_dxf.draw_column)
TK_FRAME_LOCAL = (-125.0, 125.0)        # đỉnh đầu của khung Defpoints bảng thống kê (bang_thong_ke.generate)


def ascii_text(t):
    """Bỏ dấu tiếng Việt để AutoCAD (ANSI) in được thông báo lỗi."""
    import unicodedata
    t = t.replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in unicodedata.normalize("NFD", t) if unicodedata.category(c) != "Mn").encode("ascii", "replace").decode("ascii")


def decode_acad(t):
    """AutoCAD đời cũ trả chuỗi Unicode dạng \\U+1EA7; AutoCAD mới trả thẳng ký tự."""
    return re.sub(r"\\U\+([0-9A-Fa-f]{4})", lambda m: chr(int(m.group(1), 16)), t)


def parse_dump(path):
    """-> [ dict(M, SL, Z0, HM, NEO, segs=[...], cfg={...}, ov={...}) ]"""
    with open(path, "r", encoding="utf-8-sig", errors="replace") as f:
        lines = [decode_acad(x.rstrip("\r\n")) for x in f]
    blocks, cur = [], None
    for ln in lines:
        if ln.strip() == "#COL":
            cur = []
            blocks.append(cur)
        elif cur is not None and ln.strip():
            cur.append(ln.strip())
    cols = []
    for bl in blocks:
        head = bl[0].split("|")
        if head[0] != "COL":
            continue
        info = T.kv(head)
        c = dict(M=info["M"], SL=info.get("SL", "1"), Z0=float(info.get("Z0", "0")),
                 HM=float(info.get("HM", "600")), NEO=float(info.get("NEO", "400")),
                 segs=[], cfg={}, ov={}, old=True)
        for ln in bl[1:]:
            p = ln.split("|")
            if p[0] == "SEG":
                c["segs"].append(p)
            elif p[0] in ("CFG", "CFG2"):
                c["cfg"].update(T.kv(p))
                c["old"] = False
            elif p[0] == "OV" and len(p) >= 3:
                try:
                    c["ov"][p[1]] = int(float(p[2]))
                except ValueError:
                    pass
        cols.append(c)
    return cols


def read_directives(dump):
    """Dòng chỉ thị đầu dump.txt: '#TARGET Mark', '#RENAME TênMới', '#SL SốCấuKiện'."""
    d = {}
    with open(dump, "r", encoding="utf-8-sig", errors="replace") as f:
        for ln in f:
            ln = ln.rstrip("\r\n")
            if ln.startswith("#COL"):
                break
            if ln.startswith("#ONLY "):                    # chỉ thống kê các cột này (có thể nhiều dòng)
                d.setdefault("ONLY", []).append(decode_acad(ln[6:].strip()))
                continue
            for tag in ("#TARGET ", "#RENAME ", "#SL ", "#NOTAG ", "#ROWS "):
                if ln.startswith(tag):
                    d[tag.strip()[1:]] = decode_acad(ln[len(tag):].strip())
    return d


def make_segs(c, extra_ov):
    """Dựng lại danh sách Seg của cột từ XDATA (không qua Excel / Revit)."""
    ov = dict(c["ov"])
    ov.update(extra_ov)
    segs = []
    for i, p in enumerate(c["segs"]):
        s = E.Seg()
        s.row = int(p[13]) if len(p) > 13 and p[13].lstrip("-").isdigit() else 0
        s.mark = c["M"]
        s.n_from, s.n_to = p[2], p[3]
        s.H = float(p[4])
        s.b, s.h = float(p[5]), float(p[6])
        s.nb, s.nh = int(p[7]), int(p[8])
        s.dia = int(p[9])
        stir = p[10]
        s.spiral = stir[:1].upper() == "S"
        s.stir = E.parse_stirrup(stir)
        s.R = float(p[11])
        s.beam = E.parse_pair(p[12], (200.0, 0.0))
        s.round = len(p) > 14 and p[14] == "C"
        s.has_beam = (p[15] == "1") if len(p) > 15 else (s.R != 100.0)
        s.slant = float(p[17]) if len(p) > 17 else 0.0
        hz = float(p[16]) if len(p) > 16 else 0.0
        s.Hz = hz if (hz and s.slant) else None
        if i == 0:
            s.x = c["Z0"]
            s.base = "%g/%g" % (c["HM"], c["NEO"])
            s.sl = c["SL"]
            s.ov = ov
        segs.append(s)
    return segs


CFG_FLOAT = ("LAP_K", "HOOK", "JOG", "JOG_X", "TOP_COVER", "COVER", "BAR_INSET", "DENSE_DIV", "ROUND_STEP",
             "STIRRUP_END", "MIN_MID", "ADD_ANCHOR_K", "SPIRAL_END_TURNS", "STIR_HOOK_K", "HEAD_ANCHOR_K",
             "THRU_MIN_LEN")


def apply_cfg(c):
    """Đưa cấu hình vẽ đã lưu trong bản vẽ vào bộ vẽ (để vẽ lại giống hệt lần đầu)."""
    for k in CFG_FLOAT:
        if k in c["cfg"]:
            setattr(E, k, float(c["cfg"][k]))
    if "ROUND_MODE" in c["cfg"]:
        E.ROUND_MODE = c["cfg"]["ROUND_MODE"]
    if "BASE_SPLICE" in c["cfg"]:
        E.BASE_SPLICE = c["cfg"]["BASE_SPLICE"] == "1"
    if "TOP_THROUGH" in c["cfg"]:
        E.TOP_THROUGH = c["cfg"]["TOP_THROUGH"] == "1"


def nat_key(s):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", str(s))]


def insert_point_of_col(dxf):
    """Điểm chèn (x, y) của khối tiêu đề cột (INSERT có XDATA COL) trong file DXF vừa vẽ."""
    for ent in T.entities(T.read_pairs(dxf)):
        if ent[0][1] == "INSERT":
            xs = T.xdata(ent)
            if xs and xs[0].startswith("COL|"):
                x = next(float(v) for c_, v in ent if c_ == 10)
                y = next(float(v) for c_, v in ent if c_ == 20)
                return x, y
    return COL_ANCHOR_LOCAL


def draw_one(c, extra_ov, out, warns):
    apply_cfg(c)
    segs = make_segs(c, extra_ov)
    E.generate_columns([(c["M"], segs)], TEMPLATE, out, True, warns)


def main(argv):
    if len(argv) < 4:
        sys.exit(__doc__)
    dump, outdir, mark = argv[1], argv[2], argv[3]
    extra = {}
    for a in argv[4:]:
        if "=" in a:
            k, v = a.split("=", 1)
            extra[k.strip()] = int(float(v))
    os.makedirs(outdir, exist_ok=True)
    res = os.path.join(outdir, "result.txt")
    logp = os.path.join(outdir, "log.txt")
    for f in (res, logp):
        if os.path.isfile(f):
            os.remove(f)
    lines = []
    try:
        dirs = read_directives(dump)
        if mark == "@":
            mark = dirs.get("TARGET", "-")
        cols = parse_dump(dump)
        if not cols:
            raise ValueError("Khong doc duoc cot nao trong dump")
        cols.sort(key=lambda c: nat_key(c["M"]))
        warns = []
        target = None
        if mark != "-":
            target = next((c for c in cols if c["M"] == mark), None)
            if target is None:
                raise ValueError("Khong thay cot %s" % mark)
            if target["old"]:
                raise ValueError("Ban ve cu (chua co cau hinh luu trong cot): ve lai tu Revit bang CotTools v9.6")
            if dirs.get("RENAME"):                      # đổi tên cột (Mark)
                newm = dirs["RENAME"].replace("|", "/").replace("=", "-").strip()
                if not newm:
                    raise ValueError("Ten cot moi rong")
                if any(c is not target and c["M"] == newm for c in cols):
                    raise ValueError("Ten cot moi trung voi cot khac: %s" % newm)
                target["M"] = newm
            if dirs.get("SL"):                          # đổi số cấu kiện
                target["SL"] = str(int(float(dirs["SL"])))
            col_dxf = os.path.join(outdir, "col.dxf")
            draw_one(target, extra, col_dxf, warns)
            ax, ay = insert_point_of_col(col_dxf)
            lines.append("COL_ANCHOR %r %r" % (ax, ay))
            # cột đã đổi Ø: dùng chính dữ liệu mới cho bảng thống kê
            target["ov"].update(extra)
        # ---- bảng thống kê: vẽ lại TOÀN BỘ cột (mỗi cột 1 file tạm) rồi đọc ngược như khi vẽ lần đầu
        scan_cols, scan_bars, scan_stirs = {}, [], []
        skipped = []
        only = set(dirs.get("ONLY") or [])
        table_cols = [c for c in cols if (not only) or c["M"] in only]
        if only and not table_cols:
            raise ValueError("Khong co cot nao trong danh sach chon")
        for c in table_cols:
            if c["old"]:
                skipped.append(c["M"])
                continue
            tmp = os.path.join(outdir, "_tmp_%d.dxf" % len(scan_cols))
            draw_one(c, {}, tmp, [])
            cs, bs, ss = T.scan(tmp)
            scan_cols.update(cs)
            scan_bars += bs
            scan_stirs += ss
            os.remove(tmp)
        stat, _by = T.compute(scan_cols, scan_bars, scan_stirs)
        kg = sum(r["doc"] + r["dai"] + r["noi"] for r in stat)
        try:
            import colcore as C
            st = C.load_settings()
            C.apply_table_settings(BT, st)
            nrows = int(st.get("table_rows", 40))
        except Exception:
            nrows = BT.MAX_ROWS
        if dirs.get("ROWS"):                              # số dòng tối đa / phần bảng (cắt phần) do người dùng nhập
            nrows = max(5, int(float(dirs["ROWS"])))
        apply_cfg(table_cols[0] if table_cols else cols[0])
        if not scan_cols:
            raise ValueError("Khong co cot v9.6 nao de thong ke (cot ban ve cu bi bo qua)")
        info = BT.generate(None, os.path.join(outdir, "tk.dxf"), max_rows=nrows,
                           scan=(scan_cols, scan_bars, scan_stirs), tag=("TKX" if dirs.get("NOTAG") else "TK"))
        lines.append("TK_ANCHOR %r %r" % TK_FRAME_LOCAL)
        lines.append("KG %.2f" % kg)
        lines.append("TKROWS %d" % info["rows"])
        lines.append("WARN %d" % len(warns))
        lines.append("SKIP %d" % len(skipped))
        lines.append("NEWMARK %d" % (1 if (mark != "-" and dirs.get("RENAME")) else 0))
        with open(logp, "w", encoding="utf-8") as f:
            f.write("\n".join(warns))
            if skipped:
                f.write("\nCot ban ve cu (chua co du lieu v9.6) bi bo qua trong bang: " + ", ".join(skipped))
        with open(res, "w", encoding="ascii") as f:
            f.write("OK\n" + "\n".join(lines) + "\n")
    except Exception as ex:
        with open(logp, "w", encoding="utf-8") as f:
            f.write(traceback.format_exc())
        with open(res, "w", encoding="ascii") as f:
            f.write("ERR\nMSG %s\n" % ascii_text(str(ex)))
        print("LOI:", ex)
        sys.exit(1)


if __name__ == "__main__":
    main(sys.argv)
