# -*- coding: utf-8 -*-
"""
Bảng THỐNG KÊ CỐT THÉP (DXF) theo mẫu  data/mau_thong_ke.dxf  (mẫu_thép_tk.dxf).

    python bang_thong_ke.py COT.dxf THONG_KE.dxf

Đầu vào : file DXF cột do excel_to_dxf.py sinh ra (đọc dữ liệu ẩn COLREBAR qua thong_ke_thep.scan)
Đầu ra  : DXF gồm  [BẢNG THỐNG KÊ] (1 hay nhiều phần) + [TỔNG HỢP CỐT THÉP]

Quy tắc:
- Mỗi dòng thống kê = 1 số hiệu thép (SH) của 1 cột.  Thanh thẳng -> block TK1, thanh có 2 móc cùng phía -> TK4,
  hình khác (L, Z, có đoạn gãy, đai kín) -> TKTUnknown + hình vẽ tay, chiều dài ghi bằng CHỮ (không dùng dim).
- Mỗi phần tối đa MAX_ROWS (=40) dòng thống kê. Ô TỔNG HỢP CỐT THÉP KHÔNG tính vào 40 dòng.
  Dài hơn 40 dòng thì tự ngắt thành 2, 3, 4... phần đặt cạnh nhau; ô tổng hợp gắn dưới phần cuối.
- Không cần ezdxf: ghi DXF thô như excel_to_dxf.py (giữ HEADER / TABLES / BLOCKS của file mẫu).
"""
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import excel_to_dxf as E
import thong_ke_thep as T

TEMPLATE = os.path.join(HERE, "data", "mau_thong_ke.dxf")

# ------------------------------------------------------------------ THAM SỐ (đơn vị mm trên bản vẽ)
MAX_ROWS = 40              # số dòng thống kê tối đa trong 1 phần (không tính ô tổng hợp)
U = 50.0                   # tỉ lệ block mẫu
TABLE_W = 192.5 * U        # bề rộng bảng
TITLE_H = 35.0 * U         # chiều cao khối tiêu đề (TKTitle)
ROW_H = 8.0 * U            # dòng thường (TK1 / TK4 / TK7 / TK8)
ROW_H_UNK = 13.5 * U       # dòng hình tự vẽ (TKTUnknown)
NAME_W = 15.0 * U          # cột TÊN CẤU KIỆN
PART_GAP = 1000.0          # khoảng cách giữa các phần khi ngắt bảng
BAR_STD = 11.7             # chiều dài cây thép tiêu chuẩn (m)
COIL_MAX_D = 8             # Ø <= giá trị này coi là thép cuộn (không chia 11.7)
SK_X0, SK_X1 = 25.0 * U, 75.0 * U      # cột "HÌNH DẠNG, KÍCH THƯỚC"
SUM_C0, SUM_CW = 1900.0, 1100.0        # ô tổng hợp: cột nhãn / cột Ø
SUM_ROW = 400.0
SUM_TITLE_H = 600.0
GRP_W = 4100.0
TXT_LAYER, TXT_STYLE, TXT_H = "Dce_text", "Dce_Text2", 100.0
LINE_LAYER = "DCE_Lanh_To"


# ------------------------------------------------------------------ đọc dữ liệu từ DXF cột
def _dedupe(pts):
    out = []
    for p in pts:
        if not out or abs(p[0] - out[-1][0]) > 1e-6 or abs(p[1] - out[-1][1]) > 1e-6:
            out.append(p)
    return out


def _classify(pts):
    """Trả (kiểu, L1, L2, L3). kiểu: 'TK1' thẳng | 'TK4' 2 móc cùng phía | 'UNK' hình khác."""
    pts = _dedupe(pts)
    if len(pts) == 2:
        L = math.hypot(pts[1][0] - pts[0][0], pts[1][1] - pts[0][1])
        return "TK1", 0.0, L, 0.0
    if len(pts) == 4:
        v = [(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]) for i in range(3)]
        ln = [math.hypot(*a) for a in v]
        if min(ln) > 1e-6:
            perp1 = abs(v[0][0] * v[1][0] + v[0][1] * v[1][1]) / (ln[0] * ln[1]) < 0.05
            perp2 = abs(v[1][0] * v[2][0] + v[1][1] * v[2][1]) / (ln[1] * ln[2]) < 0.05
            anti = (v[0][0] * v[2][0] + v[0][1] * v[2][1]) < 0
            if perp1 and perp2 and anti:
                return "TK4", ln[0], ln[1], ln[2]
    return "UNK", 0.0, 0.0, 0.0


def collect(dxf_path):
    """-> [ {mark, skc, rows:[...]} ]  (mỗi row 1 số hiệu thép, đã có sumL / SL / TSL / Lall / KL)."""
    return collect_scan(*T.scan(dxf_path))


def collect_scan(cols, bars, stirs):
    """Như collect() nhưng nhận sẵn kết quả thong_ke_thep.scan (dùng khi gộp nhiều cột / vẽ lại bảng từ AutoCAD)."""
    groups = {}
    for m, info in cols.items():
        groups[m] = dict(mark=m, skc=max(int(round(info["SL"])), 1), rows={})
    for b in bars:
        g = groups.get(b["M"])
        if g is None:
            continue
        kind, l1, l2, l3 = _classify(b["V"])
        r = g["rows"].setdefault(b["SH"], dict(sh=b["SH"], d=b["D"], n=0, kind=kind, l1=l1, l2=l2, l3=l3,
                                               sumL=b["L"], pts=b["V"], closed=False))
        r["n"] += b["N"]
    for s in stirs:
        g = groups.get(s["M"])
        if g is None:
            continue
        seg = next((x for x in cols[s["M"]]["segs"] if x["k"] == s["SEG"]), None)
        r = g["rows"].setdefault(s["SH"], dict(sh=s["SH"], d=s["D"], n=0, kind="UNK", l1=0.0, l2=0.0, l3=0.0,
                                               sumL=s["L"], pts=None, closed=True,
                                               round=bool(seg and seg.get("round")), spiral=bool(s.get("SP")),
                                               bw=(seg["b"] - 2 * E.COVER) if seg else 0.0,
                                               bh=(seg["h"] - 2 * E.COVER) if seg else 0.0,
                                               hook=E.STIR_HOOK_K * s["D"]))
        r["n"] += s["NUM"]
    out = []
    for m, g in groups.items():
        rows = []
        for sh in sorted(g["rows"]):
            r = g["rows"][sh]
            exact = r["sumL"]                       # tính khối lượng theo chiều dài thật -> khớp bảng Excel
            r["sumL"] = int(round(exact))           # chỉ làm tròn khi hiển thị
            r["tsl"] = r["n"] * g["skc"]
            r["lall"] = exact * r["tsl"] / 1000.0
            r["kl"] = r["lall"] * T.wt(r["d"])
            r["mark"], r["skc"] = m, g["skc"]
            rows.append(r)
        if rows:
            out.append(dict(mark=m, skc=g["skc"], rows=rows))
    return out


def split_parts(groups, max_rows=MAX_ROWS):
    """Dàn phẳng các dòng rồi ngắt mỗi max_rows dòng. -> [ [row, ...], ... ]"""
    flat = [r for g in groups for r in g["rows"]]
    return [flat[i:i + max_rows] for i in range(0, len(flat), max_rows)] or [[]]


# ------------------------------------------------------------------ bộ vẽ (mở rộng Builder có sẵn)
class TB(E.Builder):
    def _owner(self):
        return "2"

    def text(self, x, y, txt, h=TXT_H, align="L"):
        """Chữ canh giữa theo chiều dọc; align: L trái, C giữa, R phải."""
        ax, ay = self.ab(x, y)
        halign = {"L": 0, "C": 1, "R": 2}.get(align, 0)
        ch = [(0, "TEXT"), (5, self.ctx.handle()), (330, self._owner()), (100, "AcDbEntity"),
              (8, TXT_LAYER), (100, "AcDbText"),
              (10, E.fmt(ax)), (20, E.fmt(ay - h / 2.0)), (30, "0.0"), (40, E.fmt(h)), (1, txt),
              (7, TXT_STYLE)]
        if halign:
            ch.append((72, str(halign)))
        ch += [(11, E.fmt(ax)), (21, E.fmt(ay)), (31, "0.0"), (100, "AcDbText"), (73, "2")]
        self.ctx.out.extend(ch)

    def line(self, x1, y1, x2, y2, layer=LINE_LAYER):
        ax, ay = self.ab(x1, y1)
        bx, by = self.ab(x2, y2)
        self.ctx.out.extend([(0, "LINE"), (5, self.ctx.handle()), (330, self._owner()), (100, "AcDbEntity"),
                             (8, layer), (100, "AcDbLine"),
                             (10, E.fmt(ax)), (20, E.fmt(ay)), (30, "0.0"),
                             (11, E.fmt(bx)), (21, E.fmt(by)), (31, "0.0")])

    def dimx(self, vertical, p13, p14, dimline_pt, text_pt, meas, text, style="Dce_50MV"):
        """Dim có chữ ghi đè (hình vẽ tay nên số đo thật khác độ dài trên bản vẽ)."""
        proto = self.p.dim_rot if vertical else self.p.dim_h
        ch = [(c, v) for c, v in E.clean_xdata(list(proto)) if c != 2]
        E.setv(ch, 5, self.ctx.handle())
        E.setv(ch, 8, "DCE_Dim")
        E.setv(ch, 3, style)
        for cx, cy, pt in ((10, 20, dimline_pt), (11, 21, text_pt), (13, 23, p13), (14, 24, p14)):
            ax, ay = self.ab(*pt)
            E.setv(ch, cx, E.fmt(ax))
            E.setv(ch, cy, E.fmt(ay))
        E.setv(ch, 42, E.fmt(meas))
        E.setv(ch, 1, text)
        self.ctx.out.extend(ch)


def _f2(v):
    return "%.2f" % v


# ------------------------------------------------------------------ hình vẽ tay cho dòng TKTUnknown
def _sketch_points(r):
    """Đỉnh hình vẽ (toạ độ thực, mm) đã xoay cho đoạn dài nhất nằm ngang; closed=True nếu đai kín."""
    if r["closed"]:
        w, h = max(r["bw"], 1.0), max(r["bh"], 1.0)
        return [(0, 0), (w, 0), (w, h), (0, h), (0, 0)], True
    pts = _dedupe(r["pts"])
    best, ang = 0.0, 0.0
    for a, b in zip(pts[:-1], pts[1:]):
        L = math.hypot(b[0] - a[0], b[1] - a[1])
        if L > best:
            best, ang = L, math.atan2(b[1] - a[1], b[0] - a[0])
    c, s = math.cos(-ang), math.sin(-ang)
    rot = [((x - pts[0][0]) * c - (y - pts[0][1]) * s, (x - pts[0][0]) * s + (y - pts[0][1]) * c) for x, y in pts]
    return rot, False


def draw_sketch(bd, r, row_top):
    """Vẽ hình + dim trong ô HÌNH DẠNG của dòng cao ROW_H_UNK, đỉnh dòng ở y = row_top."""
    if r.get("closed") and r.get("round"):
        # đai tròn: vẽ vòng tròn + ghi đường kính vòng đai bằng chữ (không dim)
        cx, cy, rad = (SK_X0 + SK_X1) / 2.0 - 150.0, row_top - 300.0, 110.0
        bd.poly("DCE_ThepChu", [(cx - rad, cy), (cx + rad, cy)], closed=True, bulges=[1.0, 1.0])
        bd.text(cx + rad + 70.0, cy, "%%c" + str(int(round(r["bw"]))) + (" xoắn" if r.get("spiral") else ""), TXT_H, "L")
        return
    pts, closed = _sketch_points(r)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    bw, bh = max(xs) - min(xs), max(ys) - min(ys)
    box_w, box_h = (SK_X1 - SK_X0) - 700.0, 270.0
    sc = min(box_w / bw if bw > 1e-6 else 1.0, box_h / bh if bh > 1e-6 else 1.0, 1.0)
    # hình minh hoạ: đoạn ngắn (móc, đoạn gãy) được kéo dài tối thiểu để còn nhìn thấy; số dim vẫn là số thật
    Q = [(0.0, 0.0)]
    for i in range(len(pts) - 1):
        dx, dy = pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]
        axis = abs(dx) < 1e-6 or abs(dy) < 1e-6
        mx = []
        for c in (dx, dy):
            if abs(c) < 1e-6:
                mx.append(0.0)
            else:
                mn = 140.0 if axis else 45.0
                mx.append(math.copysign(max(abs(c) * sc, mn), c))
        Q.append((Q[-1][0] + mx[0], Q[-1][1] + mx[1]))
    qx = [p[0] for p in Q]
    qy = [p[1] for p in Q]
    cx = (SK_X0 + SK_X1) / 2.0
    cy = row_top - 300.0
    P = [(cx + x - (min(qx) + max(qx)) / 2.0, cy + y - (min(qy) + max(qy)) / 2.0) for x, y in Q]
    bd.poly("DCE_ThepChu", P, closed=False)
    xmin, xmax = min(p[0] for p in P), max(p[0] for p in P)
    ymin, ymax = min(p[1] for p in P), max(p[1] for p in P)
    used_h = set()
    # KHÔNG dùng dim: chỉ vẽ hình dạng thép và ghi chiều dài từng đoạn bằng chữ thường (số đo thật, mm)
    for i in range(len(P) - 1):
        if closed and i >= 2:           # đai kín: chỉ ghi 1 cạnh ngang + 1 cạnh đứng
            break
        (ax, ay), (bx, by) = P[i], P[i + 1]
        real = math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1])
        txt = "%d" % round(real)
        dx, dy = bx - ax, by - ay
        if abs(dy) < 1e-6 and abs(dx) > 1e-6:                    # đoạn ngang: chữ ở giữa, phía trên hoặc dưới hình
            low = (ay - ymin) <= (ymax - ay)
            key = ("h", low)
            if key in used_h:
                continue
            used_h.add(key)
            yt = ymin - 90.0 if low else ymax + 90.0
            bd.text((ax + bx) / 2.0, yt, txt, TXT_H, "C")
        elif abs(dx) < 1e-6 and abs(dy) > 1e-6:                  # đoạn đứng: chữ bên trái (canh phải) hoặc bên phải (canh trái)
            left = (ax - xmin) <= (xmax - ax)
            if left:
                bd.text(xmin - 60.0, (ay + by) / 2.0, txt, TXT_H, "R")
            else:
                bd.text(xmax + 60.0, (ay + by) / 2.0, txt, TXT_H, "L")


# ------------------------------------------------------------------ vẽ 1 phần bảng
def _regroup(rows):
    """Gom các dòng liên tiếp cùng cột -> [(mark, skc, [rows])]"""
    out = []
    for r in rows:
        if out and out[-1][0] == r["mark"]:
            out[-1][2].append(r)
        else:
            out.append((r["mark"], r["skc"], [r]))
    return out


def draw_part(bd, rows):
    """Trả về y (toạ độ tương đối) đáy bảng."""
    P = bd.p.blocks
    bd.insert(P["TKTitle"], 0.0, 0.0, None, {})
    y = -TITLE_H
    first = True
    for mark, skc, grows in _regroup(rows):
        y0 = y
        if not first:
            bd.poly(LINE_LAYER, [(0.0, y0), (NAME_W, y0)])
        first = False
        for r in grows:
            tx = {"SH": str(r["sh"]), "DK": str(r["d"]), "sumL": str(r["sumL"]), "SL": str(r["n"]),
                  "SKC": str(r["skc"]), "TSL": str(r["tsl"]), "Lall": _f2(r["lall"]), "KL": _f2(r["kl"])}
            if r["kind"] == "TK1":
                tx["L"] = str(r["sumL"])
                bd.insert(P["TK1"], 0.0, y, None, tx)
                y -= ROW_H
            elif r["kind"] == "TK4":
                tx.update({"L1": str(int(round(r["l1"]))), "L2": str(int(round(r["l2"]))),
                           "L3": str(int(round(r["l3"])))})
                bd.insert(P["TK4"], 0.0, y, None, tx)
                y -= ROW_H
            else:
                bd.insert(P["TKTUnknown"], 0.0, y, None, tx)
                draw_sketch(bd, r, y)
                y -= ROW_H_UNK
        bd.insert(P["TenCauKien"], NAME_W / 2.0, (y0 + y) / 2.0, None,
                  {"SOCAUKIEN": "SL: %d" % skc, "TENCAUKIEN": mark})
    bd.poly(LINE_LAYER, [(0.0, y), (NAME_W, y)])
    return y


# ------------------------------------------------------------------ ô TỔNG HỢP CỐT THÉP
def draw_summary(bd, y_top, rows_all):
    """Vẽ ô tổng hợp, đỉnh ở y_top (toạ độ tương đối). Trả về y đáy."""
    bydia = {}
    for r in rows_all:
        a = bydia.setdefault(r["d"], [0.0, 0.0])
        a[0] += r["lall"]
        a[1] += r["kl"]
    dias = sorted(bydia)
    nc = max(len(dias), 1)
    W = SUM_C0 + nc * SUM_CW
    # khung tiêu đề
    bd.line(0, y_top, W, y_top)
    bd.line(0, y_top, 0, y_top - SUM_TITLE_H)
    bd.line(W, y_top, W, y_top - SUM_TITLE_H)
    bd.text(W / 2.0, y_top - SUM_TITLE_H / 2.0, "TỔNG HỢP CỐT THÉP", 150.0, "C")
    # lưới 4 dòng
    y0 = y_top - SUM_TITLE_H
    for i in range(5):
        bd.line(0, y0 - i * SUM_ROW, W, y0 - i * SUM_ROW)
    xs = [0.0, SUM_C0] + [SUM_C0 + (i + 1) * SUM_CW for i in range(nc)]
    for x in xs:
        bd.line(x, y0, x, y0 - 4 * SUM_ROW)
    labels = ["- Đường kính (mm):", "- Chiều dài (m):", "- Khối lượng (kg):", "- Chiều dài / %g" % BAR_STD]
    for i, lb in enumerate(labels):
        bd.text(100.0, y0 - (i + 0.5) * SUM_ROW, lb)
    for j, d in enumerate(dias):
        xc = SUM_C0 + (j + 0.5) * SUM_CW
        L, K = bydia[d]
        vals = ["%%c" + str(d), _f2(L), _f2(K), "-" if d <= COIL_MAX_D else str(int(math.ceil(L / BAR_STD - 1e-9)))]
        for i, v in enumerate(vals):
            bd.text(xc, y0 - (i + 0.5) * SUM_ROW, v, TXT_H, "C")
    # nhóm theo Ø + tổng cộng
    g1 = sum(v[1] for d, v in bydia.items() if d <= 10)
    g2 = sum(v[1] for d, v in bydia.items() if 10 < d <= 18)
    g3 = sum(v[1] for d, v in bydia.items() if d > 18)
    items = [("- Nhóm %%c <= 10:", g1), ("- Nhóm 10 < %%c <= 18:", g2), ("- Nhóm %%c > 18:", g3)]
    items = [it for it in items if it[1] > 1e-9]
    items.append(("- Tổng cộng:", sum(v[1] for v in bydia.values())))
    y = y0 - 4 * SUM_ROW - 50.0
    for lb, val in items:
        bd.poly(LINE_LAYER, [(0, y), (GRP_W, y), (GRP_W, y - SUM_ROW), (0, y - SUM_ROW)], closed=True)
        bd.line(SUM_C0, y, SUM_C0, y - SUM_ROW)
        bd.line(SUM_C0 + SUM_CW, y, SUM_C0 + SUM_CW, y - SUM_ROW)
        bd.text(100.0, y - SUM_ROW / 2.0, lb)
        bd.text(SUM_C0 + SUM_CW / 2.0, y - SUM_ROW / 2.0, _f2(val), TXT_H, "C")
        bd.text(SUM_C0 + SUM_CW * 1.5, y - SUM_ROW / 2.0, "kg", TXT_H, "C")
        y -= SUM_ROW
    return y, W


# ------------------------------------------------------------------ chương trình chính
def generate(dxf_in, dxf_out, max_rows=MAX_ROWS, template=TEMPLATE, scan=None, tag="TK"):
    """Đọc COT.dxf -> ghi bảng thống kê. Trả về dict thông tin (số dòng, số phần, tổng kg).
    scan: (cols, bars, stirs) có sẵn thì dùng thay cho việc đọc dxf_in."""
    groups = collect(dxf_in) if scan is None else collect_scan(*scan)
    if not groups:
        raise ValueError("Không thấy thanh thép / đai (dữ liệu COLREBAR) trong %s" % dxf_in)
    parts = split_parts(groups, max_rows)
    pairs = E.load_raw(template)
    head, ents, tail = E.split_sections(pairs)
    protos = E.Protos(ents)
    for need in ("TKTitle", "TK1", "TK4", "TKTUnknown", "TenCauKien"):
        if need not in protos.blocks:
            raise ValueError("File mẫu thiếu block %s" % need)
    seed, hs_i = None, None
    for i, (c, v) in enumerate(head):
        if c == 9 and v.strip() == "$HANDSEED":
            seed, hs_i = int(head[i + 1][1].strip(), 16), i + 1
            break
    ctx = E.Ctx(max(seed or 0, 0x10000))
    head = E.add_appid(head, ctx, E.APP_NAME)           # để gắn thẻ XDATA cho bảng (SUATHEP vẽ lại bảng đúng chỗ)
    if hs_i is not None:
        hs_i = [i for i, (c, v) in enumerate(head) if c == 9 and v.strip() == "$HANDSEED"][0] + 1
    ends = []
    for k, rows in enumerate(parts):
        bd = TB(ctx, protos, k * (TABLE_W + PART_GAP), 0.0, (0.0, 0.0))
        ends.append(draw_part(bd, rows))
    # ô tổng hợp gắn dưới phần cuối
    k = len(parts) - 1
    bdl = TB(ctx, protos, k * (TABLE_W + PART_GAP), 0.0, (0.0, 0.0))
    all_rows = [r for g in groups for r in g["rows"]]
    y_bot, _ = draw_summary(bdl, ends[-1], all_rows)
    # khung Defpoints bao ngoài
    right = (len(parts) - 1) * (TABLE_W + PART_GAP) + TABLE_W
    bot = min(min(ends), y_bot)
    bdf = TB(ctx, protos, 0.0, 0.0, (0.0, 0.0))
    bdf.poly("Defpoints", [(-125.0, 125.0), (right + 125.0, 125.0), (right + 125.0, bot - 95.0),
                           (-125.0, bot - 95.0)], closed=True)
    ctx.out = E.tag_entities(ctx.out, "OBJ|T=%s" % tag)      # TK = bảng lien kết (tự thay); tag khác = bảng riêng, không tự thay
    if hs_i is not None:
        head[hs_i] = (head[hs_i][0], "%X" % ctx.h)
    for i in range(len(head) - 1):
        if head[i] == (9, "$INSUNITS"):
            head[i + 1] = (70, "0")
        if head[i] == (9, "$EXTMIN"):
            for j in range(i + 1, min(i + 7, len(head))):
                if head[j][0] == 10:
                    head[j] = (10, E.fmt(-125.0))
                elif head[j][0] == 20:
                    head[j] = (20, E.fmt(bot - 95.0))
                elif head[j][0] == 30:
                    head[j] = (30, "0.0")
        if head[i] == (9, "$EXTMAX"):
            for j in range(i + 1, min(i + 7, len(head))):
                if head[j][0] == 10:
                    head[j] = (10, E.fmt(right + 125.0))
                elif head[j][0] == 20:
                    head[j] = (20, E.fmt(125.0))
                elif head[j][0] == 30:
                    head[j] = (30, "0.0")
    E.save_raw(dxf_out, head + ctx.out + tail)
    return dict(rows=len(all_rows), parts=len(parts), per_part=[len(p) for p in parts],
                kg=sum(r["kl"] for r in all_rows))


def main():
    if len(sys.argv) < 3:
        sys.exit("Cách dùng: python bang_thong_ke.py COT.dxf THONG_KE.dxf [so_dong_toi_da]")
    mx = int(sys.argv[3]) if len(sys.argv) > 3 else MAX_ROWS
    info = generate(sys.argv[1], sys.argv[2], mx)
    print("Đã ghi %s: %d dòng, %d phần %s, tổng %.2f kg" % (sys.argv[2], info["rows"], info["parts"],
                                                          info["per_part"], info["kg"]))


if __name__ == "__main__":
    main()
